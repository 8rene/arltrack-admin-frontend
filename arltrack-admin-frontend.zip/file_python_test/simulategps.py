"""
Fake ESP32 GPS tracker — sends a random ping to the local backend every 10s,
for 2 devices at once.

Usage:
    pip install requests
    python simulate_gps.py

Edit the CONFIG block below before running.
"""

import random
import time
import requests

# ── CONFIG ───────────────────────────────────────────────────────────────
API_URL = "http://localhost:5000/api/gps"

# Each device wanders randomly around its own center point, within ~1km.
DEVICE_1_ID  = "vBvPENicmLpCXGPmLwMg"   # must match a real gpsDeviceID in Firestore
DEVICE_1_LAT = 14.6760                 # Quezon City
DEVICE_1_LNG = 121.0437

DEVICE_2_ID  = "Lzgg0exNFuetH1yFckOn"   # must match a real gpsDeviceID in Firestore
DEVICE_2_LAT = 14.5547                           # Makati
DEVICE_2_LNG = 121.0244

JITTER = 0.01                     # ~1km of drift in each direction

SPEED_MIN, SPEED_MAX = 0, 80      # km/h
OFFLINE_CHANCE       = 0.1        # 10% of pings marked as buffered/offline
INTERVAL_SECONDS     = 10
# ─────────────────────────────────────────────────────────────────────────

DEVICES = [
    {"id": DEVICE_1_ID, "lat": DEVICE_1_LAT, "lng": DEVICE_1_LNG},
    {"id": DEVICE_2_ID, "lat": DEVICE_2_LAT, "lng": DEVICE_2_LNG},
]


def random_ping(device):
    return {
        "device_id": device["id"],
        "lat": round(device["lat"] + random.uniform(-JITTER, JITTER), 6),
        "lng": round(device["lng"] + random.uniform(-JITTER, JITTER), 6),
        "speed": round(random.uniform(SPEED_MIN, SPEED_MAX), 1),
        "offline": random.random() < OFFLINE_CHANCE,
    }


def send_ping(device):
    payload = random_ping(device)
    try:
        res = requests.post(API_URL, json=payload, timeout=5)
        status = res.status_code
        body = res.text
    except requests.RequestException as e:
        status = "ERR"
        body = str(e)

    flag = "📦 offline" if payload["offline"] else "🛰️  live   "
    print(
        f"[{device['id']}] [{flag}] lat={payload['lat']:.6f} lng={payload['lng']:.6f} "
        f"speed={payload['speed']:.1f}km/h -> {status} {body}"
    )


def main():
    print(f"Sending fake GPS pings for {len(DEVICES)} devices to {API_URL} every {INTERVAL_SECONDS}s. Ctrl+C to stop.\n")
    while True:
        for device in DEVICES:
            send_ping(device)
        time.sleep(INTERVAL_SECONDS)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")