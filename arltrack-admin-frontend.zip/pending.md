Pending


sean 12:30 cleanup remove changes in penalty model treshol


refund cleanup ui
type should have more


mainca
Cron schedule dont record audit log


logs and archives design



penalty setup
overall breakdown
    the penalty and usch if refunded.
    how much sale ? depositw as used for?

penalty cash no 

USER RESUBMIT UIAND USER ACCOUNT
 FLGAGGED SHOULD NOTIFY THEM and should show that they wont be capable of cancelling and creating a review



 ise eucahange some logic didnt you let me explain to you okay?

when requesting refund within grace period 2hours, it will auto approve, basically auto scheduled for refund in cron of admin
= full refund except the gatewayfee they paid, because its a loss

if they cancelled outside 2 hours and the booking is more than 48 hours before it, it will return deposit but not the gatewayfee too

if its under 48 hours gateway was refunded and deposit fee was not

so there sno full refund, in customer and so evey refund they do is on possibily on enxt day because the partial refund inpaymongo on same day they paid is impossible
so the full refund may only hapepn in fleet.jsx adn booking.jsx when the owner admits its their issue nd they shall take the loss]








main.851fe174.js:2 [InspectionMedia] video upload failed: FirebaseError: Firebase Storage: An unknown error occurred, please check the error payload for server response. (storage/unknown)
S @ main.851fe174.js:2
firestore.googleapis.com/google.firestore.v1.Firestore/Write/channel?VER=8&database=projects%2Farltrack-carrentalservices%2Fdatabases%2F(default)&gsessionid=tF8WCSopw1mflg6_-4lWC3xTi6JKJoxwUr2o175099aqhVb3PsHK0w&SID=CnODiSKlTGhYEzvNEoPoKA&RID=45755&TYPE=terminate&zx=w2wmqabgw7rt:1  Failed to load resource: net::ERR_BLOCKED_BY_CLIENT

COULNT REMOVE VIDEO UPLOAD

wrong fetchning 
itrefrehses every time
coding restriction 
gps fetching


mark stolen status bookigns
schedule refund
the car tarcking deisgn


remove  revenu upcomnig or possible

hisotry design on sean arimado claude



aduti logs 
therestore buttons and such
should follow the bookings button that sticks udner

color the user to view user

transction log done yb staff incorrectiguess or maybe yb system anywyas scheduled should show who did it

view booking too



account save and edit


driver dahsboard
show the recent trips like dashoard of staff

the next and previous follow instpeciton design



archive audit log should have the descripiton clipped

booking archive he veiwu users view terms
put email as the blue color terms and condit too
fix it please its kidna ugly






driver view terms dont have the number
driver dont ahve contac number f the customer, and license

steps vehicle inspection + gps setup
driver dont allow pickup unless on mywa buttonw as clicked

maintenance in creating no notify on owner
mintanence when editing it should show the warning select parts before clicking it
add the penalties ont he left side

penalty showing amintenace hsould have the details
penalty when has to review

put the cant ad a new one close to the create and notify
already on this booking si alwsy show

penalty edit discard dont have proper color


CUSTOMER SIDE
NUMBER CODING NOT SHOWING
ICAN BOOK SAME DAY WHEN THERES A PREPARTION TIME
CUSTOMER CAN JUST OPENT HE PAY BALANCE AND QUIT THEN OPEN AGIN THEN IT WILL BE REOCRDED

show penalties on the details not just in boking sumarry
pre