Pending


sean 12:30 cleanup remove changes in penalty model treshol


refund cleanup ui
type should have more


mainca
Cron schedule dont record audit log


logs and archives design



penalty setup
overall breakdown
    the penalty and usch if refunded.
    how much sale ? depositw as used for?

penalty cash no 

USER RESUBMIT UIAND USER ACCOUNT
 FLGAGGED SHOULD NOTIFY THEM and should show that they wont be capable of cancelling and creating a review



 ise eucahange some logic didnt you let me explain to you okay?

when requesting refund within grace period 2hours, it will auto approve, basically auto scheduled for refund in cron of admin
= full refund except the gatewayfee they paid, because its a loss

if they cancelled outside 2 hours and the booking is more than 48 hours before it, it will return deposit but not the gatewayfee too

if its under 48 hours gateway was refunded and deposit fee was not

so there sno full refund, in customer and so evey refund they do is on possibily on enxt day because the partial refund inpaymongo on same day they paid is impossible
so the full refund may only hapepn in fleet.jsx adn booking.jsx when the owner admits its their issue nd they shall take the loss