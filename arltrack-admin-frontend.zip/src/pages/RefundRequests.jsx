import { useEffect, useState, useCallback, Fragment } from "react";
import { useNavigate } from "react-router-dom";
import { useCurrency } from "../context/CurrencyContext";

// ─── SVG ICONS ─────────────────────────────────────────────────────────────

const IconCheck = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconX = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

// ─── HELPERS ────────────────────────────────────────────────────────────────

const statusDot = {
  Pending:  "bg-yellow-400",
  Approved: "bg-blue-500",
  Refunded: "bg-green-500",
  Rejected: "bg-red-500",
  Failed:   "bg-red-500",
};
const statusBg = {
  Pending:  "bg-yellow-50 border border-yellow-200",
  Approved: "bg-blue-50 border border-blue-200",
  Refunded: "bg-green-50 border border-green-200",
  Rejected: "bg-red-50 border border-red-200",
  Failed:   "bg-red-50 border border-red-200",
};
// "Approved" is stored as-is, but it is a WAITING state, not a finished one: the booking is
// cancelled and PayMongo has been asked to refund, yet the money isn't back until PayMongo
// confirms (and staff hand back any in-person part). So the screen shows what it is waiting on:
//   paymongo → a refund part hasn't been confirmed by PayMongo yet
//   handback → every online part is done, only the in-person cash is left for staff to hand back
const WAIT_STAGE = {
  paymongo: { label: "Waiting for PayMongo",  dot: "bg-blue-500",   bg: "bg-blue-50 border border-blue-200",     tip: "Approved — waiting for PayMongo to confirm the refund." },
  handback: { label: "Waiting for hand-back", dot: "bg-orange-500", bg: "bg-orange-50 border border-orange-200", tip: "Approved — the online part is done; the in-person amount still has to be handed back." },
};
const stageOf = (r) => {
  if (!r || r.status !== "Approved") return null;
  const parts = Array.isArray(r.parts) ? r.parts : [];
  const onlinePending = parts.length === 0 || parts.some((x) => x.status !== "succeeded"); // older requests without parts → assume PayMongo
  const handbackPending = !!(r.manualRefund && !r.manualRefund.issued);
  if (onlinePending) return "paymongo";
  return handbackPending ? "handback" : "paymongo";
};
const handbackDue = (r) => (r && r.status === "Approved" && r.manualRefund && !r.manualRefund.issued ? Number(r.manualRefund.amount) || 0 : 0);

function StatusBadge({ status, stage }) {
  const w   = stage ? WAIT_STAGE[stage] : null;
  const dot = w ? w.dot : (statusDot[status] || "bg-gray-400");
  const bg  = w ? w.bg  : (statusBg[status]  || "bg-gray-50 border border-gray-200");
  return (
    <span title={w ? w.tip : undefined} className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full text-black ${bg}`}>
      <span className={`w-2 h-2 rounded-full shrink-0 ${dot}`} />
      {w ? w.label : status}
    </span>
  );
}

// How long an approved refund has been waiting (since it was approved). Lets stuck ones stand out.
const waitStartMs = (r) => {
  const d = r.processedAt || r.updatedAt;
  const t = d && d.toDate ? d.toDate() : d ? new Date(d) : null;
  return t && !isNaN(t) ? t.getTime() : 0;
};
const fmtWaiting = (r) => {
  const t = waitStartMs(r);
  if (!t) return null;
  const hours = Math.max(0, (Date.now() - t) / 3600000);
  return { text: hours < 48 ? `${Math.max(1, Math.floor(hours))}h` : `${Math.floor(hours / 24)}d`, late: hours >= 72 };
};
// Queue order inside the Active tab: needs-review first, waiting-on-money below.
const groupOf = (r) => (r.status === "Pending" ? 0 : 1);

// "Active" = still an open queue item admin needs to act on or is waiting
// on PayMongo for. "History" = resolved, permanent record — money already
// moved (or definitively didn't). Tab lives above the status chips; the
// chips themselves narrow further within whichever tab is selected.
const PAGE_SIZE = 15;

// --- PAGINATION (same pattern as Bookings.jsx / Payments.jsx / Users.jsx) -----
function usePagination(items, pageSize = PAGE_SIZE) {
  const [page, setPage] = useState(1);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  // Clamp if the list shrinks (filter/search/refresh) and we were on a now-empty page.
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;
  const pageItems = items.slice(start, start + pageSize);
  return { page: safePage, setPage, totalPages, pageItems, start, count: items.length };
}

function Pagination({ page, totalPages, onChange, start, pageSize, count }) {
  if (totalPages <= 1) return null;

  const nums = [];
  const add = (n) => nums.push(n);
  add(1);
  for (let n = page - 1; n <= page + 1; n++) if (n > 1 && n < totalPages) add(n);
  if (totalPages > 1) add(totalPages);
  const dedup = [...new Set(nums)].sort((a, b) => a - b);

  const rangeEnd = Math.min(start + pageSize, count);

  return (
    <div className="flex items-center justify-between px-5 py-3 border-t bg-gray-50/50">
      <p className="text-xs text-gray-400">
        Showing {count === 0 ? 0 : start + 1}–{rangeEnd} of {count}
      </p>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange(Math.max(1, page - 1))} disabled={page === 1}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Prev
        </button>
        {dedup.map((n, i) => (
          <span key={n} className="flex items-center">
            {i > 0 && n - dedup[i - 1] > 1 && <span className="px-1.5 text-gray-300 text-xs">…</span>}
            <button onClick={() => onChange(n)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                n === page ? "bg-teal-600 text-white shadow" : "border text-gray-600 hover:bg-white"
              }`}>
              {n}
            </button>
          </span>
        ))}
        <button onClick={() => onChange(Math.min(totalPages, page + 1))} disabled={page === totalPages}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Next
        </button>
      </div>
    </div>
  );
}

const TABS = [
  { key: "active",  label: "Active Queue", statuses: ["Pending", "Approved"] },
  { key: "history", label: "History",      statuses: ["Refunded", "Rejected", "Failed"] },
];

// ─── MAIN COMPONENT ─────────────────────────────────────────────────────────

// ─── SORT HEADER ────────────────────────────────────────────────────────────
// Same clickable <th> as Bookings/Users: toggles asc/desc, neutral chevrons when
// the column isn't the active sort. (px-5 here to line up with this table's cells.)
const IconChevronsUpDown = ({ className = "w-3.5 h-3.5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7 15l5 5 5-5M7 9l5-5 5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconSortArrow = ({ dir, className = "w-3.5 h-3.5" }) => (
  <svg
    className={`${className} transition-transform ${dir === "desc" ? "rotate-180" : ""}`}
    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M12 19V5M5 12l7-7 7 7" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

function SortableTh({ label, sortKey: key, sortKeyState, sortDir, onSort, className = "" }) {
  const active = sortKeyState === key;
  return (
    <th className={`px-5 py-3 text-left select-none ${className}`}>
      <button
        onClick={() => onSort(key)}
        className={`flex items-center gap-1.5 uppercase tracking-wider text-xs font-semibold px-2 py-1 -mx-2 rounded-lg transition-colors ${
          active ? "text-teal-700 bg-teal-50" : "text-gray-400 hover:text-gray-700 hover:bg-gray-100"
        }`}
      >
        {label}
        {active ? <IconSortArrow dir={sortDir} /> : <IconChevronsUpDown />}
      </button>
    </th>
  );
}

// ─── DATES ──────────────────────────────────────────────────────────────────
// createdAt / updatedAt / processedAt come back from the API as Firestore
// timestamps ({_seconds}) — or ISO strings, depending on the path.
const toDate = (val) => {
  if (!val) return null;
  let d;
  if (typeof val.toDate === "function") d = val.toDate();
  else if (val._seconds !== undefined)  d = new Date(val._seconds * 1000);
  else if (val.seconds !== undefined)   d = new Date(val.seconds * 1000);
  else d = new Date(val);
  return isNaN(d.getTime()) ? null : d;
};
const toMillis = (d) => (d ? d.getTime() : -Infinity);

// "Updated" only means something once the request changed after it was filed;
// a still-untouched Pending request shows "—" instead of repeating the request date.
// Keyed off status, not a time gap — a quick Approve/Reject right after filing
// is still a real change and must show its own Updated date.
const updatedDate = (r) => {
  if (r.status === "Pending") return null;
  return toDate(r.updatedAt) || toDate(r.processedAt);
};

const stampParts = (d) => d && ({
  date: d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" }),
  time: d.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" }),
});

const DateCell = ({ date }) => {
  const p = stampParts(date);
  if (!p) return <span className="text-gray-300">—</span>;
  return (
    <>
      <p className="text-sm text-gray-700">{p.date}</p>
      <p className="text-xs text-gray-400">{p.time}</p>
    </>
  );
};

export default function RefundRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [tab, setTab]           = useState("active");
  const [statusF, setStatusF]   = useState("All");
  const [search, setSearch]     = useState("");
  const [toast, setToast]       = useState(null);
  const [busyId, setBusyId]     = useState(null);
  const [rejectTarget, setRejectTarget] = useState(null); // request being rejected
  const [rejectReason, setRejectReason] = useState("");
  // Approving a request that carries a 48-hour deposit forfeit opens a confirmation
  // (with an optional, reason-required "waive the forfeit" override).
  const [approveTarget, setApproveTarget] = useState(null);
  const [waiveForfeit, setWaiveForfeit]   = useState(false);
  const [waiveReason, setWaiveReason]     = useState("");
  // Which method staff picked when handing the in-person part of a refund back, per request id.
  // Method staff pick when they hand the in-person part of a refund back, per request id (default Cash).
  const [handbackMethod, setHandbackMethod] = useState({});
  const [sortKey, setSortKey] = useState(null); // null = default/unsorted (API order: newest request first)
  const [sortDir, setSortDir] = useState("asc");

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const token = localStorage.getItem("token");
  const { fmt } = useCurrency();
  const navigate = useNavigate();

  const activeTab = TABS.find((t) => t.key === tab) || TABS[0];

  const switchTab = (key) => {
    setTab(key);
    setStatusF("All"); // reset the sub-filter so switching tabs doesn't hide everything
  };

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchRequests = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to load refund requests.");
      setRequests(data.data || []);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchRequests(); }, [fetchRequests]);

  // A request with a deposit forfeit asks for confirmation first; anything else approves straight away.
  const startApprove = (r) => {
    if (r.planPreview && r.planPreview.forfeit > 0) {
      setApproveTarget(r); setWaiveForfeit(false); setWaiveReason("");
    } else {
      approve(r.refundRequestID);
    }
  };

  const approve = async (id, opts = {}) => {
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/${id}/approve`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(opts.waiveForfeit ? { waiveForfeit: true, waiveReason: opts.waiveReason } : {}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to approve refund.");
      showToast(data.message || "Refund approved and sent to PayMongo.");
      // Approval can now change the amount (recomputed from what the customer has
      // actually paid), split it into PayMongo refunds + a manual part, and cancel the
      // booking — so take the server's version of the request rather than guessing.
      setRequests((prev) => prev.map((r) => r.refundRequestID === id ? { ...r, ...(data.data || {}), status: "Approved", planPreview: undefined } : r));
    } catch (e) { showToast(e.message, "error"); fetchRequests(); }
    finally { setBusyId(null); setApproveTarget(null); }
  };

  // Staff confirm they physically handed the in-person part back. The backend finishes the
  // request (→ Refunded) once every PayMongo part has also succeeded.
  const markHandedBack = async (r) => {
    const id = r.refundRequestID;
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/${id}/manual-issued`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ method: handbackMethod[id] || "Cash" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to mark the refund as handed back.");
      showToast(data.message || "Marked as handed back.");
      fetchRequests(); // status may have moved to Refunded (history) — take the server's version
    } catch (e) { showToast(e.message, "error"); }
    finally { setBusyId(null); }
  };

  const submitReject = async () => {
    if (!rejectTarget) return;
    const id = rejectTarget.refundRequestID;
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/${id}/reject`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ rejectReason }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to reject refund.");
      showToast("Refund request rejected.");
      setRequests((prev) => prev.map((r) => r.refundRequestID === id ? { ...r, status: "Rejected", rejectReason } : r));
      setRejectTarget(null); setRejectReason("");
    } catch (e) { showToast(e.message, "error"); }
    finally { setBusyId(null); }
  };

  const filtered = requests.filter((r) => {
    const q = search.toLowerCase();
    const matchQ = !q
      || (r.refundRequestID || "").toLowerCase().includes(q)
      || (r.customerName || "").toLowerCase().includes(q)
      || (r.bookingID || "").toLowerCase().includes(q)
      || (r.paymentID || "").toLowerCase().includes(q);
    const matchTab = activeTab.statuses.includes(r.status);
    const matchS = statusF === "All" || r.status === statusF;
    return matchQ && matchTab && matchS;
  });

  // Numbered pagination (same shared component as Bookings/Payments). The hook
  // clamps the page if approving/rejecting shrinks the list underneath us.
  // Sort after search/tab/status filtering, before pagination, so Page 1 is the
  // top of whatever sort is active.
  const sorted = [...filtered].sort((a, b) => {
    // Active tab: Pending (needs a decision) always above the ones waiting on money,
    // whatever column is sorted — the chosen sort then applies inside each group.
    if (tab === "active") {
      const g = groupOf(a) - groupOf(b);
      if (g) return g;
    }
    if (!sortKey) {
      // default inside the waiting group: longest-waiting first, so stuck ones are on top
      if (tab === "active" && groupOf(a) === 1) return waitStartMs(a) - waitStartMs(b);
      return 0;
    }
    if (sortKey === "customer") {
      const c = (a.customerName || "").localeCompare(b.customerName || "", undefined, { sensitivity: "base" });
      return sortDir === "asc" ? c : -c;
    }
    let av, bv;
    if (sortKey === "amount")         { av = Number(a.amount) || 0;             bv = Number(b.amount) || 0; }
    else if (sortKey === "requested") { av = toMillis(toDate(a.createdAt));     bv = toMillis(toDate(b.createdAt)); }
    else if (sortKey === "updated")   { av = toMillis(updatedDate(a));          bv = toMillis(updatedDate(b)); }
    else return 0;
    return sortDir === "asc" ? av - bv : bv - av;
  });

  const { page, setPage, totalPages, pageItems: paginated, start, count } = usePagination(sorted, PAGE_SIZE);
  useEffect(() => { setPage(1); }, [search, statusF, tab, sortKey, sortDir]); // eslint-disable-line react-hooks/exhaustive-deps

  // History is a closed record — nothing left to approve/reject — so no Actions column there.
  const showActions = tab !== "history";

  const pendingCount = requests.filter((r) => r.status === "Pending").length;
  const waitingCount = requests.filter((r) => r.status === "Approved").length;
  // Section headers inside the Active tab (only when both groups are on screen / any waiting exists)
  const nPendingShown = filtered.filter((r) => r.status === "Pending").length;
  const nWaitingShown = filtered.filter((r) => r.status === "Approved").length;
  const showSections  = tab === "active" && statusF === "All" && nWaitingShown > 0;

  return (
    <div className="w-full px-4 space-y-5">

      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"
        }`}>{toast.msg}</div>
      )}

      {/* Approve confirmation: shows the 48-hour policy outcome + the staff override */}
      {approveTarget && approveTarget.planPreview && (() => {
        const pv = approveTarget.planPreview;
        const when = pv.tier === "no_show" ? "after the pickup time" : pv.hoursBeforePickup !== null && pv.hoursBeforePickup !== undefined ? `${Math.max(0, Math.round(pv.hoursBeforePickup * 10) / 10)} hours before pickup` : "under 48 hours before pickup";
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setApproveTarget(null)} />
            <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-arl-dark">Approve Refund</h3>
                <button onClick={() => setApproveTarget(null)} className="text-gray-400 hover:text-gray-600"><IconX /></button>
              </div>
              <p className="text-sm text-gray-500">{approveTarget.customerName}</p>
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm space-y-1">
                <p className="text-amber-800 font-semibold">Requested {when}</p>
                <div className="flex justify-between"><span className="text-gray-600">Customer paid</span><span className="font-semibold">{fmt(pv.grossPaid)}</span></div>
                <div className="flex justify-between text-amber-700"><span>Deposit kept (48-hour policy)</span><span className="font-semibold">-{fmt(waiveForfeit ? 0 : pv.forfeit)}</span></div>
                <div className="flex justify-between border-t border-black/10 pt-1"><span className="font-bold text-gray-800">Refund</span><span className="font-black">{fmt(waiveForfeit ? pv.grossPaid : pv.total)}</span></div>
              </div>
              <p className="text-[11px] text-gray-400">The timing is judged by when the customer sent the request, not by when you approve it.</p>
              <label className="flex items-start gap-2 text-sm text-gray-700 cursor-pointer">
                <input type="checkbox" className="mt-0.5" checked={waiveForfeit} onChange={(e) => setWaiveForfeit(e.target.checked)} />
                <span>Waive the deposit forfeit and refund the full {fmt(pv.grossPaid)} <span className="text-gray-400">(goodwill, duplicate charge, etc.)</span></span>
              </label>
              {waiveForfeit && (
                <textarea
                  value={waiveReason}
                  onChange={(e) => setWaiveReason(e.target.value)}
                  placeholder="Reason for waiving (required, saved in the audit log)"
                  rows={2}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-arl-dark/20"
                />
              )}
              <div className="flex justify-end gap-2">
                <button onClick={() => setApproveTarget(null)} className="px-4 py-2 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-100">Cancel</button>
                <button
                  onClick={() => approve(approveTarget.refundRequestID, { waiveForfeit, waiveReason })}
                  disabled={busyId === approveTarget.refundRequestID || (waiveForfeit && !waiveReason.trim())}
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
                >
                  {busyId === approveTarget.refundRequestID ? "Approving..." : "Confirm Approve"}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Reject reason modal */}
      {rejectTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setRejectTarget(null)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-arl-dark">Reject Refund Request</h3>
              <button onClick={() => setRejectTarget(null)} className="text-gray-400 hover:text-gray-600">
                <IconX />
              </button>
            </div>
            <p className="text-sm text-gray-500">
              {rejectTarget.customerName} — {fmt(rejectTarget.amount)}
            </p>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Reason for rejecting (optional, shown to customer)"
              rows={3}
              className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-arl-dark/20"
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setRejectTarget(null)} className="px-4 py-2 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-100">
                Cancel
              </button>
              <button
                onClick={submitReject}
                disabled={busyId === rejectTarget.refundRequestID}
                className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-red-500 hover:bg-red-600 disabled:opacity-50"
              >
                {busyId === rejectTarget.refundRequestID ? "Rejecting…" : "Confirm Reject"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <h1 className="text-xl font-bold text-arl-dark flex items-center gap-2">
            Refunds
          </h1>
          <p className="text-sm text-gray-500">
            {pendingCount > 0 ? `${pendingCount} pending review` : "No pending requests"}
          </p>
        </div>
      </div>

      {/* Active / History tabs */}
      <div className="flex gap-1 border-b border-gray-100">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => switchTab(t.key)}
            className={`px-4 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors ${
              tab === t.key
                ? "border-arl-dark text-arl-dark"
                : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            {t.label}
            {t.key === "active" && pendingCount > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-yellow-100 text-yellow-700 text-[11px] font-bold" title="Needs review">
                {pendingCount}
              </span>
            )}
            {t.key === "active" && waitingCount > 0 && (
              <span className="ml-1 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-gray-100 text-gray-500 text-[11px] font-bold" title="Approved, waiting for the money to go back">
                {waitingCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by customer, booking, or payment ID…"
          className="flex-1 min-w-[220px] rounded-xl border border-gray-200 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-arl-dark/20"
        />
        <div className="flex gap-2 flex-wrap">
          {["All", ...activeTab.statuses].map((s) => (
            <button
              key={s}
              onClick={() => setStatusF(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
                statusF === s ? "bg-arl-dark text-white border-arl-dark" : "bg-white text-gray-600 border-gray-200 hover:border-arl-dark"
              }`}
            >
              {s === "Approved" ? "Waiting" : s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="rounded-2xl border border-gray-100 bg-white shadow-soft overflow-hidden">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-10 text-center text-sm text-gray-400">Loading refund requests…</div>
          ) : error ? (
            <div className="p-10 text-center text-sm text-red-500">{error}</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-sm text-gray-400">
              {tab === "history" ? "No resolved refunds yet." : "No refund requests found."}
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider text-gray-400 border-b border-gray-100">
                  <SortableTh label="Customer" sortKey="customer" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <th className="px-5 py-3 font-semibold">Booking</th>
                  <th className="px-5 py-3 font-semibold">Reason</th>
                  <SortableTh label="Amount" sortKey="amount" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <th className="px-5 py-3 font-semibold">Deposit</th>
                  <SortableTh label="Requested" sortKey="requested" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <SortableTh label="Updated" sortKey="updated" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <th className="px-5 py-3 font-semibold">Status</th>
                  {showActions && <th className="px-5 py-3 font-semibold text-right">Actions</th>}
                </tr>
              </thead>
              <tbody>
                {paginated.map((r, idx) => {
                  const g = groupOf(r);
                  const firstOfGroup = idx === 0 || groupOf(paginated[idx - 1]) !== g;
                  const header = showSections && firstOfGroup && (g === 1 || nPendingShown > 0);
                  return (
                  <Fragment key={r.refundRequestID}>
                    {header && (
                      <tr className="bg-gray-50/80">
                        <td colSpan={showActions ? 9 : 8} className="px-5 py-2 text-xs font-bold uppercase tracking-wider text-gray-500">
                          {g === 0
                            ? `Needs review · ${nPendingShown}`
                            : `Waiting for the money to go back · ${nWaitingShown}`}
                          {g === 1 && <span className="ml-2 font-medium normal-case tracking-normal text-gray-400">approved and booking cancelled — longest waiting first</span>}
                        </td>
                      </tr>
                    )}
                  <tr className="border-b border-gray-50 last:border-0 hover:bg-gray-50/60">
                    <td className="px-5 py-4">
                      <p className="font-semibold text-arl-dark">{r.customerName || "—"}</p>
                    </td>
                    <td className="px-5 py-4">
                      {r.bookingID ? (
                        <button
                          onClick={() => navigate(`/bookings?open=${encodeURIComponent(r.bookingID)}`)}
                          className="font-medium text-teal-600 hover:text-teal-700 hover:underline"
                          title="Open this booking"
                        >
                          {r.bookingID}
                        </button>
                      ) : "—"}
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-gray-700">{r.reason}</p>
                      {r.notes && <p className="text-xs text-gray-400 max-w-[220px] truncate" title={r.notes}>{r.notes}</p>}
                      {r.status === "Rejected" && r.rejectReason && (
                        <p className="text-xs text-red-500 max-w-[220px] truncate" title={r.rejectReason}>Reason: {r.rejectReason}</p>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <p className="font-semibold text-arl-dark">{fmt(r.planPreview ? r.planPreview.total : r.amount)}</p>
                      {r.autoCreated && (
                        <p className="text-[11px] text-amber-600 max-w-[200px]">Opened automatically — payment arrived after the booking was cancelled.</p>
                      )}
                      {r.status === "Pending" && r.planPreview && (
                        <p className="text-[11px] text-gray-500 max-w-[220px]">
                          {fmt(r.planPreview.onlineAmount)} via PayMongo
                          {r.planPreview.manualAmount > 0 && <> · <span className="text-orange-600 font-semibold">{fmt(r.planPreview.manualAmount)} to hand back in person</span></>}
                          {r.planPreview.unrefundableAmount > 0 && <> · <span className="text-red-600 font-semibold">{fmt(r.planPreview.unrefundableAmount)} not refundable — Payment ID does not exist</span></>}
                          {r.planPreview.total !== r.amount && <> · <span className="text-gray-400">(was {fmt(r.amount)} when requested)</span></>}
                        </p>
                      )}
                      {/* 48-hour policy outcome: judged from when the customer ASKED */}
                      {(() => {
                        const tier   = r.status === "Pending" && r.planPreview ? r.planPreview.tier : r.policyTier;
                        const kept   = r.status === "Pending" && r.planPreview ? r.planPreview.forfeit : Number(r.depositForfeited) || 0;
                        if (!tier) return null;
                        const label  = tier === "full" ? "Full refund" : tier === "no_show" ? "No-show" : "Under 48h";
                        const cls    = tier === "full" ? "bg-green-100 text-green-700 border-green-200" : "bg-amber-100 text-amber-700 border-amber-200";
                        return (
                          <p className="text-[11px] mt-0.5 max-w-[220px]">
                            <span className={`inline-block rounded-full border px-2 py-0.5 font-semibold ${cls}`}>{label}</span>
                            {kept > 0 && <span className="text-amber-700 font-semibold"> {fmt(kept)} deposit kept</span>}
                            {r.forfeitWaived && <span className="text-blue-600 font-semibold" title={r.forfeitWaivedReason || ""}> forfeit waived</span>}
                          </p>
                        );
                      })()}
                      {Array.isArray(r.parts) && r.parts.length > 0 && (
                        <div className="mt-1 space-y-0.5">
                          {r.parts.map((pt, i) => (
                            <p key={i} className="text-[11px] text-gray-500">
                              {pt.kind === "balance" ? "Balance" : "Deposit"} {fmt(pt.amount)} —{" "}
                              <span className={pt.status === "succeeded" ? "text-green-600" : pt.status === "failed" ? "text-red-600" : "text-blue-600"}>
                                {pt.status === "succeeded" ? "refunded" : pt.status === "failed" ? "failed" : "processing"}
                              </span>
                            </p>
                          ))}
                        </div>
                      )}
                      {Number(r.unrefundableAmount) > 0 && (
                        <p className="text-[11px] mt-0.5 text-red-600 font-semibold max-w-[240px]" title="Paid online, but no PayMongo payment ID is on record, so this can't be refunded through PayMongo. It is not a hand-back.">
                          {fmt(r.unrefundableAmount)} not refunded — Payment ID does not exist
                        </p>
                      )}
                      {r.manualRefund && (
                        <p className={`text-[11px] mt-0.5 ${r.manualRefund.issued ? "text-green-600" : "text-orange-600 font-semibold"}`}>
                          {fmt(r.manualRefund.amount)} in person — {r.manualRefund.issued ? `handed back${r.manualRefund.method ? ` (${r.manualRefund.method})` : ""}` : "not yet handed back"}
                        </p>
                      )}
                    </td>
                    <td className="px-5 py-4 whitespace-nowrap">
                      {(() => {
                        // Pending: live preview. Resolved: what was saved when the request was made.
                        const tier = r.status === "Pending" && r.planPreview ? r.planPreview.tier : r.policyTier;
                        const kept = r.status === "Pending" && r.planPreview ? r.planPreview.forfeit : Number(r.depositForfeited) || 0;
                        // Rejected = nothing is refunded, so there is no deposit decision. No tier = older request from before the 48-hour rule.
                        if (r.status === "Rejected" || !tier) return <span className="text-gray-300">—</span>;
                        if (kept > 0) {
                          return <span className="inline-block rounded-full border border-amber-200 bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700" title={`${fmt(kept)} deposit kept`}>Kept</span>;
                        }
                        return (
                          <span className="inline-flex items-center gap-1">
                            <span className="inline-block rounded-full border border-green-200 bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700">Not kept</span>
                            {r.forfeitWaived && <span className="text-[11px] font-semibold text-blue-600" title={r.forfeitWaivedReason || ""}>waived</span>}
                          </span>
                        );
                      })()}
                    </td>
                    <td className="px-5 py-4 whitespace-nowrap"><DateCell date={toDate(r.createdAt)} /></td>
                    <td className="px-5 py-4 whitespace-nowrap"><DateCell date={updatedDate(r)} /></td>
                    <td className="px-5 py-4">
                      <StatusBadge status={r.status} stage={stageOf(r)} />
                      {r.status === "Approved" && (() => {
                        const w = fmtWaiting(r);
                        return w ? (
                          <p className={`mt-1 text-[11px] ${w.late ? "font-semibold text-amber-600" : "text-gray-400"}`}>
                            Waiting {w.text}{w.late ? " — worth checking" : ""}
                          </p>
                        ) : null;
                      })()}
                    </td>
                    {showActions && (
                      <td className="px-5 py-4 text-right">
                        {r.status === "Pending" ? (
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => startApprove(r)}
                              disabled={busyId === r.refundRequestID}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
                            >
                              <IconCheck /> {busyId === r.refundRequestID ? "…" : "Approve"}
                            </button>
                            <button
                              onClick={() => { setRejectTarget(r); setRejectReason(""); }}
                              disabled={busyId === r.refundRequestID}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-600 border border-red-200 hover:bg-red-50 disabled:opacity-50"
                            >
                              <IconX /> Reject
                            </button>
                          </div>
                        ) : r.status === "Approved" ? (
                          <div className="flex flex-col items-end gap-1.5">
                            {stageOf(r) === "paymongo" && <span className="text-xs text-gray-400 italic">Waiting for PayMongo…</span>}
                            {handbackDue(r) > 0 && (
                              <div className="flex items-center gap-1.5">
                                <select
                                  value={handbackMethod[r.refundRequestID] || "Cash"}
                                  onChange={(e) => setHandbackMethod((m) => ({ ...m, [r.refundRequestID]: e.target.value }))}
                                  className="rounded-lg border border-gray-200 px-2 py-1 text-xs"
                                >
                                  <option>Cash</option><option>GCash</option><option>Bank Transfer</option>
                                </select>
                                <button
                                  onClick={() => markHandedBack(r)}
                                  disabled={busyId === r.refundRequestID}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-orange-500 hover:bg-orange-600 disabled:opacity-50"
                                  title="Confirm you handed this amount back to the customer in person"
                                >
                                  <IconCheck /> {busyId === r.refundRequestID ? "…" : `Handed back ${fmt(handbackDue(r))}`}
                                </button>
                              </div>
                            )}
                          </div>
                        ) : r.status === "Failed" ? (
                          <span className="text-xs text-red-500 italic">Needs manual follow-up</span>
                        ) : (
                          <span className="text-xs text-gray-300">—</span>
                        )}
                      </td>
                    )}
                  </tr>
                  </Fragment>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <Pagination page={page} totalPages={totalPages} onChange={setPage} start={start} pageSize={PAGE_SIZE} count={count} />
      </div>
    </div>
  );
}