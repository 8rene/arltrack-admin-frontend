import { useEffect, useState, useCallback, Fragment } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useCurrency } from "../context/CurrencyContext";
import PaymentEntriesPanel from "../components/shared/PaymentEntriesPanel";

// ─── SVG ICONS ─────────────────────────────────────────────────────────────

const IconCheck = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconX = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

// ─── HELPERS ────────────────────────────────────────────────────────────────

const statusDot = {
  Pending:  "bg-yellow-400",
  Approved: "bg-blue-500",
  Refunded: "bg-green-500",
  Rejected: "bg-red-500",
  Failed:   "bg-red-500",
};
const statusBg = {
  Pending:  "bg-yellow-50 border border-yellow-200",
  Approved: "bg-blue-50 border border-blue-200",
  Refunded: "bg-green-50 border border-green-200",
  Rejected: "bg-red-50 border border-red-200",
  Failed:   "bg-red-50 border border-red-200",
};
// "Approved" is stored as-is, but it is a WAITING state, not a finished one: the booking is
// cancelled and PayMongo has been asked to refund, yet the money isn't back until PayMongo
// confirms (and staff hand back any in-person part). So the screen shows what it is waiting on:
//   paymongo → a refund part hasn't been confirmed by PayMongo yet
//   handback → every online part is done, only the in-person cash is left for staff to hand back
const WAIT_STAGE = {
  paymongo: { label: "Waiting for PayMongo",  dot: "bg-blue-500",   bg: "bg-blue-50 border border-blue-200",     tip: "Approved — waiting for PayMongo to confirm the refund." },
  handback: { label: "Waiting for hand-back", dot: "bg-orange-500", bg: "bg-orange-50 border border-orange-200", tip: "Approved — the online part is done; the in-person amount still has to be handed back." },
};
const stageOf = (r) => {
  if (!r || r.status !== "Approved") return null;
  const parts = Array.isArray(r.parts) ? r.parts : [];
  const onlinePending = parts.length === 0 || parts.some((x) => x.status !== "succeeded"); // older requests without parts → assume PayMongo
  const handbackPending = !!(r.manualRefund && !r.manualRefund.issued);
  if (onlinePending) return "paymongo";
  return handbackPending ? "handback" : "paymongo";
};
const handbackDue = (r) => (r && r.status === "Approved" && r.manualRefund && !r.manualRefund.issued ? Number(r.manualRefund.amount) || 0 : 0);

// A staff discount on the same payment is money going back to the customer too, and it waits on PayMongo like this
// refund does. While it is still processing (or failed) the server refuses to approve, so the button says why.
const DISCOUNT_WAIT = {
  processing:        { label: "Discount refund waiting for PayMongo", cls: "text-blue-700" },
  failed:            { label: "Discount refund failed — retry it on Payments", cls: "text-red-600 font-semibold" },
  awaiting_handback: { label: "Discount to hand back in store", cls: "text-orange-600" },
  refunded:          { label: "Discount refunded", cls: "text-green-700" },
};
const discountBlocksApproval = (r) => !!(r && r.discount && r.discount.refund && ["processing", "failed"].includes(r.discount.refund.state));

function StatusBadge({ status, stage }) {
  const w   = stage ? WAIT_STAGE[stage] : null;
  const dot = w ? w.dot : (statusDot[status] || "bg-gray-400");
  const bg  = w ? w.bg  : (statusBg[status]  || "bg-gray-50 border border-gray-200");
  return (
    <span title={w ? w.tip : undefined} className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full text-black ${bg}`}>
      <span className={`w-2 h-2 rounded-full shrink-0 ${dot}`} />
      {w ? w.label : status}
    </span>
  );
}

// How long an approved refund has been waiting (since it was approved). Lets stuck ones stand out.
const waitStartMs = (r) => {
  const d = r.processedAt || r.updatedAt;
  const t = d && d.toDate ? d.toDate() : d ? new Date(d) : null;
  return t && !isNaN(t) ? t.getTime() : 0;
};
const fmtWaiting = (r) => {
  const t = waitStartMs(r);
  if (!t) return null;
  const hours = Math.max(0, (Date.now() - t) / 3600000);
  return { text: hours < 48 ? `${Math.max(1, Math.floor(hours))}h` : `${Math.floor(hours / 24)}d`, late: hours >= 72 };
};

// "Active" = still an open queue item admin needs to act on or is waiting
// on PayMongo for. "History" = resolved, permanent record — money already
// moved (or definitively didn't). Tab lives above the status chips; the
// chips themselves narrow further within whichever tab is selected.
const PAGE_SIZE = 15;

// --- PAGINATION (same pattern as Bookings.jsx / Payments.jsx / Users.jsx) -----
function usePagination(items, pageSize = PAGE_SIZE) {
  const [page, setPage] = useState(1);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  // Clamp if the list shrinks (filter/search/refresh) and we were on a now-empty page.
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;
  const pageItems = items.slice(start, start + pageSize);
  return { page: safePage, setPage, totalPages, pageItems, start, count: items.length };
}

function Pagination({ page, totalPages, onChange, start, pageSize, count }) {
  if (totalPages <= 1) return null;

  const nums = [];
  const add = (n) => nums.push(n);
  add(1);
  for (let n = page - 1; n <= page + 1; n++) if (n > 1 && n < totalPages) add(n);
  if (totalPages > 1) add(totalPages);
  const dedup = [...new Set(nums)].sort((a, b) => a - b);

  const rangeEnd = Math.min(start + pageSize, count);

  return (
    <div className="flex items-center justify-between px-5 py-3 border-t bg-gray-50/50">
      <p className="text-xs text-gray-400">
        Showing {count === 0 ? 0 : start + 1}–{rangeEnd} of {count}
      </p>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange(Math.max(1, page - 1))} disabled={page === 1}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Prev
        </button>
        {dedup.map((n, i) => (
          <span key={n} className="flex items-center">
            {i > 0 && n - dedup[i - 1] > 1 && <span className="px-1.5 text-gray-300 text-xs">…</span>}
            <button onClick={() => onChange(n)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                n === page ? "bg-teal-600 text-white shadow" : "border text-gray-600 hover:bg-white"
              }`}>
              {n}
            </button>
          </span>
        ))}
        <button onClick={() => onChange(Math.min(totalPages, page + 1))} disabled={page === totalPages}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Next
        </button>
      </div>
    </div>
  );
}

// Three tabs, split by WHO has to act:
//   Request Pending  a customer asked; staff must approve or reject
//   Under Process    money is on its way back (PayMongo confirming / cash to hand back), or something failed and needs
//                    a person. Refund requests AND discount refunds both live here: both wait on PayMongo.
//   History          finished: refunded or rejected
const DISCOUNT_STATES = { processing: "paymongo", awaiting_handback: "handback", failed: "failed", refunded: "done" };
// "Discount" rows and "deposit return" rows are both money that went (or is going) back through PayMongo and carry a
// `refund` object, so every place that handles `isDiscount` handles both. isDeposit tells them apart for wording and actions.
const isDeposit  = (r) => !!r && r.kind === "deposit";
const isDiscount = (r) => !!r && (r.kind === "discount" || r.kind === "deposit");
// Which tab an item belongs to.
const tabOf = (r) => {
  if (isDiscount(r)) return r.refund.state === "refunded" ? "history" : "processing";
  if (r.status === "Pending") return "pending";
  if (r.status === "Approved" || r.status === "Failed") return "processing";   // a Failed request needs manual follow-up: not history
  return "history";
};
// What an item is waiting on: the sub-filter inside Under Process.
const waitKeyOf = (r) => {
  if (isDiscount(r)) return DISCOUNT_STATES[r.refund.state];
  if (r.status === "Failed") return "failed";
  if (r.status === "Approved") return stageOf(r);
  return null;
};
const TABS = [
  { key: "pending",    label: "Request Pending", chips: [] },
  { key: "processing", label: "Under Process",   chips: [
    { key: "paymongo", label: "Waiting for PayMongo" }, { key: "handback", label: "Waiting for hand-back" }, { key: "failed", label: "Failed" } ] },
  { key: "history",    label: "History",         chips: [
    { key: "Refunded", label: "Refunded" }, { key: "Rejected", label: "Rejected" } ] },
];
const chipMatches = (tab, chip, r) => {
  if (chip === "All") return true;
  if (tab === "processing") return waitKeyOf(r) === chip;
  if (tab === "history") return (isDiscount(r) ? "Refunded" : r.status) === chip;
  return true;
};
// A discount refund shaped like a request row, so the table, search, sort and tabs treat both the same way.
const toDiscountItem = (d) => ({ ...d, kind: "discount", refundRequestID: `discount_${d.paymentID}`, amount: d.refund.amount, createdAt: d.discountAt, updatedAt: d.refund.at, status: d.refund.state });

// A security-deposit return sent through PayMongo, shaped the same way.
const toDepositItem = (d) => ({ ...d, kind: "deposit", refundRequestID: `deposit_${d.paymentID}`, amount: d.refund.amount, discountAmount: 0, updatedAt: d.refund.at, status: d.refund.state });

// A discount that sent money back, as a row. Same columns and the same stages as a refund request, so the two read alike.
const DISCOUNT_BADGE = {
  processing:        { label: "Waiting for PayMongo",  dot: "bg-blue-500",   bg: "bg-blue-50 border border-blue-200" },
  awaiting_handback: { label: "Waiting for hand-back", dot: "bg-orange-500", bg: "bg-orange-50 border border-orange-200" },
  failed:            { label: "Refund failed",         dot: "bg-red-500",    bg: "bg-red-50 border border-red-200" },
  refunded:          { label: "Refunded",              dot: "bg-green-500",  bg: "bg-green-50 border border-green-200" },
};
const DiscountBadge = ({ state }) => {
  const b = DISCOUNT_BADGE[state] || DISCOUNT_BADGE.processing;
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full text-black ${b.bg}`}>
      <span className={`w-2 h-2 rounded-full shrink-0 ${b.dot}`} />{b.label}
    </span>
  );
};

// ── what the table and the View modal both read ──
const updatedOf = (r) => (isDiscount(r) ? toDate(r.refund.at) : updatedDate(r));
// 48-hour policy outcome. Pending: the live preview. Otherwise: what was saved when the request was made.
const policyOf = (r) => {
  const pv = r.status === "Pending" ? r.planPreview : null;
  const tier = pv ? pv.tier : (r.policyTier || (typeof r.returnDeposit === "boolean" ? (r.returnDeposit ? "full" : "late") : null));
  return { tier, kept: pv ? Number(pv.forfeit) || 0 : Number(r.depositForfeited) || 0, hours: pv ? pv.hoursBeforePickup : null };
};
const TIER_LABEL = { full: "Full refund", late: "Under 48h", no_show: "No-show" };

function TypeBadge({ r }) {
  if (isDeposit(r)) return <span className="inline-block rounded-full border border-teal-200 bg-teal-50 px-2 py-0.5 text-xs font-semibold text-teal-700">Deposit return</span>;
  if (isDiscount(r)) return <span className="inline-block rounded-full border border-purple-200 bg-purple-50 px-2 py-0.5 text-xs font-semibold text-purple-700">Discount</span>;
  const { tier } = policyOf(r);
  if (!tier) return <span className="inline-block rounded-full border border-gray-200 bg-gray-50 px-2 py-0.5 text-xs font-semibold text-gray-600">{r.source === "staff" ? "Staff cancel" : "Refund"}</span>;
  const cls = tier === "full" ? "bg-green-100 text-green-700 border-green-200" : "bg-amber-100 text-amber-700 border-amber-200";
  return <span className={`inline-block rounded-full border px-2 py-0.5 text-xs font-semibold ${cls}`}>{TIER_LABEL[tier] || "Under 48h"}</span>;
}

// "Oct 17, 2026 | 3:45 PM" — date and time in one cell, split by a pipe.
const stampText = (d) => { const p = stampParts(d); return p ? `${p.date} | ${p.time}` : "—"; };
const Stamp = ({ date }) => {
  const p = stampParts(date);
  if (!p) return <span className="text-gray-300">—</span>;
  return (
    <span className="whitespace-nowrap text-sm">
      <span className="text-gray-700">{p.date}</span>
      <span className="mx-1.5 text-gray-300">|</span>
      <span className="text-gray-500">{p.time}</span>
    </span>
  );
};

// One labelled line in the View modal.
const Line = ({ label, children }) => (
  <div className="flex items-start justify-between gap-4 py-1.5 text-sm">
    <span className="text-gray-500 shrink-0">{label}</span>
    <span className="text-right text-gray-800 min-w-0 break-words">{children}</span>
  </div>
);
const Block = ({ title, children }) => (
  <div className="rounded-xl border border-gray-100 p-4">
    <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">{title}</p>
    {children}
  </div>
);

// Everything about one refund / discount refund. The table stays simple; the detail, the money movements and the
// actions (approve, reject, hand back, retry) all live here.
function RefundViewModal({ r, fmt, navigate, onClose, onApprove, onReject, onHandback, handbackMethod, setHandbackMethod, busy, onRetry, retrying }) {
  const disc = isDiscount(r);
  const pv = !disc && r.status === "Pending" ? r.planPreview : null;
  const { tier, kept, hours } = disc ? {} : policyOf(r);
  const w = (disc ? r.refund.state !== "refunded" : r.status === "Approved") ? fmtWaiting(r) : null;
  const due = disc ? 0 : handbackDue(r);
  const blocked = !disc && discountBlocksApproval(r);
  const when = hours !== null && hours !== undefined ? `${Math.max(0, Math.round(hours * 10) / 10)} hours before pickup` : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-start justify-between gap-3 px-6 pt-5 pb-4 border-b border-gray-100">
          <div className="min-w-0">
            <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400">{isDeposit(r) ? "Deposit return" : disc ? "Discount refund" : "Refund request"}</p>
            <h3 className="font-bold text-arl-dark text-lg truncate">{r.customerName || "—"}</h3>
            <div className="mt-1.5">{disc ? <DiscountBadge state={r.refund.state} /> : <StatusBadge status={r.status} stage={stageOf(r)} />}</div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><IconX /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3">
          <Block title="Summary">
            <Line label="Booking">
              {r.bookingID ? <button onClick={() => navigate(`/bookings?search=${encodeURIComponent(r.bookingID)}`)} className="font-medium text-teal-600 hover:underline">{r.bookingID}</button> : "—"}
            </Line>
            <Line label="Type"><TypeBadge r={r} /></Line>
            <Line label="Amount"><span className="font-semibold">{fmt(pv ? pv.total : disc ? r.refund.amount : r.amount)}</span></Line>
            <Line label="Requested">{stampText(toDate(r.createdAt))}</Line>
            <Line label="Updated">{stampText(updatedOf(r))}</Line>
            {w && <Line label="Waiting"><span className={w.late ? "font-semibold text-amber-600" : ""}>{w.text}{w.late ? " — worth checking" : ""}</span></Line>}
            <Line label={isDeposit(r) ? "Reason" : disc ? "Discount reason" : "Reason"}>{isDeposit(r) ? "Security deposit returned after the trip" : disc ? (r.discountReason || "Staff discount") : ((r.customerReason !== undefined ? r.customerReason : r.reason) || "—")}</Line>
            {!disc && r.notes && <Line label="Notes">{r.notes}</Line>}
            {!disc && r.status === "Rejected" && r.rejectReason && <Line label="Rejected because"><span className="text-red-600">{r.rejectReason}</span></Line>}
          </Block>

          {disc ? (
            <Block title={isDeposit(r) ? "Deposit return" : "Discount"}>
              {!isDeposit(r) && <Line label="Discount given">{fmt(r.discountAmount)}</Line>}
              <Line label={isDeposit(r) ? "Returned to customer" : "Sent back to customer"}>{fmt(r.refund.amount)} {r.refund.via === "in_store" ? "in store" : "via PayMongo"}</Line>
              {r.refund.referenceNumber && r.refund.via === "paymongo" && <Line label="PayMongo ref"><span className="font-mono text-xs">{r.refund.referenceNumber}</span></Line>}
              {r.refund.state === "failed" && <p className="text-xs text-red-600 mt-2">PayMongo could not complete this refund, so the customer has not received it.{r.refund.errorNote ? ` (${r.refund.errorNote})` : ""}</p>}
              {r.refund.state === "processing" && <p className="text-xs text-blue-700 mt-2">PayMongo is processing this refund. It can take up to 24 hours.</p>}
              {isDeposit(r) && r.refund.state === "failed" && <p className="text-xs text-gray-500 mt-1">The deposit is already settled. Retry the PayMongo refund, or hand the money back in store and record it here. Check your PayMongo payout balance if it keeps failing.</p>}
              {r.refund.state === "awaiting_handback" && <p className="text-xs text-orange-700 mt-2">Paid in store, so it can't go through PayMongo. Return it in store, then record it on the payment.</p>}
            </Block>
          ) : (
            <>
              {(tier || kept > 0) && (
                <Block title="Deposit">
                  {tier && <Line label="Policy"><TypeBadge r={r} /></Line>}
                  {when && <Line label="Requested">{when}</Line>}
                  <Line label="Deposit">
                    {kept > 0
                      ? <span className="font-semibold text-amber-700">{fmt(kept)} kept (48-hour policy)</span>
                      : <span className="text-green-700 font-semibold">Not kept{r.forfeitWaived ? " — forfeit waived" : ""}</span>}
                  </Line>
                  {r.forfeitWaived && r.forfeitWaivedReason && <Line label="Waived because">{r.forfeitWaivedReason}</Line>}
                </Block>
              )}

              {(pv || (Array.isArray(r.parts) && r.parts.length > 0) || r.manualRefund || Number(r.unrefundableAmount) > 0) && (
                <Block title="Where the money goes">
                  {pv && (
                    <>
                      <Line label="Customer paid">{fmt(pv.bookingPaid ?? pv.grossPaid)}</Line>
                      {pv.forfeit > 0 && <Line label="Deposit kept"><span className="text-amber-700">−{fmt(pv.forfeit)}</span></Line>}
                      <Line label="Via PayMongo">{fmt(pv.onlineAmount)}</Line>
                      {pv.manualAmount > 0 && <Line label="Hand back in person"><span className="text-orange-600 font-semibold">{fmt(pv.manualAmount)}</span></Line>}
                      {pv.unrefundableAmount > 0 && <Line label="Not refundable"><span className="text-red-600 font-semibold">{fmt(pv.unrefundableAmount)} — Payment ID does not exist</span></Line>}
                      {pv.total !== r.amount && <p className="text-[11px] text-gray-400 mt-1">Was {fmt(r.amount)} when requested.</p>}
                    </>
                  )}
                  {Array.isArray(r.parts) && r.parts.map((pt, i) => (
                    <Line key={i} label={`${pt.kind === "balance" ? "Balance" : "Deposit"} ${fmt(pt.amount)}`}>
                      <span className={pt.status === "succeeded" ? "text-green-600" : pt.status === "failed" ? "text-red-600" : "text-blue-600"}>
                        {pt.status === "succeeded" ? "refunded" : pt.status === "failed" ? "failed" : "processing at PayMongo"}
                      </span>
                    </Line>
                  ))}
                  {r.manualRefund && (
                    <Line label={`In person ${fmt(r.manualRefund.amount)}`}>
                      <span className={r.manualRefund.issued ? "text-green-600" : "text-orange-600 font-semibold"}>
                        {r.manualRefund.issued ? `handed back${r.manualRefund.method ? ` (${r.manualRefund.method})` : ""}` : "not yet handed back"}
                      </span>
                    </Line>
                  )}
                  {!pv && Number(r.unrefundableAmount) > 0 && <Line label="Not refunded"><span className="text-red-600 font-semibold">{fmt(r.unrefundableAmount)} — Payment ID does not exist</span></Line>}
                </Block>
              )}

              {r.discount && DISCOUNT_WAIT[r.discount.refund.state] && (
                <Block title="Discount on this payment">
                  <Line label="Discount given">{fmt(r.discount.amount)}</Line>
                  <Line label="Its refund">
                    <button type="button" onClick={() => navigate(`/payments?paymentID=${encodeURIComponent(r.paymentID)}`)} className={`hover:underline ${DISCOUNT_WAIT[r.discount.refund.state].cls}`}>
                      {DISCOUNT_WAIT[r.discount.refund.state].label}
                    </button>
                  </Line>
                </Block>
              )}
            </>
          )}

          <Block title="Money movements">
            <PaymentEntriesPanel
              key={`${r.refundRequestID}-${disc ? r.refund.state : r.status}`}
              query={disc ? { paymentID: r.paymentID } : { refundRequestID: r.refundRequestID }}
              title=""
            />
          </Block>
        </div>

        <div className="shrink-0 border-t border-gray-100 px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            {!disc && r.status === "Pending" && (
              <>
                <button onClick={onApprove} disabled={busy || blocked}
                  className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-green-600 hover:bg-green-700 disabled:opacity-50">
                  <IconCheck /> {busy ? "…" : "Approve"}
                </button>
                <button onClick={onReject} disabled={busy}
                  className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold text-red-600 border border-red-200 hover:bg-red-50 disabled:opacity-50">
                  <IconX /> Reject
                </button>
                {blocked && <span className="text-xs text-blue-700 max-w-[260px]">Approving is on hold until the discount refund is confirmed by PayMongo (or retried on Payments).</span>}
              </>
            )}
            {!disc && r.status === "Approved" && stageOf(r) === "paymongo" && <span className="text-xs text-gray-400 italic">Waiting for PayMongo…</span>}
            {!disc && due > 0 && (
              <>
                <select value={handbackMethod || "Cash"} onChange={(e) => setHandbackMethod(e.target.value)} className="rounded-lg border border-gray-200 px-2 py-2 text-sm">
                  <option>Cash</option><option>GCash</option><option>Bank Transfer</option>
                </select>
                <button onClick={onHandback} disabled={busy} title="Confirm you handed this amount back to the customer in person"
                  className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-orange-500 hover:bg-orange-600 disabled:opacity-50">
                  <IconCheck /> {busy ? "…" : `Handed back ${fmt(due)}`}
                </button>
              </>
            )}
            {!disc && r.status === "Failed" && <span className="text-xs text-red-500 italic">Needs manual follow-up</span>}
            {isDeposit(r) && r.refund.state === "failed" && (
              <>
                <select value={handbackMethod || "Cash"} onChange={(e) => setHandbackMethod(e.target.value)} className="rounded-lg border border-gray-200 px-2 py-2 text-sm">
                  <option>Cash</option><option>GCash</option><option>Maya</option><option>Bank Transfer</option>
                </select>
                <button onClick={onHandback} disabled={busy || retrying} title="Confirm you handed the deposit back to the customer in store"
                  className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-semibold text-white bg-orange-500 hover:bg-orange-600 disabled:opacity-50">
                  <IconCheck /> {busy ? "…" : `Handed back ${fmt(r.refund.amount)}`}
                </button>
              </>
            )}
            {disc && r.refund.state === "failed" && (
              <button onClick={onRetry} disabled={retrying} className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-red-600 hover:bg-red-700 disabled:opacity-50">
                {retrying ? "…" : `Retry ${fmt(r.refund.amount)} refund`}
              </button>
            )}
            {disc && r.refund.state === "awaiting_handback" && (
              <button onClick={() => navigate(`/payments?paymentID=${encodeURIComponent(r.paymentID)}`)} className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-orange-500 hover:bg-orange-600">
                Record hand-back →
              </button>
            )}
          </div>
          <button onClick={onClose} className="px-4 py-2 rounded-xl border text-sm hover:bg-gray-50">Close</button>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN COMPONENT ─────────────────────────────────────────────────────────

// ─── SORT HEADER ────────────────────────────────────────────────────────────
// Same clickable <th> as Bookings/Users: toggles asc/desc, neutral chevrons when
// the column isn't the active sort. (px-5 here to line up with this table's cells.)
const IconChevronsUpDown = ({ className = "w-3.5 h-3.5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7 15l5 5 5-5M7 9l5-5 5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconSortArrow = ({ dir, className = "w-3.5 h-3.5" }) => (
  <svg
    className={`${className} transition-transform ${dir === "desc" ? "rotate-180" : ""}`}
    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M12 19V5M5 12l7-7 7 7" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

function SortableTh({ label, sortKey: key, sortKeyState, sortDir, onSort, className = "" }) {
  const active = sortKeyState === key;
  return (
    <th className={`px-5 py-3 text-left select-none ${className}`}>
      <button
        onClick={() => onSort(key)}
        className={`flex items-center gap-1.5 uppercase tracking-wider text-xs font-semibold px-2 py-1 -mx-2 rounded-lg transition-colors ${
          active ? "text-teal-700 bg-teal-50" : "text-gray-400 hover:text-gray-700 hover:bg-gray-100"
        }`}
      >
        {label}
        {active ? <IconSortArrow dir={sortDir} /> : <IconChevronsUpDown />}
      </button>
    </th>
  );
}

// ─── DATES ──────────────────────────────────────────────────────────────────
// createdAt / updatedAt / processedAt come back from the API as Firestore
// timestamps ({_seconds}) — or ISO strings, depending on the path.
const toDate = (val) => {
  if (!val) return null;
  let d;
  if (typeof val.toDate === "function") d = val.toDate();
  else if (val._seconds !== undefined)  d = new Date(val._seconds * 1000);
  else if (val.seconds !== undefined)   d = new Date(val.seconds * 1000);
  else d = new Date(val);
  return isNaN(d.getTime()) ? null : d;
};
const toMillis = (d) => (d ? d.getTime() : -Infinity);

// "Updated" only means something once the request changed after it was filed;
// a still-untouched Pending request shows "—" instead of repeating the request date.
// Keyed off status, not a time gap — a quick Approve/Reject right after filing
// is still a real change and must show its own Updated date.
const updatedDate = (r) => {
  if (r.status === "Pending") return null;
  return toDate(r.updatedAt) || toDate(r.processedAt);
};

const stampParts = (d) => d && ({
  date: d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" }),
  time: d.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" }),
});

export default function RefundRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [tab, setTab]           = useState(null);          // null until the list loads, then the most useful tab (see below)
  const [depositReturns, setDepositReturns] = useState([]);   // security deposits sent back through PayMongo
  const [discounts, setDiscounts] = useState([]);           // discount refunds (money a staff discount sent back)
  const [retryingId, setRetryingId] = useState(null);
  const [viewId, setViewId]   = useState(null);   // refundRequestID of the item open in the View modal
  const [statusF, setStatusF]   = useState("All");
  const [search, setSearch]     = useState("");
  const [toast, setToast]       = useState(null);
  const [busyId, setBusyId]     = useState(null);
  const [rejectTarget, setRejectTarget] = useState(null); // request being rejected
  const [rejectReason, setRejectReason] = useState("");
  // Approving a request that carries a 48-hour deposit forfeit opens a confirmation
  // (with an optional, reason-required "waive the forfeit" override).
  const [approveTarget, setApproveTarget] = useState(null);
  const [waiveForfeit, setWaiveForfeit]   = useState(false);
  const [waiveReason, setWaiveReason]     = useState("");
  // Which method staff picked when handing the in-person part of a refund back, per request id.
  // Method staff pick when they hand the in-person part of a refund back, per request id (default Cash).
  const [handbackMethod, setHandbackMethod] = useState({});
  const [sortKey, setSortKey] = useState(null); // null = default/unsorted (API order: newest request first)
  const [sortDir, setSortDir] = useState("asc");
  const items = [...requests, ...discounts.map(toDiscountItem), ...depositReturns.map(toDepositItem)];

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const token = localStorage.getItem("token");
  const { fmt } = useCurrency();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Linked in with ?search=<refundRequestID | paymentID | bookingID> (e.g. Payments' "View refund request"): fills the
  // search bar and opens the tab the request is in (Active Queue or History), then strips the param. It waits for the
  // list to load so the right tab can be picked.
  useEffect(() => {
    const q = searchParams.get("search");
    if (!q) return;
    setSearch(q);
    const hit = items.find((r) => r.refundRequestID === q || r.paymentID === q || r.bookingID === q);
    if (hit) setTab(tabOf(hit));
    else if (loading) return;
    setSearchParams((prev) => { const n = new URLSearchParams(prev); n.delete("search"); return n; }, { replace: true });
  }, [searchParams, items, loading, setSearchParams]);

  const activeTab = TABS.find((t) => t.key === tab) || TABS[0];
  const tabKey = activeTab.key;

  const switchTab = (key) => {
    setTab(key);
    setStatusF("All"); // reset the sub-filter so switching tabs doesn't hide everything
  };

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchRequests = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to load refund requests.");
      setRequests(data.data || []);
      // Discount refunds ride along; if this part fails the requests still show.
      try {
        const dres = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/discount-refunds`, { headers: { Authorization: `Bearer ${token}` } });
        const ddata = await dres.json();
        setDiscounts(dres.ok ? (ddata.data || []) : []);
      } catch { setDiscounts([]); }
      // Deposit returns sent through PayMongo ride along the same way.
      try {
        const rres = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/deposit-returns`, { headers: { Authorization: `Bearer ${token}` } });
        const rdata = await rres.json();
        setDepositReturns(rres.ok ? (rdata.data || []) : []);
      } catch { setDepositReturns([]); }
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchRequests(); }, [fetchRequests]);

  // A request with a deposit forfeit asks for confirmation first; anything else approves straight away.
  const startApprove = (r) => {
    if (r.planPreview && r.planPreview.forfeit > 0) {
      setApproveTarget(r); setWaiveForfeit(false); setWaiveReason("");
    } else {
      approve(r.refundRequestID);
    }
  };

  const approve = async (id, opts = {}) => {
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/${id}/approve`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(opts.waiveForfeit ? { waiveForfeit: true, waiveReason: opts.waiveReason } : {}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to approve refund.");
      showToast(data.message || "Refund approved and sent to PayMongo.");
      // Approval can now change the amount (recomputed from what the customer has
      // actually paid), split it into PayMongo refunds + a manual part, and cancel the
      // booking — so take the server's version of the request rather than guessing.
      setRequests((prev) => prev.map((r) => r.refundRequestID === id ? { ...r, ...(data.data || {}), status: "Approved", planPreview: undefined } : r));
      setViewId(null);
    } catch (e) { showToast(e.message, "error"); fetchRequests(); }
    finally { setBusyId(null); setApproveTarget(null); }
  };

  // Staff confirm they physically handed the in-person part back. The backend finishes the
  // request (→ Refunded) once every PayMongo part has also succeeded.
  const markHandedBack = async (r) => {
    const id = r.refundRequestID;
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/${id}/manual-issued`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ method: handbackMethod[id] || "Cash" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to mark the refund as handed back.");
      showToast(data.message || "Marked as handed back.");
      setViewId(null);
      fetchRequests(); // status may have moved to Refunded (history) — take the server's version
    } catch (e) { showToast(e.message, "error"); }
    finally { setBusyId(null); }
  };

  // A discount's PayMongo refund failed: send it again (the failed attempt stays on record).
  const retryDiscount = async (r) => {
    setRetryingId(r.refundRequestID);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/booking/${encodeURIComponent(r.bookingID)}/discount-refund/retry`, {
        method: "PATCH", headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Could not retry the refund.");
      showToast("Refund sent to PayMongo again.");
      setViewId(null);
      fetchRequests();
    } catch (e) { showToast(e.message, "error"); }
    finally { setRetryingId(null); }
  };

  // A deposit return PayMongo refused: send it again (the failed attempt stays on record).
  const retryDeposit = async (r) => {
    setRetryingId(r.refundRequestID);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/bookings/${encodeURIComponent(r.bookingID)}/deposit-return/retry`, {
        method: "PATCH", headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok || data.success === false) throw new Error(data.message || "Could not retry the deposit return.");
      showToast("Deposit return sent to PayMongo again.");
      setViewId(null);
      fetchRequests();
    } catch (e) { showToast(e.message, "error"); fetchRequests(); }
    finally { setRetryingId(null); }
  };

  // The online return failed: staff handed the deposit back in store and record it.
  const handBackDeposit = async (r) => {
    const id = r.refundRequestID;
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/bookings/${encodeURIComponent(r.bookingID)}/deposit-return/handback`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ method: handbackMethod[id] || "Cash" }),
      });
      const data = await res.json();
      if (!res.ok || data.success === false) throw new Error(data.message || "Could not record the hand-back.");
      showToast("Deposit hand-back recorded.");
      setViewId(null);
      fetchRequests();
    } catch (e) { showToast(e.message, "error"); fetchRequests(); }
    finally { setBusyId(null); }
  };

  const submitReject = async () => {
    if (!rejectTarget) return;
    const id = rejectTarget.refundRequestID;
    setBusyId(id);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/refund-requests/${id}/reject`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ rejectReason }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to reject refund.");
      showToast("Refund request rejected.");
      setRequests((prev) => prev.map((r) => r.refundRequestID === id ? { ...r, status: "Rejected", rejectReason } : r));
      setRejectTarget(null); setRejectReason(""); setViewId(null);
    } catch (e) { showToast(e.message, "error"); }
    finally { setBusyId(null); }
  };

  const filtered = items.filter((r) => {
    const q = search.toLowerCase();
    const matchQ = !q
      || (r.refundRequestID || "").toLowerCase().includes(q)
      || (r.customerName || "").toLowerCase().includes(q)
      || (r.bookingID || "").toLowerCase().includes(q)
      || (r.paymentID || "").toLowerCase().includes(q);
    const matchTab = tabOf(r) === tabKey;
    const matchS = chipMatches(tabKey, statusF, r);
    return matchQ && matchTab && matchS;
  });

  // Numbered pagination (same shared component as Bookings/Payments). The hook
  // clamps the page if approving/rejecting shrinks the list underneath us.
  // Sort after search/tab/status filtering, before pagination, so Page 1 is the
  // top of whatever sort is active.
  const sorted = [...filtered].sort((a, b) => {
    if (!sortKey) {
      // Under Process: longest-waiting first, so stuck ones are on top
      if (tabKey === "processing") return waitStartMs(a) - waitStartMs(b);
      return 0;
    }
    if (sortKey === "customer") {
      const c = (a.customerName || "").localeCompare(b.customerName || "", undefined, { sensitivity: "base" });
      return sortDir === "asc" ? c : -c;
    }
    let av, bv;
    if (sortKey === "amount")         { av = Number(a.amount) || 0;             bv = Number(b.amount) || 0; }
    else if (sortKey === "requested") { av = toMillis(toDate(a.createdAt));     bv = toMillis(toDate(b.createdAt)); }
    else if (sortKey === "updated")   { av = toMillis(updatedOf(a));            bv = toMillis(updatedOf(b)); }
    else return 0;
    return sortDir === "asc" ? av - bv : bv - av;
  });

  const { page, setPage, totalPages, pageItems: paginated, start, count } = usePagination(sorted, PAGE_SIZE);
  useEffect(() => { setPage(1); }, [search, statusF, tabKey, sortKey, sortDir]); // eslint-disable-line react-hooks/exhaustive-deps


  const pendingCount    = items.filter((r) => tabOf(r) === "pending").length;
  const processingItems = items.filter((r) => tabOf(r) === "processing");
  const processingCount = processingItems.length;
  const failedCount     = processingItems.filter((r) => waitKeyOf(r) === "failed").length;

  // Open on the tab that needs someone: requests to review first, otherwise what is still in flight.
  useEffect(() => {
    if (tab === null && !loading) setTab(pendingCount > 0 ? "pending" : processingCount > 0 ? "processing" : "pending");
  }, [tab, loading, pendingCount, processingCount]);

  return (
    <div className="w-full px-4 space-y-5">

      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"
        }`}>{toast.msg}</div>
      )}

      {/* View: everything about one refund. Approve / reject / hand back / retry happen here. The approve and reject
          dialogs below open on top of it. */}
      {(() => {
        const v = viewId && items.find((x) => x.refundRequestID === viewId);
        if (!v) return null;
        return (
          <RefundViewModal
            r={v} fmt={fmt} navigate={navigate} onClose={() => setViewId(null)}
            onApprove={() => startApprove(v)}
            onReject={() => { setRejectTarget(v); setRejectReason(""); }}
            onHandback={() => (isDeposit(v) ? handBackDeposit(v) : markHandedBack(v))}
            handbackMethod={handbackMethod[v.refundRequestID]}
            setHandbackMethod={(m) => setHandbackMethod((x) => ({ ...x, [v.refundRequestID]: m }))}
            busy={busyId === v.refundRequestID}
            onRetry={() => (isDeposit(v) ? retryDeposit(v) : retryDiscount(v))} retrying={retryingId === v.refundRequestID}
          />
        );
      })()}

      {/* Approve confirmation: shows the 48-hour policy outcome + the staff override */}
      {approveTarget && approveTarget.planPreview && (() => {
        const pv = approveTarget.planPreview;
        const when = pv.tier === "no_show" ? "after the pickup time" : pv.hoursBeforePickup !== null && pv.hoursBeforePickup !== undefined ? `${Math.max(0, Math.round(pv.hoursBeforePickup * 10) / 10)} hours before pickup` : "under 48 hours before pickup";
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setApproveTarget(null)} />
            <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-arl-dark">Approve Refund</h3>
                <button onClick={() => setApproveTarget(null)} className="text-gray-400 hover:text-gray-600"><IconX /></button>
              </div>
              <p className="text-sm text-gray-500">{approveTarget.customerName}</p>
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm space-y-1">
                <p className="text-amber-800 font-semibold">Requested {when}</p>
                <div className="flex justify-between"><span className="text-gray-600">Customer paid</span><span className="font-semibold">{fmt(pv.grossPaid)}</span></div>
                <div className="flex justify-between text-amber-700"><span>Deposit kept (48-hour policy)</span><span className="font-semibold">-{fmt(waiveForfeit ? 0 : pv.forfeit)}</span></div>
                <div className="flex justify-between border-t border-black/10 pt-1"><span className="font-bold text-gray-800">Refund</span><span className="font-black">{fmt(waiveForfeit ? pv.grossPaid : pv.total)}</span></div>
              </div>
              <p className="text-[11px] text-gray-400">The timing is judged by when the customer sent the request, not by when you approve it.</p>
              <label className="flex items-start gap-2 text-sm text-gray-700 cursor-pointer">
                <input type="checkbox" className="mt-0.5" checked={waiveForfeit} onChange={(e) => setWaiveForfeit(e.target.checked)} />
                <span>Waive the deposit forfeit and refund the full {fmt(pv.grossPaid)} <span className="text-gray-400">(goodwill, duplicate charge, etc.)</span></span>
              </label>
              {waiveForfeit && (
                <textarea
                  value={waiveReason}
                  onChange={(e) => setWaiveReason(e.target.value)}
                  placeholder="Reason for waiving (required, saved in the audit log)"
                  rows={2}
                  className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-arl-dark/20"
                />
              )}
              <div className="flex justify-end gap-2">
                <button onClick={() => setApproveTarget(null)} className="px-4 py-2 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-100">Cancel</button>
                <button
                  onClick={() => approve(approveTarget.refundRequestID, { waiveForfeit, waiveReason })}
                  disabled={busyId === approveTarget.refundRequestID || (waiveForfeit && !waiveReason.trim())}
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
                >
                  {busyId === approveTarget.refundRequestID ? "Approving..." : "Confirm Approve"}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Reject reason modal */}
      {rejectTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setRejectTarget(null)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-arl-dark">Reject Refund Request</h3>
              <button onClick={() => setRejectTarget(null)} className="text-gray-400 hover:text-gray-600">
                <IconX />
              </button>
            </div>
            <p className="text-sm text-gray-500">
              {rejectTarget.customerName} — {fmt(rejectTarget.amount)}
            </p>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Reason for rejecting (optional, shown to customer)"
              rows={3}
              className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-arl-dark/20"
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setRejectTarget(null)} className="px-4 py-2 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-100">
                Cancel
              </button>
              <button
                onClick={submitReject}
                disabled={busyId === rejectTarget.refundRequestID}
                className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-red-500 hover:bg-red-600 disabled:opacity-50"
              >
                {busyId === rejectTarget.refundRequestID ? "Rejecting…" : "Confirm Reject"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <h1 className="text-xl font-bold text-arl-dark flex items-center gap-2">Refunds</h1>
          <p className="text-sm text-gray-500">
            {pendingCount > 0 ? `${pendingCount} request${pendingCount > 1 ? "s" : ""} to review` : "No requests to review"}
            {processingCount > 0 && <> · {processingCount} under process</>}
            {failedCount > 0 && <span className="text-red-600 font-semibold"> · {failedCount} failed — needs you</span>}
          </p>
        </div>
      </div>

      {/* Request Pending / Under Process / History */}
      <div className="flex gap-1 border-b border-gray-100">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => switchTab(t.key)}
            className={`px-4 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors ${
              tabKey === t.key ? "border-arl-dark text-arl-dark" : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            {t.label}
            {t.key === "pending" && pendingCount > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-yellow-100 text-yellow-700 text-[11px] font-bold" title="Needs review">{pendingCount}</span>
            )}
            {t.key === "processing" && processingCount > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-blue-100 text-blue-700 text-[11px] font-bold" title="Money on its way back, or needing follow-up">{processingCount}</span>
            )}
            {t.key === "processing" && failedCount > 0 && (
              <span className="ml-1 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded-full bg-red-100 text-red-600 text-[11px] font-bold" title="Failed — needs follow-up">{failedCount}!</span>
            )}
          </button>
        ))}
      </div>

      {/* What this tab means, in one line */}
      <p className="text-xs text-gray-400 -mt-2">
        {tabKey === "pending" && "Customers asking for a refund. Approve or reject each one."}
        {tabKey === "processing" && "Approved refunds and discount refunds whose money isn't back with the customer yet. PayMongo can take up to 24 hours; anything marked Failed needs a person."}
        {tabKey === "history" && "Finished: the money went back, or the request was rejected."}
      </p>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by customer, booking, or payment ID…"
          className="flex-1 min-w-[220px] rounded-xl border border-gray-200 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-arl-dark/20"
        />
        {activeTab.chips.length > 0 && (
          <div className="flex gap-2 flex-wrap">
            {[{ key: "All", label: "All" }, ...activeTab.chips].map((c) => (
              <button
                key={c.key}
                onClick={() => setStatusF(c.key)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
                  statusF === c.key ? "bg-arl-dark text-white border-arl-dark" : "bg-white text-gray-600 border-gray-200 hover:border-arl-dark"
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Table */}
      <div className="rounded-2xl border border-gray-100 bg-white shadow-soft overflow-hidden">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-10 text-center text-sm text-gray-400">Loading refund requests…</div>
          ) : error ? (
            <div className="p-10 text-center text-sm text-red-500">{error}</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-sm text-gray-400">
              {tabKey === "history" ? "No finished refunds yet." : tabKey === "processing" ? "Nothing is waiting on PayMongo or on a hand-back." : "No requests waiting for review."}
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider text-gray-400 border-b border-gray-100">
                  <SortableTh label="Requested" sortKey="requested" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <SortableTh label="Customer" sortKey="customer" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <th className="px-5 py-3 font-semibold">Booking</th>
                  <th className="px-5 py-3 font-semibold">Reason</th>
                  <SortableTh label="Amount" sortKey="amount" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <th className="px-5 py-3 font-semibold">Type</th>
                  <SortableTh label="Updated" sortKey="updated" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                  <th className="px-5 py-3 font-semibold">Status</th>
                  <th className="px-5 py-3 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((r) => {
                  const disc = isDiscount(r);
                  return (
                    <tr key={r.refundRequestID} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/60">
                      <td className="px-5 py-4"><Stamp date={toDate(r.createdAt)} /></td>
                      <td className="px-5 py-4"><p className="font-semibold text-arl-dark">{r.customerName || "—"}</p></td>
                      <td className="px-5 py-4">
                        {r.bookingID ? (
                          <button onClick={() => navigate(`/bookings?search=${encodeURIComponent(r.bookingID)}`)}
                            className="font-medium text-teal-600 hover:text-teal-700 hover:underline" title="Open this booking">{r.bookingID}</button>
                        ) : "—"}
                      </td>
                      <td className="px-5 py-4">
                        <p className="text-gray-700 max-w-[240px] truncate" title={isDeposit(r) ? "Security deposit return" : disc ? r.discountReason : (r.customerReason !== undefined ? r.customerReason : r.reason)}>
                          {isDeposit(r) ? "Security deposit return" : disc ? (r.discountReason || "Staff discount") : ((r.customerReason !== undefined ? r.customerReason : r.reason) || "—")}
                        </p>
                      </td>
                      <td className="px-5 py-4 font-semibold text-arl-dark whitespace-nowrap">
                        {fmt(disc ? r.refund.amount : (r.planPreview ? r.planPreview.total : r.amount))}
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap"><TypeBadge r={r} /></td>
                      <td className="px-5 py-4"><Stamp date={updatedOf(r)} /></td>
                      <td className="px-5 py-4">{disc ? <DiscountBadge state={r.refund.state} /> : <StatusBadge status={r.status} stage={stageOf(r)} />}</td>
                      <td className="px-5 py-4 text-right">
                        <button onClick={() => setViewId(r.refundRequestID)}
                          className="px-3 py-1 border rounded-lg text-xs hover:bg-gray-50">View</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <Pagination page={page} totalPages={totalPages} onChange={setPage} start={start} pageSize={PAGE_SIZE} count={count} />
      </div>
    </div>
  );
}