import { useState, useEffect, useCallback } from "react";

const API_URL = process.env.REACT_APP_API_URL;

const IconClock = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3 2" />
  </svg>
);

const IconPin = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s7-7.75 7-13a7 7 0 10-14 0c0 5.25 7 13 7 13z" />
    <circle cx="12" cy="8" r="2.5" />
  </svg>
);

const IconHistory = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 12a9 9 0 109-9 9 9 0 00-6.36 2.64L3 8" />
    <path strokeLinecap="round" d="M3 3v5h5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3 2" />
  </svg>
);

const fmtDateTime = (val) => {
  if (!val) return "—";
  const d = new Date(val);
  if (isNaN(d)) return "—";
  return d.toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
};

const STATUS_STYLE = {
  completed: "bg-blue-50 text-blue-700 border border-blue-200",
  cancelled: "bg-red-50 text-red-600 border border-red-200",
  stolen:    "bg-red-900 text-white",
};

export default function TripHistory() {
  const token = localStorage.getItem("token");

  const [trips, setTrips]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const fetchHistory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res  = await fetch(`${API_URL}/api/driver-dispatch/my-trips/history`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to load trip history.");
      setTrips(json.data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  return (
    <div className="w-full px-4 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-arl-dark">Trip History</h1>
          <p className="text-xs text-gray-400 mt-0.5">{loading ? "Loading…" : `${trips.length} past trip${trips.length === 1 ? "" : "s"}`}</p>
        </div>
        <button onClick={fetchHistory} disabled={loading}
          className="px-3 py-2 text-sm rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
          ↺ Refresh
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl p-3">{error}</div>
      )}

      {loading ? (
        <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>
      ) : trips.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-soft p-10 text-center">
          <IconHistory className="w-8 h-8 mx-auto text-gray-300 mb-2" />
          <p className="text-sm font-semibold text-arl-dark">No completed trips yet</p>
          <p className="text-xs text-gray-400 mt-1">Trips you've finished, cancelled, or flagged will show here.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {trips.map((trip) => (
            <div key={trip.id} className="bg-white rounded-2xl shadow-soft p-4 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-arl-dark">{trip.customerName}</span>
                    <span className={`text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-lg ${STATUS_STYLE[trip.status] || "bg-gray-100 text-gray-500"}`}>
                      {trip.status?.replace("_", " ")}
                    </span>
                    {trip.modeOfDriving === "With Chauffeur" && (
                      <span className="text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-lg bg-indigo-600 text-white">
                        Chauffeur
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">{trip.vehicleName}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                <span className="flex items-center gap-1"><IconClock /> {fmtDateTime(trip.startDateTime)} → {fmtDateTime(trip.endDateTime)}</span>
                <span className="flex items-center gap-1"><IconPin /> {trip.location}</span>
              </div>

              {trip.status === "completed" && (trip.pickupTime || trip.customerDroppedOffAt || trip.returnTime) && (
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-gray-400 bg-gray-50 rounded-lg px-2.5 py-1.5">
                  <span>Picked up: <span className="font-semibold text-gray-600">{fmtDateTime(trip.pickupTime)}</span></span>
                  {trip.modeOfDriving === "With Chauffeur" && (
                    <span>Dropped off: <span className="font-semibold text-gray-600">{trip.customerDroppedOffAt ? fmtDateTime(trip.customerDroppedOffAt) : "Not recorded"}</span></span>
                  )}
                  <span>Returned: <span className="font-semibold text-gray-600">{fmtDateTime(trip.returnTime)}</span></span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}