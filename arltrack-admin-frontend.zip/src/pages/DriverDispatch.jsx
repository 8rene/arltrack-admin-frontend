import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useSearchParams, useLocation, useNavigate } from "react-router-dom";

const API_URL = process.env.REACT_APP_API_URL;

// ─── SVG ICONS ───────────────────────────────────────────────────────────────

const IconSteering = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="2.5" />
    <path strokeLinecap="round" d="M12 3v6.5M12 14.5V21M4.2 7.5l5.6 3.2M14.2 13.3l5.6 3.2M19.8 7.5l-5.6 3.2M9.8 13.3l-5.6 3.2" />
  </svg>
);

const IconClock = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3 2" />
  </svg>
);

const IconWarning = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
    <line x1="12" y1="9" x2="12" y2="13" strokeLinecap="round" />
    <line x1="12" y1="17" x2="12.01" y2="17" strokeLinecap="round" />
  </svg>
);

const IconDots = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <circle cx="5" cy="12" r="1.8" />
    <circle cx="12" cy="12" r="1.8" />
    <circle cx="19" cy="12" r="1.8" />
  </svg>
);

const IconUser = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="8" r="3.5" />
    <path strokeLinecap="round" d="M4.5 20c1.2-3.5 4-5.5 7.5-5.5s6.3 2 7.5 5.5" />
  </svg>
);

// ─── HELPERS ─────────────────────────────────────────────────────────────────

const fmtDateTime = (val) => {
  if (!val) return "—";
  const d = new Date(val);
  if (isNaN(d)) return "—";
  return d.toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
};

const fmtDay = (val) => {
  const d = new Date(val);
  if (isNaN(d)) return "";
  return d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
};

// Rows per page — applies to both "Needs a Driver" and "Drivers". Real
// pagination (Prev/Next), not a "See more" that keeps appending to an
// ever-growing list.
const PAGE_SIZE = 10;

// Driver's-license note for the assign UI; null when there's nothing to warn about.
// (Comes from the board's `license` field — see driverDispatch.service.js.)
const licenseWarning = (lic) => {
  if (!lic) return null;
  if (lic.status === "expired") {
    return { level: "expired", short: "license expired",
             long: `Driver's license expired${lic.expiry ? ` on ${fmtDay(lic.expiry)}` : ""}.` };
  }
  if (lic.status === "expiring") {
    return { level: "expiring", short: `license expires in ${lic.daysLeft}d`,
             long: `Driver's license expires in ${lic.daysLeft} day${lic.daysLeft === 1 ? "" : "s"}.` };
  }
  return null;
};

// How one driver fits ONE booking's window, from GET /api/driver-dispatch/availability.
//   free = no clash · tight = gap shorter than the buffer (warning) · busy = real overlap (needs a reason)
const fmtGap = (mins) => {
  const m = Number(mins) || 0;
  if (m <= 0) return "no gap";
  const h = Math.floor(m / 60), r = m % 60;
  return [h ? `${h} h` : "", r ? `${r} min` : ""].filter(Boolean).join(" ");
};
const fitLabel = (fit) => {
  if (!fit) return "";
  if (fit.status === "busy")  return "busy — overlaps another trip";
  if (fit.status === "tight") return `tight — ${fmtGap(fit.conflict?.gapMinutes)} gap`;
  return "free";
};
const FIT_STYLES = {
  free:  "bg-green-50 text-green-700 border-green-200",
  tight: "bg-amber-50 text-amber-700 border-amber-200",
  busy:  "bg-red-50 text-red-700 border-red-200",
};
// A real overlap can only be forced with a typed reason; keep in step with OVERRIDE_REASON_MIN_LENGTH in the backend.
const OVERRIDE_REASON_MIN = 5;

const StatCard = ({ icon, value, label, color }) => {
  const colors = {
    red:    "bg-red-50 text-red-600",
    yellow: "bg-yellow-50 text-yellow-600",
    blue:   "bg-blue-50 text-blue-600",
    green:  "bg-green-50 text-green-600",
  };
  return (
    <div className="bg-white rounded-2xl shadow-soft p-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colors[color]}`}>{icon}</div>
      <div>
        <div className="text-lg font-bold text-arl-dark leading-none">{value}</div>
        <div className="text-xs text-gray-400 mt-1">{label}</div>
      </div>
    </div>
  );
};

// Real Prev/Next pagination — used by both "Needs a Driver" and "Drivers".
// Only renders once there's more than one page, so a short list (≤10) shows
// nothing extra.
function Pager({ page, totalPages, onChange }) {
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-between pt-1">
      <button type="button" onClick={() => onChange(page - 1)} disabled={page <= 1}
        className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40 disabled:hover:bg-transparent">
        ‹ Prev
      </button>
      <span className="text-xs text-gray-400">Page {page} of {totalPages}</span>
      <button type="button" onClick={() => onChange(page + 1)} disabled={page >= totalPages}
        className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40 disabled:hover:bg-transparent">
        Next ›
      </button>
    </div>
  );
}

export default function DriverDispatch() {
  const token = localStorage.getItem("token");
  const [searchParams] = useSearchParams();
  const highlightDriverID = searchParams.get("driver");
  const routerLocation = useLocation();
  const navigate        = useNavigate();

  // If we got here from "Assign Driver" / "Assign Driver First" on Car
  // Tracking, this holds the booking we're trying to assign a driver to —
  // same pattern as DeviceTrack.jsx's assignForCar. Kept in local state
  // (rather than read straight from routerLocation.state) so we can clear
  // it once the assignment succeeds without another navigation.
  const [assignForBooking, setAssignForBooking] = useState(
    routerLocation.state?.assignBookingId
      ? {
          bookingId: routerLocation.state.assignBookingId,
          customerName: routerLocation.state.assignCustomerName,
          carLabel: routerLocation.state.assignCarLabel,
        }
      : null
  );
  const cancelAssignMode = () => {
    setAssignForBooking(null);
    navigate(routerLocation.pathname, { replace: true, state: {} });
  };

  const [board, setBoard]       = useState({ drivers: [], unassigned: [], missingWhileOngoing: [] });
  const [loading, setLoading]   = useState(true);
  const [toast, setToast]       = useState(null);
  const [picked, setPicked]     = useState({});   // { [bookingDocID]: driverID }
  const [busyID, setBusyID]     = useState(null);  // bookingDocID currently being assigned/unassigned
  const [conflict, setConflict] = useState(null);  // { bookingDocID, driverID, message, conflictType, requiresReason, bufferMinutes }
  const [overrideReason, setOverrideReason] = useState(""); // typed reason when forcing a real overlap
  const [availability, setAvailability] = useState({});     // { [bookingDocID]: { bufferMinutes, byDriver: { [driverID]: fit } } }
  const availRequested = useRef(new Set());                 // booking ids already fetched (or in flight) since the last board load
  const [expanded, setExpanded] = useState({});    // { [driverID]: bool }
  const [openCards, setOpenCards] = useState({});          // { [bookingDocID]: bool } — details row expanded
  const [queuePage, setQueuePage]     = useState(1);        // "Needs a Driver" — 1-based
  const [driversPage, setDriversPage] = useState(1);        // "Drivers" — 1-based

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  const authedFetch = useCallback((path, options = {}) => {
    return fetch(`${API_URL}${path}`, {
      ...options,
      headers: {
        Authorization: `Bearer ${token}`,
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers,
      },
    });
  }, [token]);

  const fetchBoard = useCallback(async () => {
    setLoading(true);
    try {
      const res  = await authedFetch("/api/driver-dispatch/board");
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to load driver dispatch board.");
      setBoard(json.data);
      availRequested.current = new Set(); // schedules may have changed: ask again for whatever is open
      setAvailability({});
      setQueuePage(1);
      setDriversPage(1);
    } catch (e) {
      showToast(e.message, "error");
    } finally {
      setLoading(false);
    }
  }, [authedFetch]);

  useEffect(() => { fetchBoard(); }, [fetchBoard]);

  // Arrived via a "View Driver" link (e.g. from Car Tracking) — auto-expand
  // and scroll to that driver's card instead of leaving it collapsed.
  useEffect(() => {
    if (!highlightDriverID || loading) return;
    const idx = board.drivers.findIndex((d) => d.driverID === highlightDriverID);
    if (idx >= 0) setDriversPage(Math.floor(idx / PAGE_SIZE) + 1);
    setExpanded((prev) => ({ ...prev, [highlightDriverID]: true }));
    // Page state update above needs a render before the target row exists in
    // the DOM, so scroll on the next frame rather than immediately.
    requestAnimationFrame(() => {
      const el = document.getElementById(`driver-${highlightDriverID}`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }, [highlightDriverID, loading, board.drivers]);

  // Arrived via "Assign Driver" on Car Tracking — scroll to this booking's
  // card in the "Needs a Driver" queue so its conflict prompt (if any) is
  // visible once a driver is clicked below.
  useEffect(() => {
    if (!assignForBooking || loading) return;
    const idx = board.unassigned.findIndex((b) => b.id === assignForBooking.bookingId);
    if (idx >= 0) setQueuePage(Math.floor(idx / PAGE_SIZE) + 1);
    requestAnimationFrame(() => {
      const el = document.getElementById(`booking-${assignForBooking.bookingId}`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }, [assignForBooking, loading, board.unassigned]);

  const driverOptions = useMemo(
    () => board.drivers.map((d) => ({ id: d.driverID, name: d.name, license: d.license })),
    [board.drivers]
  );

  const clearConflict = () => { setConflict(null); setOverrideReason(""); };

  const doAssign = async (bookingDocID, driverID, force = false, reason = "") => {
    if (!driverID) { showToast("Pick a driver first.", "error"); return false; }
    setBusyID(bookingDocID);
    try {
      const res  = await authedFetch("/api/driver-dispatch/assign", {
        method: "POST",
        body: JSON.stringify({ bookingID: bookingDocID, driverID, force, ...(reason ? { overrideReason: reason } : {}) }),
      });
      const json = await res.json();
      if (!res.ok) {
        if (json.conflict) {
          setConflict({
            bookingDocID, driverID, message: json.message,
            conflictType: json.conflictType || null,      // "overlap" | "tight" | null (license only)
            requiresReason: !!json.requiresReason,
            bufferMinutes: json.bufferMinutes ?? null,
          });
          return false;
        }
        throw new Error(json.message || "Failed to assign driver.");
      }
      clearConflict();
      // Assignment is done: drop the dropdown selection for this booking so it
      // doesn't linger (or come back pre-selected if the driver is later unassigned).
      setPicked((prev) => {
        if (!(bookingDocID in prev)) return prev;
        const { [bookingDocID]: _done, ...rest } = prev;
        return rest;
      });
      // If this was the booking we arrived to assign (amber banner + pulsing
      // driver cards), leave assign mode no matter how it was assigned —
      // clicking a driver card OR using the dropdown + Assign button.
      if (assignForBooking?.bookingId === bookingDocID) cancelAssignMode();
      showToast("Driver assigned.");
      fetchBoard();
      return true;
    } catch (e) {
      showToast(e.message, "error");
      return false;
    } finally {
      setBusyID(null);
    }
  };

  // Used when a driver card is clicked while in "assign this booking" mode
  // (i.e. arrived here via "Assign Driver" on Car Tracking). Skips the
  // manual dropdown-and-Assign step and assigns directly — mirrors
  // DeviceTrack.jsx's handleQuickAssign for GPS devices. On a scheduling
  // conflict, doAssign already surfaces the "Assign Anyway" prompt on the
  // matching Needs-a-Driver card (scrolled into view above), so assign
  // mode stays open until it actually succeeds.
  const handleQuickAssignDriver = async (driverID) => {
    if (!assignForBooking) return;
    await doAssign(assignForBooking.bookingId, driverID); // leaves assign mode itself on success
  };

  const doUnassign = async (bookingDocID) => {
    setBusyID(bookingDocID);
    try {
      const res  = await authedFetch("/api/driver-dispatch/unassign", {
        method: "POST",
        body: JSON.stringify({ bookingID: bookingDocID }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to unassign driver.");
      setPicked((prev) => {
        if (!(bookingDocID in prev)) return prev;
        const { [bookingDocID]: _done, ...rest } = prev;
        return rest;
      });
      showToast("Driver unassigned.");
      fetchBoard();
    } catch (e) {
      showToast(e.message, "error");
    } finally {
      setBusyID(null);
    }
  };

  const toggleExpand = (driverID) => setExpanded((prev) => ({ ...prev, [driverID]: !prev[driverID] }));

  // "Needs a Driver" — real pagination, 10 per page. The deep-link effect
  // above already moved queuePage to wherever assignForBooking's target
  // booking lives, so it's simply on-screen by the time this renders.
  const queueTotalPages   = Math.max(1, Math.ceil(board.unassigned.length / PAGE_SIZE));
  const visibleUnassigned = board.unassigned.slice((queuePage - 1) * PAGE_SIZE, queuePage * PAGE_SIZE);

  // Collapsed by default; opens on its own for the booking we arrived to assign or one showing a conflict
  // prompt. An explicit click always wins.
  const isCardOpen = (b) => {
    const forcedOpen = assignForBooking?.bookingId === b.id || conflict?.bookingDocID === b.id;
    return openCards[b.id] !== undefined ? openCards[b.id] : forcedOpen;
  };

  // Free / tight / busy for every driver, fetched only for the bookings that are open (and the one we are
  // assigning), so the picker can show it before anyone clicks Assign. Informational only: the server
  // re-checks inside the assignment itself.
  useEffect(() => {
    if (loading) return;
    const ids = new Set(visibleUnassigned.filter(isCardOpen).map((b) => b.id));
    if (assignForBooking?.bookingId) ids.add(assignForBooking.bookingId);
    ids.forEach(async (id) => {
      if (availRequested.current.has(id)) return;
      availRequested.current.add(id);
      try {
        const res  = await authedFetch(`/api/driver-dispatch/availability?bookingID=${encodeURIComponent(id)}`);
        const json = await res.json();
        if (!res.ok) throw new Error(json.message || "Failed to load driver availability.");
        const byDriver = Object.fromEntries((json.data?.drivers || []).map((x) => [x.driverID, x]));
        setAvailability((prev) => ({ ...prev, [id]: { bufferMinutes: json.data?.bufferMinutes ?? null, byDriver } }));
      } catch {
        availRequested.current.delete(id); // not cached: it will retry the next time the card is opened
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, board.unassigned, queuePage, openCards, assignForBooking, conflict?.bookingDocID, authedFetch]);

  const driversTotalPages = Math.max(1, Math.ceil(board.drivers.length / PAGE_SIZE));
  const visibleDrivers    = board.drivers.slice((driversPage - 1) * PAGE_SIZE, driversPage * PAGE_SIZE);

  const activeTripCount = board.drivers.reduce((sum, d) => sum + d.assignments.length, 0);

  return (
    <div className="w-full px-4 space-y-5">

      {/* Assign-mode banner — shown when we arrived here to assign a specific booking */}
      {assignForBooking && (
        <div className="rounded-2xl px-4 py-3 text-xs font-medium border bg-amber-50 border-amber-200 text-amber-700 flex items-center justify-between gap-2">
          <span className="flex items-center gap-2">
            <IconSteering className="w-3.5 h-3.5 shrink-0" />
            Pick an available driver below to assign to <strong>{assignForBooking.customerName || "this trip"}</strong>
            {assignForBooking.carLabel ? <> · {assignForBooking.carLabel}</> : null}.
          </span>
          <button onClick={cancelAssignMode} className="text-amber-600 hover:text-amber-800 font-semibold shrink-0">
            Cancel
          </button>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"
        }`}>{toast.msg}</div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-arl-dark">Driver Dispatch</h1>
          <p className="text-xs text-gray-400 mt-0.5">
            {loading ? "Loading…" : `${board.unassigned.length} awaiting a driver · ${board.drivers.length} drivers`}
          </p>
        </div>
        <button onClick={fetchBoard} disabled={loading}
          className="px-3 py-2 text-sm rounded-xl bg-teal-700 text-white hover:bg-teal-800 disabled:opacity-50 self-start sm:self-auto">
          ↺ Refresh
        </button>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <StatCard icon={<IconWarning />}   value={board.unassigned.length} label="Needs a Driver" color="yellow" />
        <StatCard icon={<IconSteering />}  value={board.drivers.length}    label="Drivers"        color="blue" />
        <StatCard icon={<IconClock />}     value={activeTripCount}         label="Active Trips"   color="green" />
      </div>

      {/* Data-integrity flag: chauffeur bookings already picked up with no driver on record */}
      {board.missingWhileOngoing.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-red-700 font-semibold text-sm">
            <IconWarning /> {board.missingWhileOngoing.length} ongoing chauffeur trip(s) have no driver on record
          </div>
          <p className="text-xs text-red-600">These are already picked up but weren't assigned before dispatch — worth checking directly.</p>
          <div className="space-y-1">
            {board.missingWhileOngoing.map((b) => (
              <div key={b.id} className="text-xs text-red-700">
                {b.customerName} · {b.vehicleName} · {fmtDateTime(b.startDateTime)}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-5">

        {/* ── Needs a Driver queue ─────────────────────────────── */}
        <div className="bg-white rounded-2xl shadow-soft p-4 space-y-3">
          <h2 className="text-sm font-bold text-arl-dark flex items-center gap-2">
            <IconWarning className="w-4 h-4 text-yellow-500" /> Needs a Driver
          </h2>

          {loading ? (
            <p className="text-xs text-gray-400 py-6 text-center">Loading…</p>
          ) : board.unassigned.length === 0 ? (
            <p className="text-xs text-gray-400 py-6 text-center">All chauffeur bookings are assigned. 🎉</p>
          ) : (
            <div className="space-y-2">
              {visibleUnassigned.map((b) => {
                const isOpen = isCardOpen(b);
                return (
                <div key={b.id} id={`booking-${b.id}`} className={`border rounded-xl px-2.5 py-2 transition-all ${
                  assignForBooking?.bookingId === b.id ? "border-amber-400 ring-2 ring-amber-200" : "border-gray-200"
                }`}>
                  {/* One fixed column per item (status | customer | pickup | driver | details), so every row
                      lines up. Below sm there is no room for columns, so the items simply wrap. */}
                  <div className="flex flex-wrap items-center gap-2 sm:grid sm:grid-cols-[84px_minmax(0,1fr)_150px_84px_28px] sm:gap-x-2">
                    <span className="w-[84px] text-center text-[10px] font-semibold uppercase tracking-wide px-2 py-1 rounded-lg bg-yellow-50 text-yellow-700 border border-yellow-200">
                      Upcoming
                    </span>
                    <span className="min-w-0 flex-1 truncate text-sm font-semibold text-arl-dark" title={b.customerName}>{b.customerName}</span>
                    <span className="flex items-center gap-1 text-xs text-gray-500 whitespace-nowrap tabular-nums">
                      <IconClock className="w-3.5 h-3.5 shrink-0" /> {fmtDateTime(b.startDateTime)}
                    </span>
                    {/* Every row in this column is unassigned by definition —
                        spelled out explicitly rather than left implicit in
                        which section it's in, so it reads at a glance. */}
                    <span className="w-[84px] text-center text-[10px] font-semibold uppercase tracking-wide px-2 py-1 rounded-lg bg-red-50 text-red-700 border border-red-200">
                      No Driver
                    </span>
                    <button type="button"
                      onClick={() => setOpenCards((prev) => ({ ...prev, [b.id]: !isOpen }))}
                      aria-expanded={isOpen}
                      title={isOpen ? "Hide details" : "Show details"}
                      className={`w-7 h-7 flex items-center justify-center rounded-lg border transition-colors ${
                        isOpen ? "bg-gray-100 border-gray-300 text-arl-dark" : "border-gray-200 text-gray-500 hover:bg-gray-50"
                      }`}>
                      <IconDots className="w-4 h-4" />
                    </button>
                  </div>

                  {isOpen && (
                    <div className="mt-2 pt-2 border-t border-gray-100 space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 space-y-1.5">
                          <div className="text-xs text-gray-400">{b.vehicleName}</div>
                          <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-gray-500">
                            <span className="flex items-center gap-1"><IconClock className="w-3.5 h-3.5" /> Start: {fmtDateTime(b.startDateTime)}</span>
                            <span className="flex items-center gap-1"><IconClock className="w-3.5 h-3.5" /> End: {fmtDateTime(b.endDateTime)}</span>
                          </div>
                        </div>
                        {/* Full booking record — Bookings.jsx opens straight to it via
                            ?open=<id>, the same deep-link pattern the notification bell
                            already uses (Header.jsx), so this needs no new page support. */}
                        <button type="button" onClick={() => navigate(`/bookings?open=${encodeURIComponent(b.id)}`)}
                          className="shrink-0 text-[11px] font-semibold text-arl-dark border border-gray-200 rounded-lg px-2 py-1 hover:bg-gray-50">
                          View Booking
                        </button>
                      </div>

                    {conflict?.bookingDocID === b.id ? (() => {
                      const needsReason = conflict.requiresReason;
                      const reasonOk = overrideReason.trim().length >= OVERRIDE_REASON_MIN;
                      return (
                      <div className={`rounded-lg p-2.5 space-y-2 border ${
                        conflict.conflictType === "overlap" ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"
                      }`}>
                        <p className={`text-xs ${conflict.conflictType === "overlap" ? "text-red-700" : "text-amber-800"}`}>{conflict.message}</p>
                        {needsReason && (
                          <div className="space-y-1">
                            <label className="block text-[11px] font-semibold text-red-700">
                              Reason for assigning over an overlap (saved in the audit log)
                            </label>
                            <textarea value={overrideReason} onChange={(e) => setOverrideReason(e.target.value)} rows={2}
                              placeholder="e.g. both trips are short and in the same area"
                              className="w-full border border-red-200 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-red-200" />
                            {!reasonOk && overrideReason.length > 0 && (
                              <p className="text-[11px] text-red-600">At least {OVERRIDE_REASON_MIN} characters.</p>
                            )}
                          </div>
                        )}
                        <div className="flex gap-2">
                          <button onClick={() => doAssign(b.id, conflict.driverID, true, needsReason ? overrideReason.trim() : "")}
                            disabled={busyID === b.id || (needsReason && !reasonOk)}
                            title={needsReason && !reasonOk ? "Type a reason first" : undefined}
                            className="flex-1 px-3 py-1.5 text-xs font-semibold rounded-lg bg-arl-cta text-white hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed">
                            Assign Anyway
                          </button>
                          <button onClick={clearConflict}
                            className="flex-1 px-3 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50">
                            Cancel
                          </button>
                        </div>
                      </div>
                      );
                    })() : (
                      <div className="space-y-1.5">
                        <div className="flex gap-2">
                          <select
                            value={picked[b.id] || ""}
                            onChange={(e) => setPicked((prev) => ({ ...prev, [b.id]: e.target.value }))}
                            className="flex-1 border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-arl-light">
                            <option value="">Select driver…</option>
                            {driverOptions.map((d) => {
                              const w = licenseWarning(d.license);
                              const fit = availability[b.id]?.byDriver?.[d.id];
                              return <option key={d.id} value={d.id}>{d.name}{fit ? ` — ${fitLabel(fit)}` : ""}{w ? ` — ${w.short}` : ""}</option>;
                            })}
                          </select>
                          <button onClick={() => doAssign(b.id, picked[b.id])} disabled={busyID === b.id || !picked[b.id]}
                            title={!picked[b.id] ? "Select a driver first" : undefined}
                            className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-arl-dark text-white hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed">
                            Assign
                          </button>
                        </div>
                        {(() => {
                          const fit = availability[b.id]?.byDriver?.[picked[b.id]];
                          if (!fit || fit.status === "free") return null;
                          return (
                            <p className={`flex items-center gap-1.5 text-[11px] rounded-lg px-2 py-1.5 border ${FIT_STYLES[fit.status]}`}>
                              <IconWarning className="w-3.5 h-3.5 shrink-0" />
                              <span>
                                {fit.conflict?.message}
                                {fit.status === "busy" ? " You'll need to give a reason to assign anyway." : ""}
                              </span>
                            </p>
                          );
                        })()}
                        {(() => {
                          const w = licenseWarning(driverOptions.find((d) => d.id === picked[b.id])?.license);
                          if (!w) return null;
                          return (
                            <p className={`flex items-center gap-1.5 text-[11px] rounded-lg px-2 py-1.5 border ${
                              w.level === "expired"
                                ? "bg-red-50 border-red-200 text-red-700"
                                : "bg-amber-50 border-amber-200 text-amber-700"
                            }`}>
                              <IconWarning className="w-3.5 h-3.5 shrink-0" /> {w.long}
                              {w.level === "expired" ? " You'll be asked to confirm before assigning." : ""}
                            </p>
                          );
                        })()}
                      </div>
                    )}

                    </div>
                  )}
                </div>
                );
              })}
            </div>
          )}
          <Pager page={queuePage} totalPages={queueTotalPages} onChange={setQueuePage} />
        </div>

        {/* ── Drivers list ─────────────────────────────────────── */}
        <div className="bg-white rounded-2xl shadow-soft p-4 space-y-3">
          <h2 className="text-sm font-bold text-arl-dark flex items-center gap-2">
            <IconSteering className="w-4 h-4 text-arl-primary" /> Drivers
          </h2>

          {loading ? (
            <p className="text-xs text-gray-400 py-6 text-center">Loading…</p>
          ) : board.drivers.length === 0 ? (
            <p className="text-xs text-gray-400 py-6 text-center">No drivers found. Add one from Users.</p>
          ) : (
            <div className="space-y-2">
              {visibleDrivers.map((d) => {
                const isAssignTarget = !!assignForBooking;
                const isAssigning    = busyID === assignForBooking?.bookingId;
                return (
                <div key={d.driverID} id={`driver-${d.driverID}`}
                  className={`border rounded-xl overflow-hidden transition-all ${
                    isAssignTarget
                      ? "border-amber-400 ring-2 ring-amber-200 animate-pulse cursor-pointer"
                      : highlightDriverID === d.driverID ? "border-arl-primary ring-2 ring-arl-primary/30" : "border-gray-200"
                  }`}>
                  <button
                    onClick={() => {
                      if (isAssignTarget) { if (!isAssigning) handleQuickAssignDriver(d.driverID); }
                      else toggleExpand(d.driverID);
                    }}
                    disabled={isAssignTarget && isAssigning}
                    className="w-full flex items-center justify-between gap-2 p-3 hover:bg-gray-50 text-left disabled:opacity-50">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-arl-light flex items-center justify-center text-arl-primary overflow-hidden shrink-0">
                        {d.profileImage
                          ? <img src={d.profileImage} alt={d.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          : <IconUser />}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-arl-dark">{d.name}</div>
                        <div className="text-xs text-gray-400">{d.phone}</div>
                        {licenseWarning(d.license) && (
                          <span className={`inline-block mt-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded border ${
                            licenseWarning(d.license).level === "expired"
                              ? "bg-red-50 text-red-700 border-red-200"
                              : "bg-amber-50 text-amber-700 border-amber-200"
                          }`}>
                            {licenseWarning(d.license).short}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="shrink-0 flex flex-col items-end gap-1">
                      {/* "Has Driver / No Driver" answers "does this BOOKING
                          have a driver" — that's the Needs a Driver badge.
                          Every row here already IS a driver, so the same
                          phrase would read as self-contradictory; the
                          parallel question for this list is whether this
                          PERSON currently has a trip. */}
                      <span className={`text-[10px] font-semibold uppercase tracking-wide px-2 py-1 rounded-lg ${
                        d.assignments.length > 0 ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-gray-50 text-gray-500 border border-gray-200"
                      }`}>
                        {d.assignments.length > 0 ? "On a Trip" : "Available"}
                      </span>
                      {isAssignTarget && (() => {
                        const fit = availability[assignForBooking.bookingId]?.byDriver?.[d.driverID];
                        if (!fit) return null;
                        return (
                          <span title={fit.conflict?.message || undefined}
                            className={`text-[10px] font-semibold uppercase tracking-wide px-2 py-1 rounded-lg border ${FIT_STYLES[fit.status]}`}>
                            {fit.status === "free" ? "Free for this trip" : fit.status === "tight" ? "Tight gap" : "Busy"}
                          </span>
                        );
                      })()}
                      <span className="text-[10px] text-gray-400">
                        {isAssignTarget && isAssigning ? "Assigning…" : `${d.assignments.length} trip${d.assignments.length === 1 ? "" : "s"}`}
                      </span>
                    </div>
                  </button>

                  {!isAssignTarget && expanded[d.driverID] && (
                    <div className="border-t border-gray-100 p-3 space-y-2 bg-gray-50/50">
                      <div className="flex justify-end">
                        <button type="button" onClick={() => navigate(`/users?role=driver&tab=directory&open=${encodeURIComponent(d.driverID)}`)}
                          className="text-[11px] font-semibold text-arl-dark border border-gray-200 bg-white rounded-lg px-2 py-1 hover:bg-gray-50">
                          View Driver Info
                        </button>
                      </div>
                      {d.assignments.length === 0 ? (
                        <p className="text-xs text-gray-400">No trips assigned.</p>
                      ) : (
                        d.assignments.map((b) => (
                          <div key={b.id} className="flex items-start justify-between gap-2 bg-white border border-gray-200 rounded-lg p-2.5">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-arl-dark">
                                <span className={`shrink-0 w-[68px] text-center text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded ${
                                  b.status === "ongoing" ? "bg-green-50 text-green-700" : "bg-yellow-50 text-yellow-700"
                                }`}>{b.status}</span>
                                <span className="min-w-0">{b.vehicleName} | {b.customerName}</span>
                              </div>
                              <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-gray-500">
                                <span className="flex items-center gap-1"><IconClock className="w-3.5 h-3.5" /> Start: {fmtDateTime(b.startDateTime)}</span>
                                <span className="flex items-center gap-1"><IconClock className="w-3.5 h-3.5" /> End: {fmtDateTime(b.endDateTime)}</span>
                              </div>
                            </div>
                            <div className="shrink-0 flex flex-col items-end gap-1.5">
                              <button type="button" onClick={() => navigate(`/bookings?open=${encodeURIComponent(b.id)}`)}
                                className="text-[11px] font-semibold text-arl-dark border border-gray-200 rounded-lg px-2 py-1 hover:bg-gray-50">
                                View Booking
                              </button>
                              <button onClick={() => doUnassign(b.id)} disabled={busyID === b.id}
                                className="text-[11px] font-semibold text-arl-cta hover:underline disabled:opacity-40">
                                Unassign
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
                );
              })}
            </div>
          )}
          <Pager page={driversPage} totalPages={driversTotalPages} onChange={setDriversPage} />
        </div>
      </div>
    </div>
  );
}