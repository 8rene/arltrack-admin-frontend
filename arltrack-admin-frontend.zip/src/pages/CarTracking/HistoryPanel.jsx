import { useState, useEffect, useCallback, useRef } from "react";
import TracebackPanel from "./TracebackPanel";

const API = process.env.REACT_APP_API_URL;

function fmtDateTime(val) {
  if (!val) return "—";
  try {
    let d;
    if (typeof val?.toDate === "function") d = val.toDate();
    else if (val?._seconds !== undefined) d = new Date(val._seconds * 1000);
    else d = new Date(val);
    if (isNaN(d.getTime())) return "—";
    return d.toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
  } catch { return "—"; }
}

// Session info for a trip being reviewed. A FINISHED trip (ended / stolen) has a final file -- the last save is made
// when it ends, and the nightly job retries it if that save failed -- so the file is the record and the trip list
// only fills what an older file lacks. A trip still going has a file up to a day old, so there the list is fresher.
function mergeSessionMeta(fileSession, listFields) {
  const strip = (o) => Object.fromEntries(Object.entries(o || {}).filter(([, v]) => v !== undefined && v !== null));
  const fromFile = strip(fileSession);
  const fromList = strip(listFields);
  const finished = fromFile.status === "ended" || fromFile.status === "stolen";
  return finished ? { ...fromList, ...fromFile } : { ...fromFile, ...fromList };
}

// Fallback when a car has no photo (HistoryPanel has no icon set of its own).
const CarGlyph = ({ style }) => (
  <svg style={style} className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 16V11l2-5h10l2 5v5" />
    <path d="M3 16h18v3H3z" />
    <circle cx="7.5" cy="16" r="0.5" />
    <circle cx="16.5" cy="16" r="0.5" />
  </svg>
);

const STATUS_STYLES = {
  ended:     "bg-teal-50 text-teal-700",
  stolen:    "bg-red-50 text-red-700",
  cancelled: "bg-gray-100 text-gray-500",
  active:    "bg-blue-50 text-blue-700",
};

/**
 * Car Tracking's History tab. Left column: pick a car. Right column: every
 * archived (Firebase-Storage-flushed) trip for that car, newest first, with
 * a "No GPS record" fallback when the list comes back empty. "Review" loads
 * that trip's archive JSON and hands it to the Review tab (onOpenReview). Without that callback it falls back to
 * showing the review in place.
 */
export default function HistoryPanel({ cars, token, refreshTick = 0, autoOpen = null, onOpenReview = null }) {
  const [selectedCar, setSelectedCar] = useState(null);
  const [history, setHistory]         = useState([]);
  // Which car the current `history` list belongs to. The auto-open below must wait for this, otherwise it runs in the
  // same render that selects the car (before the fetch has even started), sees an empty list and gives up.
  const [loadedCarID, setLoadedCarID] = useState(null);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState(null);
  const [reviewData, setReviewData]   = useState(null);
  const [reviewLoading, setReviewLoading] = useState(false);
  const [deepLinkNotice, setDeepLinkNotice] = useState(null);
  const [flushingId, setFlushingId] = useState(null); // trip being saved right now by the manual flush
  const [flushNote, setFlushNote]   = useState(null); // { id, ok, msg } -- result of the last manual flush

  // Deep-link from Bookings' "Trip History" button: select the car once —
  // guarded so it doesn't fight the user if they click a different car
  // afterward (only runs while nothing else is selected yet).
  useEffect(() => {
    if (autoOpen?.carID && !selectedCar) {
      setSelectedCar(autoOpen.carID);
    }
  }, [autoOpen]); // eslint-disable-line react-hooks/exhaustive-deps

  const autoOpenedRef = useRef(false);
  // Once that car's history has actually loaded, auto-open the matching
  // trip's Review — one-shot only, so switching tabs away and back doesn't
  // keep re-opening the same trip.
  useEffect(() => {
    if (!autoOpen?.bookingID || autoOpenedRef.current) return;
    if (loading || selectedCar !== autoOpen.carID || loadedCarID !== autoOpen.carID) return;
    autoOpenedRef.current = true;
    const match = history.find(h => h.bookingID === autoOpen.bookingID);
    if (match) {
      handleReview(match);
    } else {
      setDeepLinkNotice("Couldn't find that trip's archived record for this car.");
    }
  }, [history, loading, selectedCar, loadedCarID, autoOpen]); // eslint-disable-line react-hooks/exhaustive-deps

  const fetchHistory = useCallback(async (carId) => {
    setLoading(true);
    setError(null);
    setLoadedCarID(null);
    if (!API) {
      setError("REACT_APP_API_URL is not set — check your .env and restart the dev server.");
      setLoading(false);
      return;
    }
    try {
      const res = await fetch(`${API}/api/gps/${carId}/history`, { headers: { Authorization: `Bearer ${token}` } });
      const contentType = res.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        throw new Error(`Backend returned ${res.status} (non-JSON) — is REACT_APP_API_URL correct and is the backend deployed with the history route?`);
      }
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to load history.");
      setHistory(json.data || []);
    } catch (e) {
      setError(e.message);
      setHistory([]);
    } finally {
      setLoading(false);
      setLoadedCarID(carId);   // last, so the auto-open only ever sees a finished list
    }
  }, [token]);

  useEffect(() => {
    if (selectedCar) fetchHistory(selectedCar);
  }, [selectedCar, fetchHistory, refreshTick]);

  // Manual flush: save this trip's latest GPS points to its archive file now (the nightly job does the same at
  // midnight), then reload the list so the new "Archived" time and point count show.
  async function handleFlush(item) {
    setFlushingId(item.bookingSessionID);
    setFlushNote(null);
    try {
      const res = await fetch(`${API}/api/gps/sessions/${item.bookingSessionID}/flush`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.status !== "ok") throw new Error(json.message || "Couldn't save this trip's data right now.");
      const n = json.data?.pointCount;
      setFlushNote({ id: item.bookingSessionID, ok: true, msg: typeof n === "number" ? `Saved — ${n.toLocaleString()} points` : "Saved" });
      await fetchHistory(selectedCar);
    } catch (e) {
      setFlushNote({ id: item.bookingSessionID, ok: false, msg: e.message });
    } finally {
      setFlushingId(null);
    }
  }

  async function handleReview(item) {
    const car = cars.find(c => c.id === selectedCar);
    setReviewLoading(true);
    try {
      if (!item.archiveUrl) throw new Error("This trip hasn't been archived yet — check back once it's finished.");
      let res;
      try {
        res = await fetch(item.archiveUrl);
      } catch (networkErr) {
        // A thrown TypeError here (the browser's generic "Failed to fetch")
        // means the request never got a response at all — almost always the
        // Storage bucket blocking cross-origin reads (no CORS config for
        // this frontend's origin), not a "file isn't ready" situation, since
        // getCarHistory only ever returns sessions that already have an
        // archiveUrl. Surface that instead of the opaque browser message.
        throw new Error("Couldn't reach the archive file (likely a CORS/network issue on the storage bucket) — this isn't about the trip not being ready. Try again, or check the bucket's CORS settings.");
      }
      if (!res.ok) throw new Error(`Could not load this trip's archive file (server returned ${res.status}).`);
      const parsed = await res.json();
      // New archives are { points, geofenceZones, geofenceAlerts, codingAlerts };
      // older archives already sitting in Storage are still a bare array of
      // { lat, lng, at } with no zone/alert data — handle both.
      const isLegacyArray = Array.isArray(parsed);
      const points = isLegacyArray ? parsed : (parsed.points || []);
      const meta = mergeSessionMeta(isLegacyArray ? null : parsed.session, {
        bookingSessionID: item.bookingSessionID,
        bookingID:        item.bookingID,
        status:           item.status,
        startedAt:        item.startedAt,
        endedAt:          item.endedAt,
      });
      const data = {
        label: `${car?.name || selectedCar} · ${fmtDateTime(meta.startedAt)} → ${meta.endedAt ? fmtDateTime(meta.endedAt) : meta.status === "ended" ? "—" : "ongoing"}`,
        cars: [{ id: selectedCar, name: car?.name || selectedCar, imageURL: car?.imageURL || null }],
        records: { [selectedCar]: points },
        zonesAlerts: isLegacyArray ? undefined : {
          [selectedCar]: {
            geofenceZones:  parsed.geofenceZones  || [],
            geofenceAlerts: parsed.geofenceAlerts || [],
            codingAlerts:   parsed.codingAlerts   || [],
            codingWarnings: parsed.codingWarnings || [],
            // Review details saved with newer history files; older files
            // simply don't have them (null / empty -> "not recorded").
            droppedOffAt:   parsed.droppedOffAt || parsed.session?.droppedOffAt || null,
            completedAt:    parsed.completedAt  || parsed.session?.completedAt  || null,
            stolenAt:       parsed.session?.stolenAt || null,
            holidays:       parsed.holidays     || [],
            // Trip-level plate (masked) if the file has one; Trip Summary otherwise falls back to the
            // plate stamped on the coding alerts.
            plate:          parsed.session?.plate || parsed.plate || null,
          },
        },
        // See mergeSessionMeta: the file is the record for a finished trip; the list only fills gaps.
        sessionMeta: { [selectedCar]: meta },
      };
      if (onOpenReview) onOpenReview(data);   // the Review tab shows it
      else setReviewData(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setReviewLoading(false);
    }
  }

  // ── Review mode: hand off entirely to TracebackPanel ─────────────────────
  if (reviewData) {
    return <TracebackPanel cars={cars} token={token} reviewData={reviewData} onExitReview={() => setReviewData(null)} />;
  }

  return (
    <div className="flex flex-1 min-h-0 gap-4">
      {/* ── Sidebar: car list ──────────────────────────────────────────── */}
      <div className="w-80 shrink-0 flex flex-col gap-2 overflow-y-auto scrollbar-hide">
        {cars.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-soft p-6 text-center">
            <p className="text-sm text-gray-500 font-semibold">No cars in database</p>
          </div>
        ) : (
          cars.map(car => (
            <button
              key={car.id}
              onClick={() => setSelectedCar(car.id)}
              className={`text-left bg-white rounded-2xl border-2 shadow-soft p-3 transition-all ${
                selectedCar === car.id ? "border-teal-500 ring-1 ring-teal-200" : "border-gray-100 hover:border-teal-300"
              }`}
            >
              <div className="flex items-center gap-3">
                {/* Same car photo as the Live list; falls back to a car glyph when there is none or it fails to load. */}
                <div className="w-10 h-10 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center shrink-0 overflow-hidden">
                  {car.imageURL ? (
                    <img
                      src={car.imageURL}
                      alt={car.name}
                      className="w-full h-full object-cover"
                      onError={e => { e.currentTarget.style.display = "none"; e.currentTarget.nextElementSibling.style.display = "block"; }}
                    />
                  ) : null}
                  <CarGlyph style={car.imageURL ? { display: "none" } : undefined} />
                </div>
                <p className="font-bold text-gray-800 text-sm truncate min-w-0">{car.name}</p>
              </div>
            </button>
          ))
        )}
      </div>

      {/* ── History list for the selected car ────────────────────────────── */}
      <div className="flex-1 min-w-0 flex flex-col gap-3">
        {!selectedCar ? (
          <div className="flex-1 flex items-center justify-center bg-white rounded-2xl border border-gray-100 shadow-soft">
            <p className="text-sm text-gray-400">Select a car to see its trip history.</p>
          </div>
        ) : (
          <div className="flex-1 min-h-0 bg-white rounded-2xl border border-gray-100 shadow-soft p-4 overflow-y-auto scrollbar-hide">
            <p className="font-bold text-arl-dark text-sm mb-3">
              {cars.find(c => c.id === selectedCar)?.name} — Trip History
            </p>

            {deepLinkNotice && (
              <div className="mb-3 bg-amber-50 border border-amber-100 rounded-xl p-3 text-xs text-amber-700">
                {deepLinkNotice}
              </div>
            )}

            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="h-16 bg-gray-50 rounded-xl animate-pulse" />
                ))}
              </div>
            ) : error ? (
              <p className="text-xs text-red-500">{error}</p>
            ) : history.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-sm font-semibold text-gray-400 italic">No GPS record</p>
                <p className="text-xs text-gray-300 mt-1">This car has no archived trips yet.</p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {history.map(item => (
                  <div key={item.bookingSessionID} className="flex items-center justify-between gap-3 bg-gray-50 border border-gray-100 rounded-xl p-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-semibold text-gray-700">
                          {fmtDateTime(item.startedAt)} → {item.endedAt ? fmtDateTime(item.endedAt) : item.status === "ended" ? "—" : "ongoing"}
                        </p>
                        {item.status && (
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${STATUS_STYLES[item.status] || "bg-gray-100 text-gray-500"}`}>
                            {item.status}
                          </span>
                        )}
                      </div>
                      {(item.droppedOffAt || item.stolenAt) && (
                        <p className="text-[10px] text-gray-500 mt-0.5 flex flex-wrap gap-x-3">
                          {item.droppedOffAt && <span>📍 Dropped off {fmtDateTime(item.droppedOffAt)}</span>}
                          {item.stolenAt && <span className="font-semibold text-red-600">🚨 Flagged stolen {fmtDateTime(item.stolenAt)}</span>}
                        </p>
                      )}
                      <p className="text-[10px] text-gray-400 mt-0.5">
                        Archived {fmtDateTime(item.lastArchivedAt)}
                        {typeof item.pointCount === "number" && (
                          <>
                            {" · "}
                            <span className={item.pointCount === 0 ? "font-semibold text-amber-600" : "font-semibold text-gray-500"}>
                              {item.pointCount === 0 ? "No GPS points" : `${item.pointCount.toLocaleString()} points`}
                            </span>
                          </>
                        )}
                      </p>
                    </div>
                    <div className="shrink-0 flex flex-col items-end gap-1">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleFlush(item)}
                          disabled={!!flushingId || reviewLoading}
                          title="Save this trip's latest GPS points to its archive now, instead of waiting for midnight"
                          className="px-3 py-1.5 bg-white border border-teal-300 text-teal-700 rounded-lg text-xs font-semibold hover:bg-teal-50 active:scale-95 transition-all disabled:opacity-50"
                        >
                          {flushingId === item.bookingSessionID ? "Saving…" : "Flush now"}
                        </button>
                        <button
                          onClick={() => handleReview(item)}
                          disabled={reviewLoading || !!flushingId}
                          className="px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-semibold hover:bg-teal-700 active:scale-95 transition-all disabled:opacity-50"
                        >
                          {reviewLoading ? "…" : "Review"}
                        </button>
                      </div>
                      {flushNote?.id === item.bookingSessionID && (
                        <p className={`text-[10px] font-medium ${flushNote.ok ? "text-teal-600" : "text-red-500"}`}>{flushNote.msg}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}