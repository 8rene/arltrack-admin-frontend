import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useCurrency } from "../context/CurrencyContext";
import {
  collection, getDocs, getDoc, doc, query, where,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "../fireabase";
import { useAuth } from "../context/AuthContext";
import { ROLES } from "../config/pagePermissions";

// Authenticated call to this app's own backend (/api/fleet/...) instead of
// writing to Firestore directly from the browser. This is what actually
// makes verifyToken + requireRole run on every car/pricing/brand/model
// change — going straight to Firestore skipped both entirely. Throws on
// any non-success response so callers' existing try/catch + setError(...)
// continues to work unchanged.
const apiFetch = async (path, options = {}) => {
  const token = localStorage.getItem("token");
  const res = await fetch(`${process.env.REACT_APP_API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || json?.success === false) {
    throw new Error(json?.message || `Request failed (${res.status})`);
  }
  return json?.data;
};

// Same idea as apiFetch, but returns the FULL response body instead of just
// .data — needed for /api/auth/send-otp, which reports success even when
// the email itself failed to send (emailSent: false, e.g. a missing EmailJS
// env var). apiFetch's "just give me .data" shape would silently swallow
// that distinction.
const apiFetchFull = async (path, options = {}) => {
  const token = localStorage.getItem("token");
  const res = await fetch(`${process.env.REACT_APP_API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || json?.success === false) {
    throw new Error(json?.message || `Request failed (${res.status})`);
  }
  return json || {};
};

// ─── SVG ICONS ────────────────────────────────────────────────────────────────
const Icons = {
  Car: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 11l2-4h10l2 4M3 11h18v8H3v-8zm4 8v2m10-2v2" />
      <circle cx="7.5" cy="15" r="1.5" fill="currentColor" stroke="none"/>
      <circle cx="16.5" cy="15" r="1.5" fill="currentColor" stroke="none"/>
    </svg>
  ),
  Refresh: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  ),
  Plus: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5v14M5 12h14" />
    </svg>
  ),
  Tag: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" />
      <line x1="7" y1="7" x2="7.01" y2="7" />
    </svg>
  ),
  Trash: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14H6L5 6" />
      <path d="M10 11v6M14 11v6" />
      <path d="M9 6V4h6v2" />
    </svg>
  ),
  Edit: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
  ),
  Close: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  ),
  ChevronDown: (props) => (
    <svg {...props} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.085l3.71-3.855a.75.75 0 111.08 1.04l-4.25 4.42a.75.75 0 01-1.08 0L5.21 8.27a.75.75 0 01.02-1.06z" clipRule="evenodd"/>
    </svg>
  ),
  Camera: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" />
      <circle cx="12" cy="13" r="4" />
    </svg>
  ),
  Calendar: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  ),
  AlertTriangle: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  ),
  Brands: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <path d="M8.56 2.75c4.37 6.03 6.02 9.42 8.03 17.72m2.54-15.38c-3.72 4.35-8.94 5.66-16.88 5.85m19.5 1.9c-3.5-.93-6.63-.82-8.94 0-2.58.92-5.01 2.86-7.44 6.32" />
    </svg>
  ),
  ArrowRight: (props) => (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </svg>
  ),
};

const STATUS_STYLE = {
  Active:      "bg-green-50 border border-green-200 text-black",
  Rented:      "bg-blue-50 border border-blue-200 text-black",
  Reserved:    "bg-orange-50 border border-orange-200 text-black",
  Maintenance: "bg-red-50 border border-red-200 text-black",
  // Matches Inventory.jsx's gray treatment for the same status, since
  // both pages read/write the same cars.status field.
  Inactive:    "bg-gray-100 border border-gray-200 text-gray-500",
};

// Card border color per status — same color family as STATUS_STYLE above,
// just solid instead of a light fill, so a status is identifiable from the
// card outline alone (useful when scanning a full grid at a glance).
const STATUS_BORDER = {
  Active:      "border-green-400",
  Rented:      "border-blue-400",
  Reserved:    "border-orange-400",
  Maintenance: "border-red-400",
  Inactive:    "border-gray-300",
};

// Sort pricing: 12 Hours always last
function sortPricing(pricing) {
  return [...(pricing || [])].sort((a, b) => {
    const aIs12 = a.durationType?.toLowerCase().includes("12");
    const bIs12 = b.durationType?.toLowerCase().includes("12");
    if (aIs12 && !bIs12) return 1;
    if (!aIs12 && bIs12) return -1;
    return 0;
  });
}

function fmtDate(val) {
  if (!val) return "—";
  const d = val?.toDate ? val.toDate() : new Date(val);
  return d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function Fleet() {
  const { effectiveRole } = useAuth();
  // Owner can still view/add/delete/change status — just not edit an
  // existing vehicle's details. Uses effectiveRole so an Admin previewing
  // "as Owner" sees the same restriction a real Owner would.
  const canEdit = effectiveRole !== ROLES.OWNER;
  const [cars, setCars]           = useState([]);
  const [brands, setBrands]       = useState([]);
  const [models, setModels]       = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState("");
  const [filterStatus, setFilter] = useState("All");
  const [detailCar, setDetailCar] = useState(null);
  const [editCar, setEditCar]     = useState(null);
  const [showAddCar, setShowAddCar] = useState(false);
  const [showManageBrands, setShowManageBrands] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const handleDeleteCar = async (car) => {
    try {
      // Backend's deleteCar already cascades to that car's images + pricing
      // docs in one batch — matches what this used to do by hand.
      await apiFetch(`/api/fleet/cars/${car.id}`, { method: "DELETE" });
      setConfirmDelete(null);
      fetchAll();
    } catch (e) { console.error("Delete car error:", e); }
  };

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      // getAllCars on the backend already merges in imageURL, pricing, and
      // brandName/modelName — no need to fetch+join those collections
      // client-side anymore.
      const [carsData, brandsData, modelsData] = await Promise.all([
        apiFetch("/api/fleet/cars"),
        apiFetch("/api/fleet/brands"),
        apiFetch("/api/fleet/models"),
      ]);

      setBrands(brandsData || []);
      setModels(modelsData || []);
      setCars(carsData || []);
    } catch (e) {
      console.error("Fleet fetch error:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // Rented/Reserved dropped from the filter chips too — now that they can't
  // be set from the UI anymore, they'd sit stuck at 0 forever (any legacy
  // car still tagged that way in Firestore is still reachable under "All",
  // just no longer has its own chip). Inactive added — matches
  // Inventory.jsx's status filter, which reads this same field and has
  // offered "Inactive" as an option all along even though nothing could
  // ever set it until now.
  const statuses = ["All", "Active", "Maintenance", "Inactive"];
  const filtered = cars.filter(c => {
    const q = search.toLowerCase();
    const matchSearch = !search ||
      (c.brandName || "").toLowerCase().includes(q) ||
      (c.modelName || "").toLowerCase().includes(q) ||
      (c.platenumber || c.plateNumber || "").toLowerCase().includes(q) ||
      (c.shortDescription || "").toLowerCase().includes(q);
    const matchStatus = filterStatus === "All" || c.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const counts = statuses.reduce((acc, s) => {
    acc[s] = s === "All" ? cars.length : cars.filter(c => c.status === s).length;
    return acc;
  }, {});

  return (
    <div className="p-4 space-y-5 font-sans">
      {/* TOP BAR */}
      <div className="flex flex-wrap justify-between items-center gap-3">
        <h1 className="text-2xl font-bold text-gray-800">Fleet Manager</h1>
        <div className="flex gap-2 flex-wrap items-center">
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search vehicle..."
            className="px-4 py-2 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-400 w-52"
          />
          <button onClick={() => setShowManageBrands(true)}
            className="flex items-center gap-2 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            <Icons.Tag className="w-4 h-4" />
            Brands & Models
          </button>
          <button onClick={fetchAll}
            className="flex items-center gap-2 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            <Icons.Refresh className="w-4 h-4" />
            Refresh
          </button>
          <button onClick={() => setShowAddCar(true)}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl text-sm font-medium hover:bg-teal-700">
            <Icons.Plus className="w-4 h-4" />
            Add Vehicle
          </button>
        </div>
      </div>

      {/* STATUS TABS */}
      <div className="flex gap-2 flex-wrap">
        {statuses.map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
              filterStatus === s ? "bg-teal-600 text-white shadow" : "bg-white border text-gray-600 hover:bg-gray-50"
            }`}>
            {s} <span className="ml-1 opacity-70">{counts[s]}</span>
          </button>
        ))}
      </div>

      {/* GRID */}
      {loading ? (
        <div className="grid md:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => <div key={i} className="bg-white rounded-2xl border h-72 animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center text-gray-400 py-20">No vehicles found.</div>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {filtered.map(car => (
            <VehicleCard key={car.id} car={car}
              canEdit={canEdit}
              onViewDetails={() => setDetailCar(car)}
              onEdit={() => setEditCar(car)}
              onDelete={() => setConfirmDelete(car)}
              onStatusChange={(id, st, extra = {}) => setCars(prev => prev.map(c => c.id === id ? { ...c, status: st, ...extra } : c))} />
          ))}
        </div>
      )}

      {/* MODALS */}
      {detailCar && (
        <ViewDetailsModal car={detailCar} canEdit={canEdit} onClose={() => setDetailCar(null)}
          onEdit={() => { setDetailCar(null); setEditCar(detailCar); }} />
      )}
      {editCar && (
        <EditCarModal car={editCar} brands={brands} models={models}
          onClose={() => setEditCar(null)}
          onSaved={() => { setEditCar(null); fetchAll(); }} />
      )}
      {showAddCar && (
        <AddCarModal brands={brands} models={models}
          onClose={() => setShowAddCar(false)}
          onSaved={() => { setShowAddCar(false); fetchAll(); }} />
      )}
      {showManageBrands && (
        <ManageBrandsModal brands={brands} models={models}
          onClose={() => setShowManageBrands(false)}
          onSaved={() => { setShowManageBrands(false); fetchAll(); }} />
      )}
      {confirmDelete && (
        <ConfirmDeleteModal
          message={`Delete ${confirmDelete.brandName || ""} ${confirmDelete.modelName || ""}? This will also remove its images and pricing.`}
          onConfirm={() => handleDeleteCar(confirmDelete)}
          onCancel={() => setConfirmDelete(null)} />
      )}
    </div>
  );
}

// ─── VEHICLE CARD ─────────────────────────────────────────────────────────────
function VehicleCard({ car, canEdit, onViewDetails, onEdit, onDelete, onStatusChange }) {
  const { fmt } = useCurrency();
  const navigate = useNavigate();
  const [nearestBooking, setNearestBooking] = useState(null);
  const [statusOpen, setStatusOpen] = useState(false);
  const [statusSaving, setStatusSaving] = useState(false);
  // null | "Maintenance" | "Inactive" — target status the reason → confirm →
  // OTP flow (StatusChangeFlow below) is currently running for. Active
  // never sets this; it writes immediately, no gate needed.
  const [statusChangeTarget, setStatusChangeTarget] = useState(null);
  const CAR_STATUSES = ["Active", "Maintenance", "Inactive"];

  useEffect(() => {
    if (car.status === "Rented" || car.status === "Reserved") {
      getDocs(query(
        collection(db, "bookings"),
        where("carID", "==", car.carID || car.id)
      )).then(snap => {
        const future = snap.docs
          .map(d => ({ id: d.id, ...d.data() }))
          .filter(b => ["upcoming", "ongoing"].includes(b.status?.toLowerCase()))
          .sort((a, b) => {
            const aD = a.startDateTime?.toDate ? a.startDateTime.toDate() : new Date(a.startDateTime);
            const bD = b.startDateTime?.toDate ? b.startDateTime.toDate() : new Date(b.startDateTime);
            return aD - bD;
          });
        setNearestBooking(future[0] || null);
      }).catch(() => {});
    }
  }, [car.id, car.carID, car.status]);

  const carLabel = `${car.brandName || ""} ${car.modelName || ""}`.trim() || car.plateNumber || car.id;

  // Active writes immediately — no reason, no bookings to worry about
  // leaving service. Maintenance/Inactive never come through here; they're
  // handled entirely by StatusChangeFlow below (reason → refund any
  // upcoming bookings → OTP), which calls the gated PATCH /status endpoint
  // itself and reports back via onDone.
  const applyActiveStatus = async () => {
    setStatusSaving(true);
    try {
      await apiFetch(`/api/fleet/cars/${car.id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status: "Active" }),
      });
      onStatusChange?.(car.id, "Active", { statusReason: null });
    } catch (e) { console.error(e); }
    finally { setStatusSaving(false); setStatusOpen(false); }
  };

  const handleStatusChange = (newStatus) => {
    if (newStatus === car.status) { setStatusOpen(false); return; }
    if (newStatus === "Inactive" || newStatus === "Maintenance") {
      setStatusOpen(false);
      setStatusChangeTarget(newStatus);
      return;
    }
    applyActiveStatus();
  };

  // The gated flow finished and the PATCH already went through — just
  // reflect it locally and, for Maintenance, send staff straight to the
  // Maintenance page prefilled to this car.
  const handleStatusChangeDone = (newStatus, reason) => {
    setStatusChangeTarget(null);
    onStatusChange?.(car.id, newStatus, { statusReason: reason });
    if (newStatus === "Maintenance") {
      navigate(`/maintenance?carID=${car.id}`);
    }
  };

  const basePrice = car.pricing?.find(p =>
    !p.durationType?.toLowerCase().includes("12")
  ) || car.pricing?.[0];

  return (
    <div className={`bg-white rounded-2xl shadow-sm border-2 overflow-hidden flex flex-col ${STATUS_BORDER[car.status] || "border-gray-200"}`}>
      {/* IMAGE */}
      <div className="relative h-44 bg-gray-100 overflow-hidden">
        {car.imageURL ? (
          <img src={car.imageURL} alt={`${car.brandName} ${car.modelName}`}
            className="w-full h-full object-cover"
            onError={e => { e.target.style.display = "none"; }} />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-300">
            <Icons.Car className="w-16 h-16" />
          </div>
        )}
        {/* Status badge — click to change */}
        <div className="absolute top-3 right-3 z-10">
          <button
            onClick={(e) => { e.stopPropagation(); setStatusOpen((v) => !v); }}
            disabled={statusSaving}
            title={car.statusReason && (car.status === "Inactive" || car.status === "Maintenance") ? `${car.status}: ${car.statusReason}` : undefined}
            className={`px-3 py-1 text-xs rounded-full font-semibold flex items-center gap-1 transition-opacity ${STATUS_STYLE[car.status] || "bg-gray-100 text-gray-600"} hover:opacity-80`}
          >
            {statusSaving ? "…" : car.status}
            <Icons.ChevronDown className="w-3 h-3" />
          </button>
          {statusOpen && (
            <div className="absolute right-0 mt-1 bg-white border border-gray-100 rounded-xl shadow-xl overflow-hidden z-20 min-w-[130px]">
              {CAR_STATUSES.map((s) => (
                <button key={s} onClick={(e) => { e.stopPropagation(); handleStatusChange(s); }}
                  className={`w-full text-left px-3 py-2 text-xs font-medium flex items-center gap-2 hover:bg-gray-50 transition-colors ${s === car.status ? "opacity-50 cursor-default" : ""}`}>
                  <span className={`w-2 h-2 rounded-full ${s === "Active" ? "bg-green-500" : s === "Inactive" ? "bg-gray-400" : "bg-red-500"}`}/>
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* BODY */}
      <div className="p-4 flex flex-col gap-3 flex-1">
        {/* Brand + Model as title */}
        <div>
          <h3 className="font-bold text-gray-800 text-base leading-tight">
            {car.brandName} {car.modelName}
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">{car.bodyType || "—"} · {car.year || "—"}</p>
          <span className="text-xs bg-gray-100 px-2 py-0.5 rounded-md mt-1 inline-block text-gray-600">
            {car.platenumber || car.plateNumber || "—"}
          </span>
        </div>

        {/* Why this car is out of service, shown directly on the card —
            previously this only existed as a hover title="" tooltip on
            the badge above, which is unreachable on touch/mobile and
            easy to miss even on desktop. Staff scanning the fleet grid
            should see this without opening Details. */}
        {(car.status === "Inactive" || car.status === "Maintenance") && car.statusReason && (
          <div className={`flex items-start gap-1.5 text-xs rounded-lg px-2 py-1.5 -mt-1 ${car.status === "Maintenance" ? "bg-red-50 text-red-600" : "bg-gray-100 text-gray-500"}`}>
            <span className="shrink-0">{car.status === "Maintenance" ? "🔧" : "⛔"}</span>
            <span className="line-clamp-2">{car.statusReason}</span>
          </div>
        )}

        {/* Short Description */}
        {car.shortDescription && (
          <p className="text-xs text-gray-500 leading-relaxed line-clamp-2">{car.shortDescription}</p>
        )}

        {/* Specs */}
        <div className="grid grid-cols-3 text-xs text-center border-t border-b py-2">
          <div><p className="text-gray-400">Seats</p><p className="font-semibold text-gray-700">{car.seatingCapacity || "—"}</p></div>
          <div><p className="text-gray-400">Fuel</p><p className="font-semibold text-gray-700">{car.fuelType || "—"}</p></div>
          <div><p className="text-gray-400">Trans.</p><p className="font-semibold text-gray-700">{car.transmission || "—"}</p></div>
        </div>

        {/* Price + rented info + buttons */}
        <div className="flex justify-between items-end flex-1">
          <div>
            {basePrice && (
              <p className="text-sm font-bold text-teal-700">
                {fmt(basePrice.price)}
                <span className="text-xs font-normal text-gray-400 ml-1">/{basePrice.durationType}</span>
              </p>
            )}
            {(car.status === "Rented" || car.status === "Reserved") && nearestBooking && (
              <p className="text-xs text-blue-600 font-medium mt-0.5 flex items-center gap-1">
                <Icons.Calendar className="w-3 h-3" />
                Until {fmtDate(nearestBooking.endDateTime)}
              </p>
            )}
          </div>
          <div className="flex gap-2">
            <button onClick={onDelete} className="p-1.5 border border-red-200 rounded-lg text-red-500 hover:bg-red-50">
              <Icons.Trash className="w-4 h-4" />
            </button>
            {canEdit && (
              <button onClick={onEdit} className="flex items-center gap-1.5 px-3 py-1.5 border rounded-lg text-xs text-gray-600 hover:bg-gray-50">
                <Icons.Edit className="w-3.5 h-3.5" />
                Edit
              </button>
            )}
            <button onClick={onViewDetails} className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs hover:bg-teal-700">
              Details
              <Icons.ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
      {statusChangeTarget && (
        <StatusChangeFlow
          car={car}
          carLabel={carLabel}
          targetStatus={statusChangeTarget}
          onCancel={() => setStatusChangeTarget(null)}
          onDone={handleStatusChangeDone}
        />
      )}
    </div>
  );
}

// Small modal collecting why a car is being switched to Maintenance or
// Inactive — a required, free-text reason either way. Written to the car
// doc as statusReason and surfaced via a tooltip on the status badge and
// in the details modal. Shared between both statuses so staff give a
// reason no matter which direction the car is leaving Active for.
function StatusReasonModal({ carLabel, status, saving, onConfirm, onCancel }) {
  const [reason, setReason] = useState("");
  const trimmed = reason.trim();
  const verb = status === "Maintenance" ? "sent for maintenance" : "taken out of service";

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4">
        <div>
          <h3 className="font-bold text-gray-800 text-lg">Mark as {status}</h3>
          <p className="text-sm text-gray-500 mt-1">Why is <span className="font-medium text-gray-700">{carLabel}</span> being {verb}?</p>
        </div>
        <div>
          <label className="text-xs font-medium text-gray-500">Reason</label>
          <input type="text" value={reason} onChange={(e) => setReason(e.target.value)}
            placeholder={status === "Maintenance" ? "e.g. Scheduled oil change, Flat tire…" : "e.g. Sold, Retired, Stolen/Lost…"}
            autoFocus
            className="w-full mt-1 border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400" />
        </div>
        <div className="flex gap-3">
          <button onClick={onCancel} disabled={saving}
            className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50">
            Cancel
          </button>
          <button onClick={() => onConfirm(trimmed)} disabled={saving || !trimmed}
            className="flex-1 px-4 py-2 bg-gray-700 text-white rounded-xl text-sm font-medium hover:bg-gray-800 disabled:opacity-50">
            {saving ? "Saving…" : "Confirm"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── STATUS CHANGE FLOW (reason → OTP → confirm+refund, batch-fired once) ────
// Orchestrates the full gate before a car can be switched to Maintenance or
// Inactive. Shared by the quick status badge (VehicleCard) and the Edit
// Vehicle modal's Status field — the only two places a car's status can be
// changed — so this gate can never be bypassed from either one.
//
// The OTP screen comes right after the reason, but the code it collects
// ISN'T checked yet — it just gets carried forward and verified server-side
// at the very last step, in the same call that actually fires the refunds.
// That's deliberate: OTP codes are single-use, so checking it early and
// checking it at the point money actually moves can't both be true. If a
// batch stops partway (one booking fails), that code is already spent —
// this drops back to the OTP step for a fresh one rather than trying to
// reuse it, carrying forward what already succeeded so staff aren't
// starting over blind.
function StatusChangeFlow({ car, carLabel, targetStatus, onDone, onCancel }) {
  const [step, setStep] = useState("reason"); // "reason" | "otp" | "confirm"
  const [reason, setReason] = useState("");
  const [otp, setOtp] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [lastResults, setLastResults] = useState(null); // refundResults from a stopped attempt, for context on retry

  const submitBatch = async () => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      const data = await apiFetch(`/api/fleet/cars/${car.id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status: targetStatus, statusReason: reason, otp }),
      });
      if (data.statusChanged) {
        onDone(targetStatus, reason);
        return;
      }
      // Stopped partway — anything in data.refundResults before the
      // "failed" entry already happened for real and can't be undone. The
      // OTP that was just checked is now spent; back to that step for a
      // fresh one, carrying the results forward so the next "confirm"
      // screen (and this message) has context instead of starting blind.
      setLastResults(data.refundResults || []);
      setOtp("");
      setStep("otp");
    } catch (e) {
      setSubmitError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (step === "reason") {
    return (
      <StatusReasonModal
        carLabel={carLabel}
        status={targetStatus}
        saving={false}
        onConfirm={(r) => { setReason(r); setStep("otp"); }}
        onCancel={onCancel}
      />
    );
  }

  if (step === "otp") {
    return (
      <OtpConfirmModal
        carLabel={carLabel}
        targetStatus={targetStatus}
        priorResults={lastResults}
        onNext={(code) => { setOtp(code); setStep("confirm"); }}
        onCancel={onCancel}
      />
    );
  }

  return (
    <AreYouSureRefundModal
      car={car}
      carLabel={carLabel}
      targetStatus={targetStatus}
      reason={reason}
      submitting={submitting}
      submitError={submitError}
      onSubmit={submitBatch}
      onCancel={onCancel}
    />
  );
}

// ─── OTP CONFIRM MODAL ─────────────────────────────────────────────────────
// Step 2 of StatusChangeFlow — collects the code but does NOT verify it
// here (see the flow's own comment above for why). Confirms the STAFF
// member making the change, not the customer: a code sent to the logged-in
// admin/supervisor/owner's own email via POST /api/auth/send-otp, same
// "prove it's really you" mechanic already used for role changes.
function OtpConfirmModal({ carLabel, targetStatus, priorResults, onNext, onCancel }) {
  const { user } = useAuth();
  const [otp, setOtp] = useState("");
  const [sendState, setSendState] = useState("sending"); // "sending" | "sent" | "error"
  const [sendMessage, setSendMessage] = useState(null);
  // Guards against React StrictMode's intentional double-invoke of effects
  // in development (mount → effect → cleanup → effect again, on the same
  // instance). Without this, that double-invoke fires sendCode() twice on
  // mount — two real /send-otp calls, two emails, and since the backend
  // stores the code with a plain overwrite (adminOtpCodes/{email}.set(...)),
  // whichever of the two calls' writes lands second silently invalidates
  // the code in the email that arrived first. A ref survives the
  // double-invoke (only the effect re-runs, not the component instance),
  // so this makes sure the real network call only ever fires once per mount.
  const sentOnceRef = useRef(false);

  const sendCode = useCallback(async () => {
    setSendState("sending");
    setSendMessage(null);
    try {
      const json = await apiFetchFull("/api/auth/send-otp", { method: "POST" });
      if (json.emailSent === false) {
        setSendState("error");
        setSendMessage(json.message || "Couldn't send the code — check the email configuration.");
      } else {
        setSendState("sent");
      }
    } catch (e) {
      setSendState("error");
      setSendMessage(e.message);
    }
  }, []);

  useEffect(() => {
    if (sentOnceRef.current) return;
    sentOnceRef.current = true;
    sendCode();
  }, [sendCode]);

  const [checking, setChecking] = useState(false);
  const [checkError, setCheckError] = useState(null);
  const trimmed = otp.trim();
  const resolvedCount = priorResults?.filter((r) => r.outcome !== "failed").length || 0;
  const failedResult = priorResults?.find((r) => r.outcome === "failed");

  // Real check (peekOtp on the backend — wrong digits, expired, locked out
  // all genuinely apply) but doesn't burn the code, since nothing's
  // actually happening yet at this screen. Lets staff know right away if
  // they mistyped it instead of finding out only after staging every
  // booking on the next screen. The code still gets verified for real
  // (and actually consumed) at the final "Confirm & Change Status" step.
  const handleContinue = async () => {
    setChecking(true);
    setCheckError(null);
    try {
      await apiFetch("/api/auth/check-otp", { method: "POST", body: JSON.stringify({ otp: trimmed }) });
      onNext(trimmed);
    } catch (e) {
      setCheckError(e.message);
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4">
        <div>
          <h3 className="font-bold text-gray-800 text-lg">Confirm it's you</h3>
          <p className="text-sm text-gray-500 mt-1">
            Enter the code sent to <span className="font-medium text-gray-700">{user?.email || "your email"}</span> to
            {priorResults ? " finish" : " start"} switching <span className="font-medium text-gray-700">{carLabel}</span> to {targetStatus}.
          </p>
        </div>

        {priorResults && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-800">
            {resolvedCount} booking(s) were already resolved before the last attempt stopped
            {failedResult ? ` at ${failedResult.bookingID} (${failedResult.error})` : ""}. That code's already used —
            this one will pick up where it left off; anything already resolved won't be touched again.
          </div>
        )}

        {sendState === "sending" && <p className="text-xs text-gray-400">Sending code…</p>}
        {sendState === "error" && <p className="text-xs text-red-600">{sendMessage}</p>}

        <div>
          <label className="text-xs font-medium text-gray-500">6-digit code</label>
          <input type="text" inputMode="numeric" maxLength={6} value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
            placeholder="000000" autoFocus
            className="w-full mt-1 border rounded-xl px-3 py-2 text-sm tracking-widest outline-none focus:ring-2 focus:ring-teal-400" />
        </div>

        {checkError && <p className="text-xs text-red-600">{checkError}</p>}

        <button onClick={sendCode} disabled={sendState === "sending"}
          className="text-xs text-teal-600 hover:underline disabled:opacity-50">
          Resend code
        </button>

        <div className="flex gap-3">
          <button onClick={onCancel} disabled={checking}
            className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50">
            Cancel
          </button>
          <button onClick={handleContinue} disabled={trimmed.length !== 6 || checking}
            className="flex-1 px-4 py-2 bg-gray-700 text-white rounded-xl text-sm font-medium hover:bg-gray-800 disabled:opacity-50">
            {checking ? "Checking…" : "Continue"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── ARE YOU SURE + REFUND MODAL ──────────────────────────────────────────────
// Final step of StatusChangeFlow. Shows the reason up top, then every
// upcoming booking on this car with a Refund row + live ₱ amount (each one
// staged locally with its own confirm click — nothing is sent to the
// server yet), every ongoing booking as an FYI-only row (car's already
// with that customer, nothing to refund there), and — for context on a
// retry — every booking already resolved by an earlier attempt on this
// same car. "Confirm & Change Status" is the ONLY thing that talks to the
// server: it fires the whole batch (refunds + cancels + the status write)
// in one call, all or nothing up to the first real failure — see
// StatusChangeFlow.submitBatch and changeCarStatus() on the backend.
function AreYouSureRefundModal({ car, carLabel, targetStatus, reason, submitting, submitError, onSubmit, onCancel }) {
  const { fmt } = useCurrency();
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [upcoming, setUpcoming] = useState([]); // [{ ...booking, refundPreview, staged }]
  const [ongoing, setOngoing] = useState([]);
  const [resolved, setResolved] = useState([]);
  // bookingID of the row whose mini confirm modal is open, or null. Clicking
  // a row's button never stages it directly anymore — it opens this modal
  // (booking details + who booked + the payment breakdown) and staging only
  // happens from a real Confirm click inside that modal.
  const [activeBookingID, setActiveBookingID] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    apiFetch(`/api/fleet/cars/${car.id}/status-change-preview`)
      .then((data) => {
        if (cancelled) return;
        setUpcoming((data?.upcoming || []).map((b) => ({ ...b, staged: false })));
        setOngoing(data?.ongoing || []);
        setResolved(data?.resolved || []);
      })
      .catch((e) => !cancelled && setLoadError(e.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [car.id]);

  const toggleStaged = (bookingID) => {
    setUpcoming((list) => list.map((b) => b.bookingID === bookingID ? { ...b, staged: !b.staged } : b));
  };

  const dateRange = (b) => {
    const fmtDate = (v) => {
      const d = v?.toDate ? v.toDate() : (v ? new Date(v) : null);
      return d && !isNaN(d) ? d.toLocaleDateString() : "—";
    };
    return `${fmtDate(b.startDateTime)} – ${fmtDate(b.endDateTime)}`;
  };

  const resolvedLabel = (r) => {
    if (r.outcome === "refunded") return `Refunded ${fmt(r.amount || 0)}`;
    if (r.outcome === "already_refunded") return "Cancelled — already refunded earlier";
    if (r.outcome === "nothing_owed") return "Cancelled — nothing had been paid";
    return "Resolved";
  };

  const allStaged = upcoming.length === 0 || upcoming.every((b) => b.staged);
  const activeBooking = upcoming.find((b) => b.bookingID === activeBookingID) || null;

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg p-6 space-y-4 max-h-[85vh] overflow-y-auto">
        <div>
          <h3 className="font-bold text-gray-800 text-lg">Are you sure?</h3>
          <p className="text-sm text-gray-500 mt-1">
            Switching <span className="font-medium text-gray-700">{carLabel}</span> to {targetStatus}.
          </p>
          <p className="text-sm text-gray-600 bg-gray-50 border rounded-lg px-3 py-2 mt-2">
            <span className="font-medium">Reason:</span> {reason}
          </p>
        </div>

        {loading ? (
          <p className="text-sm text-gray-400 py-6 text-center">Checking bookings…</p>
        ) : loadError ? (
          <p className="text-sm text-red-600 py-4">{loadError}</p>
        ) : (
          <div className="space-y-4">
            {upcoming.length > 0 && (
              <div>
                <p className="text-xs font-medium text-gray-500 mb-2">
                  Upcoming bookings — confirm each one below; nothing is actually refunded until "Confirm & Change Status" is clicked
                </p>
                <div className="space-y-2">
                  {upcoming.map((b) => (
                    <div key={b.bookingID}
                      className={`border rounded-xl p-3 flex items-center justify-between gap-3 ${b.refundPreview?.alreadyRefunded ? "bg-amber-50 border-amber-200" : ""}`}>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-gray-800 truncate">{b.bookingID}</p>
                        <p className="text-xs text-gray-500">{b.customerName || "—"} · {dateRange(b)}</p>
                        {b.refundPreview?.alreadyRefunded ? (
                          <p className="text-xs text-amber-700 mt-1">Payment already refunded earlier — this will just cancel the booking to match.</p>
                        ) : (
                          <p className="text-xs text-gray-500">{fmt(b.refundPreview?.total || 0)} to refund</p>
                        )}
                      </div>
                      <button
                        onClick={() => setActiveBookingID(b.bookingID)}
                        className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium ${
                          b.staged
                            ? "bg-emerald-600 text-white hover:bg-emerald-700"
                            : b.refundPreview?.alreadyRefunded
                              ? "bg-amber-600 text-white hover:bg-amber-700"
                              : "bg-red-600 text-white hover:bg-red-700"
                        }`}>
                        {b.staged
                          ? "Confirmed ✓"
                          : b.refundPreview?.alreadyRefunded
                            ? "Confirm cancel"
                            : `Refund ${fmt(b.refundPreview?.total || 0)}`}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {ongoing.length > 0 && (
              <div>
                <p className="text-xs font-medium text-gray-500 mb-2">Ongoing — car is currently with the customer</p>
                <div className="space-y-2">
                  {ongoing.map((b) => (
                    <div key={b.bookingID} className="border rounded-xl p-3 bg-gray-50">
                      <p className="text-sm font-medium text-gray-800 truncate">{b.bookingID}</p>
                      <p className="text-xs text-gray-500">{dateRange(b)}</p>
                      <p className="text-xs text-gray-400 mt-1">No refund needed — trip already in progress.</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {resolved.length > 0 && (
              <div>
                <p className="text-xs font-medium text-gray-500 mb-2">Already resolved</p>
                <div className="space-y-2">
                  {resolved.map((b) => (
                    <div key={b.bookingID} className="border rounded-xl p-3 bg-gray-50 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-gray-800 truncate">{b.bookingID}</p>
                        <p className="text-xs text-gray-500">{dateRange(b)}</p>
                      </div>
                      <span className="shrink-0 text-xs font-medium text-emerald-600">{resolvedLabel(b)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {upcoming.length === 0 && ongoing.length === 0 && resolved.length === 0 && (
              <p className="text-sm text-gray-500 py-4">No upcoming or ongoing bookings on this car right now.</p>
            )}
          </div>
        )}

        {submitError && <p className="text-xs text-red-600">{submitError}</p>}

        <div className="flex gap-3 pt-2">
          <button onClick={onCancel} disabled={submitting}
            className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50">
            Cancel
          </button>
          <button onClick={onSubmit} disabled={loading || !!loadError || !allStaged || submitting}
            className="flex-1 px-4 py-2 bg-gray-700 text-white rounded-xl text-sm font-medium hover:bg-gray-800 disabled:opacity-50">
            {submitting ? "Processing…" : "Confirm & Change Status"}
          </button>
        </div>
      </div>

      {activeBooking && (
        <BookingConfirmModal
          booking={activeBooking}
          fmt={fmt}
          dateRange={dateRange}
          onConfirm={() => { toggleStaged(activeBooking.bookingID); setActiveBookingID(null); }}
          onUnconfirm={() => { toggleStaged(activeBooking.bookingID); setActiveBookingID(null); }}
          onClose={() => setActiveBookingID(null)}
        />
      )}
    </div>
  );
}

// ─── BOOKING CONFIRM MODAL ─────────────────────────────────────────────────
// Opens on top of AreYouSureRefundModal when a booking's row is clicked —
// booking ID, who booked it, the dates, and the payment breakdown, with its
// own real Confirm button. Nothing gets staged just from clicking the row
// button anymore; this is the actual "are you sure about THIS one"
// step — the row button only opens it.
function BookingConfirmModal({ booking, fmt, dateRange, onConfirm, onUnconfirm, onClose }) {
  const already = booking.refundPreview?.alreadyRefunded;
  const hasManual = !already && (booking.refundPreview?.manualAmount || 0) > 0;

  return (
    <div className="fixed inset-0 z-[70] bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4">
        <h4 className="font-bold text-gray-800 text-lg">
          {booking.staged ? "Already confirmed" : "Confirm this booking"}
        </h4>

        <div className="text-sm space-y-1.5">
          <p><span className="text-gray-500">Booking:</span> <span className="font-medium text-gray-800">{booking.bookingID}</span></p>
          <p><span className="text-gray-500">Booked by:</span> <span className="font-medium text-gray-800">{booking.customerName || "—"}</span></p>
          <p><span className="text-gray-500">Dates:</span> {dateRange(booking)}</p>

          {already ? (
            <p className="text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mt-2">
              Payment already refunded earlier — confirming this will just cancel the booking to match. No new refund is issued.
            </p>
          ) : (
            <div className="bg-gray-50 border rounded-lg px-3 py-2 mt-2 space-y-0.5">
              <p><span className="text-gray-500">To refund:</span> <span className="font-medium text-gray-800">{fmt(booking.refundPreview?.total || 0)}</span></p>
              {hasManual && (
                <p className="text-xs text-gray-500">
                  {fmt(booking.refundPreview.onlineAmount || 0)} via PayMongo + {fmt(booking.refundPreview.manualAmount)} handed back in person
                </p>
              )}
            </div>
          )}
        </div>

        <div className="flex gap-3 pt-2">
          <button onClick={onClose}
            className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            Close
          </button>
          {booking.staged ? (
            <button onClick={onUnconfirm}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-xl text-sm font-medium hover:bg-gray-300">
              Un-confirm
            </button>
          ) : (
            <button onClick={onConfirm}
              className={`flex-1 px-4 py-2 text-white rounded-xl text-sm font-medium ${already ? "bg-amber-600 hover:bg-amber-700" : "bg-red-600 hover:bg-red-700"}`}>
              {already ? "Confirm cancel" : `Confirm refund ${fmt(booking.refundPreview?.total || 0)}`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── VIEW DETAILS MODAL ───────────────────────────────────────────────────────
function ViewDetailsModal({ car, canEdit, onClose, onEdit }) {
  const { fmt } = useCurrency();
  const navigate = useNavigate();
  const [bookings, setBookings]   = useState([]);
  const [loading, setLoading]     = useState(true);
  const [allImages, setAllImages] = useState([]);
  const [activeImg, setActiveImg] = useState(car.imageURL || null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const imgSnap = await getDocs(query(collection(db, "carImages"), where("carID", "==", car.id)));
        const imgs = imgSnap.docs.map(d => d.data().imageURL).filter(Boolean);
        setAllImages(imgs);
        if (imgs.length > 0) setActiveImg(imgs[0]);

        // Query by carID only — status is written by the customer-facing
        // backend, so its exact casing isn't guaranteed here. Filter
        // client-side with toLowerCase(), same as Vehicle Inspection's
        // Past Trips does for this same status check.
        const bSnap = await getDocs(query(
          collection(db, "bookings"),
          where("carID", "==", car.carID || car.id)
        ));
        // "upcoming"/"ongoing" ARE the "still open" states — same as the
        // backend's own definition (see dashboard.service.js's upcoming
        // count and midinghtFlush.job.js's checkOverdueBookings), both of
        // which key off status alone. Neither status auto-clears itself
        // once its date passes — a no-show pickup stays "upcoming" and an
        // overdue return stays "ongoing" until staff act on it — so an
        // extra endDateTime >= now check here only hid bookings that are
        // still genuinely open, including every real case in this car's
        // data.
        const future = bSnap.docs.map(d => ({ id: d.id, ...d.data() }))
          .filter(b => ["upcoming", "ongoing"].includes(b.status?.toLowerCase()))
          .sort((a, b) => {
            const aD = a.startDateTime?.toDate ? a.startDateTime.toDate() : new Date(a.startDateTime);
            const bD = b.startDateTime?.toDate ? b.startDateTime.toDate() : new Date(b.startDateTime);
            return aD - bD;
          });

        // Resolve booker names — same lookup Vehicle Inspection uses for
        // an active booking's customer: userDetails (firstName/lastName)
        // falling back to user (username/email), both keyed by userID.
        const withNames = await Promise.all(future.map(async (b) => {
          if (!b.userID) return { ...b, customerName: "Customer" };
          try {
            const [detailDoc, userDoc] = await Promise.all([
              getDoc(doc(db, "userDetails", b.userID)),
              getDoc(doc(db, "user", b.userID)),
            ]);
            const { firstName = "", lastName = "" } = detailDoc.exists() ? detailDoc.data() : {};
            const fullName = [firstName, lastName].filter(Boolean).join(" ").trim();
            const { username = "", email = "" } = userDoc.exists() ? userDoc.data() : {};
            return { ...b, customerName: fullName || username || email || "Customer" };
          } catch {
            return { ...b, customerName: "Customer" };
          }
        }));
        setBookings(withNames);
      } catch (e) {
        console.error("ViewDetails error:", e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [car.id, car.carID]);

  const sorted = sortPricing(car.pricing || []);

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>

        <div className="flex justify-between items-center p-5 border-b sticky top-0 bg-white z-10">
          <div>
            <h2 className="font-bold text-xl text-gray-800">{car.brandName} {car.modelName}</h2>
            <p className="text-sm text-gray-400">{car.bodyType} · {car.platenumber || car.plateNumber}</p>
          </div>
          <div className="flex gap-2 items-center">
            {canEdit && (
              <button onClick={onEdit} className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl text-sm hover:bg-teal-700">
                <Icons.Edit className="w-4 h-4" />
                Edit
              </button>
            )}
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
              <Icons.Close className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-5 space-y-5">
          {/* Image gallery */}
          <div>
            <div className="h-56 bg-gray-100 rounded-xl overflow-hidden">
              {activeImg
                ? <img src={activeImg} alt="car" className="w-full h-full object-cover" />
                : <div className="flex items-center justify-center h-full text-gray-300"><Icons.Car className="w-16 h-16" /></div>
              }
            </div>
            {allImages.length > 1 && (
              <div className="flex gap-2 mt-2 overflow-x-auto pb-1">
                {allImages.map((img, i) => (
                  <img key={i} src={img} onClick={() => setActiveImg(img)} alt={`Vehicle view ${i + 1}`}
                    className={`h-14 w-20 object-cover rounded-lg cursor-pointer border-2 flex-shrink-0 ${activeImg === img ? "border-teal-500" : "border-transparent"}`} />
                ))}
              </div>
            )}
          </div>

          {/* Details grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            {[
              ["Seats", car.seatingCapacity], ["Fuel", car.fuelType],
              ["Trans.", car.transmission],   ["Color", car.color],
              ["Year", car.year],             ["Body", car.bodyType],
              ["Status", car.status],
            ].map(([label, val]) => (
              <div key={label} className="bg-gray-50 rounded-xl p-3">
                <p className="text-xs text-gray-400">{label}</p>
                <p className="font-semibold text-gray-800 mt-0.5">{val || "—"}</p>
              </div>
            ))}
          </div>

          {(car.status === "Inactive" || car.status === "Maintenance") && car.statusReason && (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm">
              <p className="text-xs text-gray-400">{car.status} Reason</p>
              <p className="font-semibold text-gray-800 mt-0.5">{car.statusReason}</p>
            </div>
          )}

          {/* Pricing (12 Hours last) */}
          {sorted.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Pricing Tiers</h3>
              <div className="flex flex-wrap gap-2">
                {sorted.map((p, i) => (
                  <div key={i} className="bg-teal-50 border border-teal-100 rounded-xl px-4 py-2 text-sm">
                    <p className="text-xs text-gray-400">{p.durationType}</p>
                    <p className="font-bold text-teal-700">{fmt(p.price)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Short Description */}
          {car.shortDescription && (
            <div>
              <h3 className="font-semibold text-gray-700 mb-1">Short Description</h3>
              <p className="text-sm text-gray-600">{car.shortDescription}</p>
            </div>
          )}

          {/* Long Description */}
          {car.longDescription && (
            <div>
              <h3 className="font-semibold text-gray-700 mb-1">Long Description</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{car.longDescription}</p>
            </div>
          )}

          {/* Upcoming bookings */}
          <div>
            <h3 className="font-semibold text-gray-700 mb-2 flex items-center gap-2">
              Upcoming & Active Bookings
              <span className="text-xs bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full">{bookings.length}</span>
            </h3>
            {loading ? (
              <div className="space-y-2">{[...Array(2)].map((_, i) => <div key={i} className="h-14 bg-gray-100 rounded-xl animate-pulse" />)}</div>
            ) : bookings.length === 0 ? (
              <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4 text-center">No upcoming bookings</p>
            ) : (
              <div className="space-y-2">
                {bookings.map(b => (
                  <div key={b.id} className="flex justify-between items-center bg-gray-50 rounded-xl px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-gray-800">{b.customerName || "Customer"}</p>
                      <p className="text-xs text-gray-400">{fmtDate(b.startDateTime)} → {fmtDate(b.endDateTime)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${
                        b.status?.toLowerCase() === "ongoing" ? "bg-blue-50 border border-blue-200 text-black" : "bg-yellow-50 border border-yellow-200 text-black"
                      }`}>{b.status}</span>
                      <button
                        onClick={() => navigate(`/bookings?open=${b.bookingID || b.id}`)}
                        className="flex items-center gap-1 text-xs font-medium text-teal-600 hover:text-teal-700 px-2 py-1 rounded-lg hover:bg-teal-50"
                      >
                        View
                        <Icons.ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── PRICING ICON ─────────────────────────────────────────────────────────────
const PricingIcon = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="1" x2="12" y2="23" />
    <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
  </svg>
);

// ─── DETAILS FORM ─────────────────────────────────────────────────────────────
function CarDetailsForm({ form, setForm, imagePreview, onImageChange, brands, models, currentStatus, onStatusChangeRequest }) {
  const filteredModels = models.filter(m => m.brandID === form.brandID);

  const Field = ({ label, name, type = "text", options }) => (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      {options ? (
        <select value={form[name] || ""} onChange={e => setForm(f => ({ ...f, [name]: e.target.value }))}
          className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400">
          <option value="">Select {label}</option>
          {options.map(o => <option key={o.value || o} value={o.value || o}>{o.label || o}</option>)}
        </select>
      ) : (
        <input type={type} value={form[name] || ""}
          onChange={e => setForm(f => ({ ...f, [name]: e.target.value }))}
          className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400" />
      )}
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Image */}
      <div>
        <label className="block text-xs font-medium text-gray-500 mb-2">Primary Photo</label>
        <div className="flex gap-4 items-center">
          <div className="w-28 h-20 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0">
            {imagePreview
              ? <img src={imagePreview} alt="preview" className="w-full h-full object-cover" />
              : <div className="flex items-center justify-center h-full text-gray-300"><Icons.Camera className="w-8 h-8" /></div>
            }
          </div>
          <label className="cursor-pointer flex items-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-xl text-sm text-gray-500 hover:border-teal-400 hover:text-teal-600 transition-colors">
            <Icons.Camera className="w-4 h-4" />
            Choose Image
            <input type="file" accept="image/*" className="hidden" onChange={onImageChange} />
          </label>
        </div>
      </div>

      {/* Brand + Model */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Brand</label>
          <select value={form.brandID || ""} onChange={e => setForm(f => ({ ...f, brandID: e.target.value, modelID: "" }))}
            className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400">
            <option value="">Select Brand</option>
            {brands.map(b => <option key={b.id} value={b.id}>{b.brandName}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Model</label>
          <select value={form.modelID || ""} onChange={e => setForm(f => ({ ...f, modelID: e.target.value }))}
            className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400"
            disabled={!form.brandID}>
            <option value="">Select Model</option>
            {filteredModels.map(m => <option key={m.id} value={m.id}>{m.modelName}</option>)}
          </select>
        </div>
      </div>

      {/* Other fields */}
      <div className="grid grid-cols-2 gap-4">
        <Field label="Plate Number"   name="platenumber" />
        <Field label="Color"          name="color" />
        <Field label="Body Type"      name="bodyType" />
        <Field label="Year"           name="year" type="number" />
        <Field label="Seats"          name="seatingCapacity" type="number" />
        <Field label="Fuel Type"      name="fuelType"     options={["Gasoline","Diesel","Electric","Hybrid"]} />
        <Field label="Transmission"   name="transmission" options={["Automatic","Manual"]} />
        <div>
          <label className="block text-xs font-medium text-gray-500 mb-1">Status</label>
          <select
            value={form.status || "Active"}
            onChange={(e) => {
              const newStatus = e.target.value;
              // Gate only applies when a handler was given (EditCarModal;
              // AddCarModal has no car yet so no bookings to worry about)
              // and it's an actual move INTO Maintenance/Inactive.
              if (onStatusChangeRequest && ["Maintenance", "Inactive"].includes(newStatus) && newStatus !== currentStatus) {
                onStatusChangeRequest(newStatus); // opens reason → refund → OTP; form.status only updates once that succeeds
                return;
              }
              setForm(f => ({ ...f, status: newStatus }));
            }}
            className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400">
            <option value="Active">Active</option>
            <option value="Maintenance">Maintenance</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Short Description */}
      <div>
        <label className="block text-xs font-medium text-gray-500 mb-1">Short Description</label>
        <input value={form.shortDescription || ""} onChange={e => setForm(f => ({ ...f, shortDescription: e.target.value }))}
          className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400" />
      </div>

      {/* Long Description */}
      <div>
        <label className="block text-xs font-medium text-gray-500 mb-1">Long Description</label>
        <textarea rows={3} value={form.longDescription || ""}
          onChange={e => setForm(f => ({ ...f, longDescription: e.target.value }))}
          className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400 resize-none" />
      </div>
    </div>
  );
}

// ─── PRICING FORM (standalone tab) ────────────────────────────────────────────
function PricingForm({ pricing, setPricing }) {
  // editingIdx: which tier is currently in edit mode (-1 = none, "new" = new tier being added)
  const [editingIdx, setEditingIdx] = useState(null);
  // draft holds the temp values while editing
  const [draft, setDraft] = useState({ durationType: "", price: "" });

  const sorted = sortPricing(pricing);

  const DURATION_SUGGESTIONS = ["3 Hours", "6 Hours", "12 Hours", "24 Hours", "Full Day", "2 Days", "Weekly"];

  const startEdit = (idx) => {
    setEditingIdx(idx);
    setDraft({ durationType: sorted[idx].durationType, price: sorted[idx].price });
  };

  const cancelEdit = () => {
    setEditingIdx(null);
    setDraft({ durationType: "", price: "" });
  };

  const saveEdit = (idx) => {
    // find the actual index in the unsorted pricing array matching the sorted item
    const target = sorted[idx];
    setPricing(prev => prev.map(p =>
      p === target ? { ...p, durationType: draft.durationType, price: draft.price } : p
    ));
    cancelEdit();
  };

  const startAdd = () => {
    setEditingIdx("new");
    setDraft({ durationType: "", price: "" });
  };

  const saveNew = () => {
    if (!draft.durationType || draft.price === "") return;
    setPricing(prev => [...prev, { durationType: draft.durationType, price: draft.price }]);
    cancelEdit();
  };

  const removeTier = (idx) => {
    const target = sorted[idx];
    setPricing(prev => prev.filter(p => p !== target));
    if (editingIdx === idx) cancelEdit();
  };

  return (
    <div className="space-y-5">
      {/* Header info */}
      <div className="bg-teal-50 border border-teal-100 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <PricingIcon className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-teal-800">Pricing Tiers</p>
            <p className="text-xs text-teal-600 mt-0.5">Click Edit on a tier to modify it. "12 Hours" tier will always appear last.</p>
          </div>
        </div>
      </div>

      {/* Existing tiers */}
      <div className="space-y-3">
        {sorted.length === 0 && editingIdx !== "new" && (
          <div className="text-center py-10 text-gray-400">
            <PricingIcon className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No pricing tiers yet</p>
            <p className="text-xs mt-1">Click "Add Pricing Tier" to get started</p>
          </div>
        )}

        {sorted.map((p, i) => {
          const isEditing = editingIdx === i;
          return (
            <div key={p.id || `new-${i}`} className={`rounded-xl border transition-all ${isEditing ? "border-teal-300 bg-teal-50/40" : "border-gray-100 bg-gray-50"}`}>
              {isEditing ? (
                /* ── Edit mode ── */
                <div className="p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-semibold text-teal-700 uppercase tracking-wide">Editing Tier {i + 1}</span>
                    <button onClick={() => removeTier(i)} type="button"
                      className="flex items-center gap-1 text-xs text-red-400 hover:text-red-600 px-2 py-1 rounded-lg hover:bg-red-50 transition-colors">
                      <Icons.Trash className="w-3.5 h-3.5" />
                      Remove
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Duration Type</label>
                      <input value={draft.durationType} placeholder="e.g. 24 Hours"
                        onChange={e => setDraft(d => ({ ...d, durationType: e.target.value }))}
                        list="dur-suggestions"
                        className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400 bg-white" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Price (₱)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-sm text-gray-400 font-medium">₱</span>
                        <input type="number" value={draft.price} min={0} placeholder="0.00"
                          onChange={e => setDraft(d => ({ ...d, price: e.target.value }))}
                          className="w-full border rounded-xl pl-8 pr-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400 bg-white" />
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button onClick={() => saveEdit(i)} type="button"
                      className="flex items-center gap-1.5 px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-semibold hover:bg-teal-700 transition-colors">
                      <Icons.Edit className="w-3.5 h-3.5" />
                      Save
                    </button>
                    <button onClick={cancelEdit} type="button"
                      className="px-4 py-2 border rounded-xl text-xs text-gray-600 hover:bg-gray-100 transition-colors">
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                /* ── Read-only mode ── */
                <div className="flex items-center justify-between px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-gray-400 font-medium w-12">Tier {i + 1}</span>
                    <span className="bg-teal-50 border border-teal-100 text-teal-700 text-xs font-semibold px-3 py-1 rounded-full">
                      ₱{Number(p.price).toLocaleString()} / {p.durationType}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => removeTier(i)} type="button"
                      className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                      <Icons.Trash className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => startEdit(i)} type="button"
                      disabled={editingIdx !== null}
                      className="flex items-center gap-1.5 px-3 py-1.5 border rounded-lg text-xs text-gray-600 hover:bg-gray-100 transition-colors disabled:opacity-40">
                      <Icons.Edit className="w-3.5 h-3.5" />
                      Edit
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* New tier form */}
        {editingIdx === "new" && (
          <div className="rounded-xl border border-teal-300 bg-teal-50/40 p-4 space-y-3">
            <span className="text-xs font-semibold text-teal-700 uppercase tracking-wide">New Tier</span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Duration Type</label>
                <input value={draft.durationType} placeholder="e.g. 24 Hours"
                  onChange={e => setDraft(d => ({ ...d, durationType: e.target.value }))}
                  list="dur-suggestions"
                  className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400 bg-white" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Price (₱)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-sm text-gray-400 font-medium">₱</span>
                  <input type="number" value={draft.price} min={0} placeholder="0.00"
                    onChange={e => setDraft(d => ({ ...d, price: e.target.value }))}
                    className="w-full border rounded-xl pl-8 pr-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400 bg-white" />
                </div>
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <button onClick={saveNew} type="button"
                disabled={!draft.durationType || draft.price === ""}
                className="flex items-center gap-1.5 px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-semibold hover:bg-teal-700 disabled:opacity-40 transition-colors">
                <Icons.Edit className="w-3.5 h-3.5" />
                Save
              </button>
              <button onClick={cancelEdit} type="button"
                className="px-4 py-2 border rounded-xl text-xs text-gray-600 hover:bg-gray-100 transition-colors">
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      <datalist id="dur-suggestions">
        {DURATION_SUGGESTIONS.map(s => <option key={s} value={s} />)}
      </datalist>

      {/* Add tier button — hidden while editing */}
      {editingIdx === null && (
        <button onClick={startAdd} type="button"
          className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-teal-200 rounded-xl text-sm text-teal-600 hover:border-teal-400 hover:bg-teal-50 transition-colors font-medium">
          <Icons.Plus className="w-4 h-4" />
          Add Pricing Tier
        </button>
      )}
    </div>
  );
}

// ─── EDIT CAR MODAL ───────────────────────────────────────────────────────────
function EditCarModal({ car, brands, models, onClose, onSaved }) {
  const [activeTab, setActiveTab] = useState("details");
  const [form, setForm]         = useState({
    shortDescription: car.shortDescription || "",
    longDescription:  car.longDescription  || "",
    color:            car.color            || "",
    fuelType:         car.fuelType         || "",
    transmission:     car.transmission     || "",
    seatingCapacity:  car.seatingCapacity  || "",
    year:             car.year             || "",
    bodyType:         car.bodyType         || "",
    status:           car.status           || "Active",
    platenumber:      car.platenumber || car.plateNumber || "",
    brandID:          car.brandID          || "",
    modelID:          car.modelID          || "",
  });
  const [pricing, setPricing]   = useState(sortPricing(car.pricing || []));
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(car.imageURL || null);
  const [saving, setSaving]     = useState(false);
  const [error, setError]       = useState(null);
  // The status actually applied so far (starts as the car's real live
  // status). Only ever updated once StatusChangeFlow's gated PATCH call
  // genuinely succeeds — form.status can show Maintenance/Inactive mid-flow
  // for display, but the write itself never happens until that resolves,
  // so this is what the rest of Save Changes (and the bypass guard on the
  // backend's PUT) actually treats as "current".
  const [confirmedStatus, setConfirmedStatus] = useState(car.status || "Active");
  // null | "Maintenance" | "Inactive" — same gate as VehicleCard's, just
  // triggered from this modal's Status dropdown instead of the quick badge.
  const [statusChangeTarget, setStatusChangeTarget] = useState(null);

  const carLabel = `${car.brandName || ""} ${car.modelName || ""}`.trim() || car.platenumber || car.plateNumber || car.id;

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  // Status dropdown asked to move to Maintenance/Inactive — opens the same
  // reason → refund → OTP gate the quick badge uses, instead of letting it
  // slip into the plain form field it used to be. Active needs no gate.
  const handleStatusChangeRequest = (newStatus) => {
    if (newStatus === "Active") {
      // Same clearing applyActiveStatus()'s PATCH does elsewhere — a
      // leftover reason shouldn't survive the car coming back into service.
      setForm((f) => ({ ...f, status: newStatus, statusReason: null }));
      return;
    }
    setStatusChangeTarget(newStatus);
  };

  const handleStatusChangeDone = (newStatus, reason) => {
    setStatusChangeTarget(null);
    setConfirmedStatus(newStatus);
    setForm((f) => ({ ...f, status: newStatus, statusReason: reason }));
  };

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      // PUT /api/fleet/cars/:carID — runs through verifyToken +
      // requireRole on the backend, unlike the old direct Firestore write.
      await apiFetch(`/api/fleet/cars/${car.id}`, {
        method: "PUT",
        body: JSON.stringify({
          ...form,
          seatingCapacity: Number(form.seatingCapacity) || form.seatingCapacity,
          year: Number(form.year) || form.year,
        }),
      });

      // POST /api/fleet/cars/:carID/image — upload still goes to Storage
      // directly via the client SDK, but the resulting Firestore
      // carImages doc write now runs through verifyToken + requireRole
      // on the backend, unlike the old direct addDoc/updateDoc.
      if (imageFile) {
        const imgRef = ref(storage, `carImages/${car.id}/${Date.now()}_${imageFile.name}`);
        await uploadBytes(imgRef, imageFile);
        const downloadURL = await getDownloadURL(imgRef);
        await apiFetch(`/api/fleet/cars/${car.id}/image`, {
          method: "POST",
          body: JSON.stringify({ imageURL: downloadURL }),
        });
      }

      // PUT /api/fleet/cars/:carID/pricing/replace deletes every existing
      // tier for this car and reinserts the current list in one go — same
      // idea as the manual diff-and-delete this used to need client-side,
      // except it's atomic-ish on the backend and actually enforces
      // requireRole. Also fixes the old "Remove doesn't actually delete"
      // bug for free, since there's no separate delete step to forget.
      await apiFetch(`/api/fleet/cars/${car.id}/pricing/replace`, {
        method: "PUT",
        body: JSON.stringify({
          pricing: pricing
            .filter(p => p.durationType && p.price !== "")
            .map(p => ({ durationType: p.durationType, price: p.price })),
        }),
      });

      onSaved();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const pricingCount = pricing.filter(p => p.durationType && p.price).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex justify-between items-center p-5 border-b">
          <div>
            <h2 className="font-bold text-lg text-gray-800">Edit Vehicle</h2>
            <p className="text-xs text-gray-400 mt-0.5">{car.brandName} {car.modelName} · {car.platenumber || car.plateNumber}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
            <Icons.Close className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-5 pt-4 border-b pb-0">
          <button
            onClick={() => setActiveTab("details")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "details"
                ? "border-teal-600 text-teal-700"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}>
            <Icons.Car className="w-4 h-4" />
            Details
          </button>
          <button
            onClick={() => setActiveTab("pricing")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors relative ${
              activeTab === "pricing"
                ? "border-teal-600 text-teal-700"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}>
            <PricingIcon className="w-4 h-4" />
            Pricing
            {pricingCount > 0 && (
              <span className="ml-1 bg-teal-100 text-teal-700 text-xs font-bold px-1.5 py-0.5 rounded-full">
                {pricingCount}
              </span>
            )}
          </button>
        </div>

        {/* Scrollable content */}
        <div className="overflow-y-auto flex-1 p-5">
          {activeTab === "details" ? (
            <CarDetailsForm form={form} setForm={setForm}
              imagePreview={imagePreview} onImageChange={handleImageChange}
              brands={brands} models={models}
              currentStatus={confirmedStatus} onStatusChangeRequest={handleStatusChangeRequest} />
          ) : (
            <PricingForm pricing={pricing} setPricing={setPricing} />
          )}
          {error && <p className="text-sm text-red-500 bg-red-50 rounded-xl p-3 mt-4">{error}</p>}
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center gap-3 p-5 border-t bg-gray-50 rounded-b-2xl">
          <div className="text-xs text-gray-400">
            {activeTab === "details" ? "Edit vehicle info, then switch to Pricing tab" : `${pricingCount} pricing tier${pricingCount !== 1 ? "s" : ""} configured`}
          </div>
          <div className="flex gap-3">
            <button onClick={onClose} className="px-5 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50 bg-white">Cancel</button>
            <button onClick={handleSave} disabled={saving || !!statusChangeTarget}
              className="px-5 py-2 bg-teal-600 text-white rounded-xl text-sm font-medium hover:bg-teal-700 disabled:opacity-50">
              {saving ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </div>
      </div>
      {statusChangeTarget && (
        <StatusChangeFlow
          car={car}
          carLabel={carLabel}
          targetStatus={statusChangeTarget}
          onCancel={() => setStatusChangeTarget(null)}
          onDone={handleStatusChangeDone}
        />
      )}
    </div>
  );
}

// ─── ADD CAR MODAL ────────────────────────────────────────────────────────────
function AddCarModal({ brands, models, onClose, onSaved }) {
  const [activeTab, setActiveTab] = useState("details");
  const [form, setForm]     = useState({ status: "Active", fuelType: "Gasoline", transmission: "Automatic" });
  const [pricing, setPricing] = useState([{ durationType: "", price: "" }]);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const handleSave = async () => {
    if (!form.brandID || !form.modelID) { setError("Please select Brand and Model."); return; }
    setSaving(true); setError(null);
    try {
      // POST /api/fleet/cars accepts pricing[] in the same body and
      // creates the tiers itself — one authenticated call covers car +
      // pricing instead of separate addDoc calls per tier.
      const data = await apiFetch("/api/fleet/cars", {
        method: "POST",
        body: JSON.stringify({
          ...form,
          seatingCapacity: Number(form.seatingCapacity) || 0,
          year: Number(form.year) || 0,
          pricing: pricing.filter(p => p.durationType && p.price),
        }),
      });
      const carID = data.id;

      // POST /api/fleet/cars/:carID/image — same as the edit modal: upload
      // stays client-side via the Storage SDK, but the Firestore write is
      // now behind verifyToken + requireRole instead of a direct addDoc.
      if (imageFile) {
        const imgRef = ref(storage, `carImages/${carID}/${Date.now()}_${imageFile.name}`);
        await uploadBytes(imgRef, imageFile);
        const downloadURL = await getDownloadURL(imgRef);
        await apiFetch(`/api/fleet/cars/${carID}/image`, {
          method: "POST",
          body: JSON.stringify({ imageURL: downloadURL }),
        });
      }

      onSaved();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const pricingCount = pricing.filter(p => p.durationType && p.price).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex justify-between items-center p-5 border-b">
          <h2 className="font-bold text-lg text-gray-800">Add New Vehicle</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
            <Icons.Close className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-5 pt-4 border-b pb-0">
          <button
            onClick={() => setActiveTab("details")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "details"
                ? "border-teal-600 text-teal-700"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}>
            <Icons.Car className="w-4 h-4" />
            Details
          </button>
          <button
            onClick={() => setActiveTab("pricing")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "pricing"
                ? "border-teal-600 text-teal-700"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}>
            <PricingIcon className="w-4 h-4" />
            Pricing
            {pricingCount > 0 && (
              <span className="ml-1 bg-teal-100 text-teal-700 text-xs font-bold px-1.5 py-0.5 rounded-full">
                {pricingCount}
              </span>
            )}
          </button>
        </div>

        {/* Scrollable content */}
        <div className="overflow-y-auto flex-1 p-5">
          {activeTab === "details" ? (
            <CarDetailsForm form={form} setForm={setForm}
              imagePreview={imagePreview} onImageChange={handleImageChange}
              brands={brands} models={models} />
          ) : (
            <PricingForm pricing={pricing} setPricing={setPricing} />
          )}
          {error && <p className="text-sm text-red-500 bg-red-50 rounded-xl p-3 mt-4">{error}</p>}
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center gap-3 p-5 border-t bg-gray-50 rounded-b-2xl">
          <div className="text-xs text-gray-400">
            {activeTab === "details" ? "Fill in vehicle info, then set Pricing" : `${pricingCount} pricing tier${pricingCount !== 1 ? "s" : ""} configured`}
          </div>
          <div className="flex gap-3">
            <button onClick={onClose} className="px-5 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50 bg-white">Cancel</button>
            <button onClick={handleSave} disabled={saving}
              className="px-5 py-2 bg-teal-600 text-white rounded-xl text-sm font-medium hover:bg-teal-700 disabled:opacity-50">
              {saving ? "Adding..." : "Add Vehicle"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MANAGE BRANDS & MODELS MODAL ─────────────────────────────────────────────
function ManageBrandsModal({ brands, models, onClose, onSaved }) {
  const [newBrand, setNewBrand]     = useState("");
  const [newModel, setNewModel]     = useState("");
  const [modelBrandID, setModelBrandID] = useState("");
  const [saving, setSaving]         = useState(false);
  const [tab, setTab]               = useState("brand");
  const [error, setError]           = useState(null);
  const [confirmDel, setConfirmDel] = useState(null);

  const addBrand = async () => {
    if (!newBrand.trim()) return;
    setSaving(true); setError(null);
    try {
      await apiFetch("/api/fleet/brands", {
        method: "POST",
        body: JSON.stringify({ brandName: newBrand.trim() }),
      });
      setNewBrand(""); onSaved();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  const addModel = async () => {
    if (!newModel.trim() || !modelBrandID) { setError("Select a brand and enter model name."); return; }
    setSaving(true); setError(null);
    try {
      await apiFetch("/api/fleet/models", {
        method: "POST",
        body: JSON.stringify({ modelName: newModel.trim(), brandID: modelBrandID }),
      });
      setNewModel(""); setModelBrandID(""); onSaved();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!confirmDel) return;
    setSaving(true);
    try {
      // Backend's deleteBrand already cascades to that brand's models in
      // one batch — matches what this used to do by hand.
      if (confirmDel.type === "brand") {
        await apiFetch(`/api/fleet/brands/${confirmDel.item.id}`, { method: "DELETE" });
      } else {
        await apiFetch(`/api/fleet/models/${confirmDel.item.id}`, { method: "DELETE" });
      }
      setConfirmDel(null); onSaved();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-5 border-b sticky top-0 bg-white z-10">
          <h2 className="font-bold text-lg text-gray-800">Brands & Models</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
            <Icons.Close className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Tabs */}
          <div className="flex gap-2">
            <button onClick={() => setTab("brand")}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${tab === "brand" ? "bg-teal-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
              <Icons.Tag className="w-3.5 h-3.5" />
              Brands
            </button>
            <button onClick={() => setTab("model")}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${tab === "model" ? "bg-teal-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
              <Icons.Car className="w-3.5 h-3.5" />
              Models
            </button>
          </div>

          {tab === "brand" ? (
            <>
              <div className="flex gap-2">
                <input value={newBrand} onChange={e => setNewBrand(e.target.value)}
                  placeholder="New brand name (e.g. Toyota)"
                  className="flex-1 border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400" />
                <button onClick={addBrand} disabled={saving}
                  className="px-4 py-2 bg-teal-600 text-white rounded-xl text-sm hover:bg-teal-700 disabled:opacity-50">Add</button>
              </div>
              <div className="space-y-1 max-h-64 overflow-y-auto">
                {brands.length === 0
                  ? <p className="text-sm text-gray-400 text-center py-4">No brands yet</p>
                  : brands.map(b => (
                  <div key={b.id} className="flex items-center justify-between px-4 py-2.5 bg-gray-50 rounded-xl">
                    <div>
                      <span className="text-sm font-medium text-gray-700">{b.brandName}</span>
                      <span className="text-xs text-gray-400 ml-2">{models.filter(m => m.brandID === b.id).length} models</span>
                    </div>
                    <button onClick={() => setConfirmDel({ type: "brand", item: b })}
                      className="text-red-400 hover:text-red-600 p-1">
                      <Icons.Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="space-y-2">
                <select value={modelBrandID} onChange={e => setModelBrandID(e.target.value)}
                  className="w-full border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="">Select Brand</option>
                  {brands.map(b => <option key={b.id} value={b.id}>{b.brandName}</option>)}
                </select>
                <div className="flex gap-2">
                  <input value={newModel} onChange={e => setNewModel(e.target.value)}
                    placeholder="New model name (e.g. Vios)"
                    className="flex-1 border rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-400" />
                  <button onClick={addModel} disabled={saving}
                    className="px-4 py-2 bg-teal-600 text-white rounded-xl text-sm hover:bg-teal-700 disabled:opacity-50">Add</button>
                </div>
              </div>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {brands.map(b => {
                  const bModels = models.filter(m => m.brandID === b.id);
                  if (bModels.length === 0) return null;
                  return (
                    <div key={b.id}>
                      <p className="text-xs font-semibold text-gray-400 uppercase mb-1">{b.brandName}</p>
                      {bModels.map(m => (
                        <div key={m.id} className="flex items-center justify-between px-4 py-2 bg-gray-50 rounded-xl mb-1">
                          <span className="text-sm text-gray-700">{m.modelName}</span>
                          <button onClick={() => setConfirmDel({ type: "model", item: m })}
                            className="text-red-400 hover:text-red-600 p-1">
                            <Icons.Trash className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {error && <p className="text-sm text-red-500 bg-red-50 rounded-xl p-3">{error}</p>}
        </div>
      </div>

      {/* Inline confirm delete */}
      {confirmDel && (
        <div className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <div className="w-14 h-14 rounded-full bg-red-50 flex items-center justify-center">
                  <Icons.Trash className="w-7 h-7 text-red-500" />
                </div>
              </div>
              <h3 className="font-bold text-gray-800 text-lg">Confirm Delete</h3>
              <p className="text-sm text-gray-500 mt-1">
                {confirmDel.type === "brand"
                  ? `Delete brand "${confirmDel.item.brandName}"? All its models will also be deleted.`
                  : `Delete model "${confirmDel.item.modelName}"?`}
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDel(null)}
                className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
              <button onClick={handleDelete} disabled={saving}
                className="flex-1 px-4 py-2 bg-red-500 text-white rounded-xl text-sm font-medium hover:bg-red-600 disabled:opacity-50">
                {saving ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── CONFIRM DELETE MODAL ─────────────────────────────────────────────────────
function ConfirmDeleteModal({ message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4">
        <div className="text-center">
          <div className="flex justify-center mb-3">
            <div className="w-14 h-14 rounded-full bg-red-50 flex items-center justify-center">
              <Icons.AlertTriangle className="w-7 h-7 text-red-500" />
            </div>
          </div>
          <h3 className="font-bold text-gray-800 text-lg">Confirm Delete</h3>
          <p className="text-sm text-gray-500 mt-1">{message}</p>
        </div>
        <div className="flex gap-3">
          <button onClick={onCancel}
            className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            Cancel
          </button>
          <button onClick={onConfirm}
            className="flex-1 px-4 py-2 bg-red-500 text-white rounded-xl text-sm font-medium hover:bg-red-600">
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}