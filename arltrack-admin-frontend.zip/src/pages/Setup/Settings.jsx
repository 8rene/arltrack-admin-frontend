import { useState, useEffect } from "react";
import { useTheme } from "../../context/ThemeContext";
import StoreLocationSettings from "../../components/StoreLocationSettings";
import AreaMap from "../../components/AreaMap";

// ─── SVG ICONS ───────────────────────────────────────────────────────────────

const IconPeso = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 4v16M6 4h7a4 4 0 010 8H6m0 3h10" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconMap = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// ─── SECTION CARD ────────────────────────────────────────────────────────────
// Same grouping as the Bookings details window: a white card with a grey title strip.
function Section({ icon, title, desc, isDark, children }) {
  return (
    <section className={`rounded-2xl border overflow-hidden shadow-sm ${isDark ? "bg-[#1A5F7A] border-[#4FC3F7]/20" : "bg-white"}`}>
      <div className={`flex items-center gap-2 px-4 py-2.5 border-b ${isDark ? "bg-[#212121]/40 border-[#4FC3F7]/20" : "bg-gray-50"}`}>
        {icon}
        <h2 className={`text-xs font-semibold uppercase tracking-wide ${isDark ? "text-[#F5F5F5]" : "text-gray-600"}`}>{title}</h2>
      </div>
      <div className="p-4 space-y-4">
        {desc && <p className={`text-xs ${isDark ? "text-[#F5F5F5]/40" : "text-gray-400"}`}>{desc}</p>}
        {children}
      </div>
    </section>
  );
}

// ─── FIELD DEFINITIONS ─────────────────────────────────────────────────────
// Keep these in sync BY HAND with backend/models/systemSettings/systemSettings.model.js
// Percentages (0-100), not flat pesos. Computed server-side on every booking:
//   service fee = % of the rental fee only
//   gateway fee = % of everything else (rental + extra + driver's fee + service fee + security deposit)
const FLAT_FEE_FIELDS = [
  { key: "serviceFeePercent", label: "Service Fee (%)", unit: "%", hint: "Percent of the RENTAL FEE only — the extra fee, driver's fee and security deposit are not included." },
  { key: "gatewayFeePercent", label: "Gateway Fee (%)", unit: "%", hint: "Percent of the whole booking: rental + extra fee + driver's fee + service fee + security deposit." },
];

const AREA_FEE_FIELDS = [
  { key: "extraFeeOutsideArea", label: "Extra Fee — Outside Area", hint: "Charged when the drop-off destination is outside the base service area." },
  { key: "driversFeeBaseArea", label: "Driver's Fee — Base Area", hint: "Chauffeur fee when destination is inside the base area." },
  { key: "driversFeeOutsideArea", label: "Driver's Fee — Outside Area", hint: "Chauffeur fee when destination is outside the base area." },
];

// The real, refundable security deposit + late-return penalty settings.
// These already existed in the backend model with no admin UI at all —
// changing them required editing Firestore directly. This is that UI.
const DEPOSIT_FIELDS = [
  { key: "securityDepositAmount", label: "Security Deposit Amount", hint: "Refundable deposit collected at pickup. Snapshotted onto each booking at the moment it's actually collected, so changing this never affects a deposit already taken." },
  { key: "lateFeeRatePerHour", label: "Late Fee Rate (per hour)", hint: "Charged per billable hour late at return, after the grace period below." },
  { key: "lateFeeGraceMinutes", label: "Late Fee Grace Period (minutes)", hint: "Minutes late that are forgiven before the late fee starts accruing.", unit: "min" },
];

// Penalty settings. penaltyThreshold decides when the online payment (gateway) fee is added to a penalty paid online: only when
// the penalty's own amount is HIGHER than this. At or below it there is no fee. (Was a hardcoded 1,000.)
const PENALTY_FIELDS = [
  { key: "penaltyThreshold", label: "Penalty Fee Threshold", hint: "A penalty above this amount carries the gateway fee when paid online. A penalty at or below it has no fee. 0 = every penalty carries the fee." },
];

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
//
// System Settings — Owner & Admin only (see config/pagePermissions.js).
// Editable booking-fee configuration, backed by the systemSettings
// Firestore collection (backend/services/systemSettings/systemSettings.service.js).
// Each save writes a new doc (systemSettingsID + createdAt) rather than
// mutating one fixed doc — the form always reads back the latest one.
//
// IMPORTANT — this only changes what the ADMIN side stores. The customer
// app's booking quote (arltrack-customer-backend/utils/pricing.js) still
// reads its own hardcoded constants and has NOT been wired up to read from
// this doc yet — that's a deliberate follow-up, not an oversight, so that
// changing a number here doesn't silently start charging customers
// differently before that wiring exists.
//
// Personal account preferences (password, dark mode) live on the Account
// page instead (pages/Account.jsx) since those apply to every role, not
// just Owner/Admin.
//
// NOTE: Car Parts (the vehicle parts catalog) intentionally does NOT
// live here — it has its own page at pages/Inventory.jsx.

export default function Settings() {
  const { isDark } = useTheme();

  const [form, setForm] = useState(null);       // working copy the user is editing
  const [saved, setSaved] = useState(null);      // last-saved copy, to detect dirty state
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(false); // fields are read-only until "Edit" is clicked
  const [notice, setNotice] = useState(null);    // { type: "success" | "error", msg }

  const card = `rounded-2xl border p-6 ${
    isDark
      ? "bg-[#1A5F7A] border-[#4FC3F7]/20 shadow-[0_4px_24px_rgba(79,195,247,0.08)]"
      : "bg-white border-gray-100 shadow-soft"
  }`;

  const inputCls = `w-full rounded-xl border px-3 py-2 text-sm focus:outline-none focus:ring-2 transition-colors disabled:opacity-60 disabled:cursor-not-allowed ${
    isDark
      ? "bg-[#212121] border-[#4FC3F7]/20 text-[#F5F5F5] focus:ring-[#4FC3F7]/40"
      : "bg-white border-gray-200 text-arl-dark focus:ring-arl-dark/20"
  }`;

  // ── Load current settings ──────────────────────────────────────────────
  const fetchSettings = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/settings/pricing`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.message || "Failed to load settings.");
      setForm(json.data);
      setSaved(json.data);
    } catch (err) {
      setNotice({ type: "error", msg: err.message || "Failed to load settings." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSettings(); }, []);

  const handleNumberChange = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  // ── Base area keyword chips ─────────────────────────────────────────
  // Normalizes to lowercase + trims — matches how pricing.js itself
  // lower-cases the destination before checking .includes(keyword), so
  // what's shown here is exactly what actually gets matched.
  //
  // Keywords are added from the map (AreaMap below): search for a place or click
  // the map, then press the "+" button for a name it offers. Names come from the
  // PH location list or from OpenStreetMap — never from free typing — so a
  // misspelled keyword can't be saved.
  const addKeywordValue = (value) => {
    const clean = value.trim().toLowerCase();
    if (!clean) return;
    setForm((prev) => {
      if ((prev.baseAreaKeywords || []).includes(clean)) return prev; // no duplicates
      return { ...prev, baseAreaKeywords: [...(prev.baseAreaKeywords || []), clean] };
    });
  };

  const removeKeyword = (word) => {
    setForm((prev) => ({ ...prev, baseAreaKeywords: (prev.baseAreaKeywords || []).filter((k) => k !== word) }));
  };

  const arraysEqual = (a = [], b = []) => a.length === b.length && a.every((v, i) => v === b[i]);

  const isDirty = !!(form && saved) && (
    FLAT_FEE_FIELDS.concat(AREA_FEE_FIELDS, DEPOSIT_FIELDS, PENALTY_FIELDS).some(({ key }) => String(form[key]) !== String(saved[key])) ||
    !arraysEqual(form.baseAreaKeywords, saved.baseAreaKeywords)
  );

  // ── Save ─────────────────────────────────────────────────────────────
  const handleSave = async () => {
    setSaving(true);
    setNotice(null);
    try {
      const payload = {
        serviceFeePercent: Number(form.serviceFeePercent),
        gatewayFeePercent: Number(form.gatewayFeePercent),
        extraFeeOutsideArea: Number(form.extraFeeOutsideArea),
        driversFeeBaseArea: Number(form.driversFeeBaseArea),
        driversFeeOutsideArea: Number(form.driversFeeOutsideArea),
        securityDepositAmount: Number(form.securityDepositAmount),
        lateFeeRatePerHour: Number(form.lateFeeRatePerHour),
        lateFeeGraceMinutes: Number(form.lateFeeGraceMinutes),
        penaltyThreshold: Number(form.penaltyThreshold ?? 1000),
        baseAreaKeywords: form.baseAreaKeywords || [],
      };

      for (const [key, val] of Object.entries(payload)) {
        if (typeof val === "number" && (!Number.isFinite(val) || val < 0)) {
          throw new Error(`"${key}" must be a valid number.`);
        }
      }
      for (const key of ["serviceFeePercent", "gatewayFeePercent"]) {
        if (payload[key] > 100) throw new Error(`"${key}" must be a percentage between 0 and 100.`);
      }
      if (payload.baseAreaKeywords.length === 0) {
        throw new Error("At least one base-area keyword is required.");
      }

      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/settings/pricing`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.message || "Failed to save settings.");

      setForm(json.data);
      setSaved(json.data);
      setEditMode(false);
      setNotice({ type: "success", msg: "Pricing settings saved." });
    } catch (err) {
      setNotice({ type: "error", msg: err.message || "Failed to save settings." });
    } finally {
      setSaving(false);
      setTimeout(() => setNotice(null), 5000);
    }
  };

  const handleReset = () => {
    if (!saved) return;
    setForm(saved);
    setNotice(null);
    setEditMode(false);
  };

  return (
    <div className={`w-full px-4 space-y-5 ${isDark ? "dark" : ""}`}>
      {/* Header */}
      <div>
        <h1 className={`text-2xl font-bold ${isDark ? "text-[#F5F5F5]" : "text-arl-dark"}`}>System Settings</h1>
      </div>

      {notice && (
        <div className={`rounded-xl border px-4 py-2.5 text-sm ${
          notice.type === "success"
            ? isDark ? "bg-[#1A5F7A] text-[#4FC3F7] border-[#4FC3F7]/30" : "bg-green-50 text-green-700 border-green-200"
            : "bg-[#D32F2F]/10 text-[#D32F2F] border-[#D32F2F]/30"
        }`}>
          {notice.msg}
        </div>
      )}

      <StoreLocationSettings />

      {loading || !form ? (
        <div className={card}>
          <p className={`text-sm text-center ${isDark ? "text-[#F5F5F5]/50" : "text-gray-400"}`}>Loading settings…</p>
        </div>
      ) : (
        <>
          {/* Booking Fees */}
          <Section isDark={isDark} icon={<IconPeso className={`w-4 h-4 ${isDark ? "text-[#4FC3F7]" : "text-gray-500"}`} />} title="Booking Fees" desc={"Percentage fees added to every booking, shown to the customer at checkout. Bookings already made keep the amounts they were charged."}>
            <div className="grid sm:grid-cols-3 gap-4">
              {FLAT_FEE_FIELDS.map(({ key, label, hint, unit = "%" }) => (
                <div key={key} className="space-y-1">
                  <label className={`text-[11px] font-medium uppercase tracking-wide ${isDark ? "text-[#F5F5F5]/70" : "text-gray-400"}`}>{label}</label>
                  <div className="relative">
                    <span className={`absolute right-3 top-1/2 -translate-y-1/2 text-xs ${isDark ? "text-[#F5F5F5]/40" : "text-gray-400"}`}>{unit}</span>
                    <input
                      type="number" min="0" max="100" step="0.01"
                      value={form[key]}
                      onChange={(e) => handleNumberChange(key, e.target.value)}
                      disabled={!editMode}
                      className={`${inputCls} pr-7`}
                    />
                  </div>
                  <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>{hint}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Area & Chauffeur Fees */}
          <Section isDark={isDark} icon={<IconMap className={`w-4 h-4 ${isDark ? "text-[#4FC3F7]" : "text-gray-500"}`} />} title="Area & Chauffeur Fees" desc={"Conditional charges based on the drop-off destination and drive type."}>
            <div className="grid sm:grid-cols-3 gap-4">
              {AREA_FEE_FIELDS.map(({ key, label, hint }) => (
                <div key={key} className="space-y-1">
                  <label className={`text-[11px] font-medium uppercase tracking-wide ${isDark ? "text-[#F5F5F5]/70" : "text-gray-400"}`}>{label}</label>
                  <div className="relative">
                    <span className={`absolute left-3 top-1/2 -translate-y-1/2 text-xs ${isDark ? "text-[#F5F5F5]/40" : "text-gray-400"}`}>₱</span>
                    <input
                      type="number" min="0" step="1"
                      value={form[key]}
                      onChange={(e) => handleNumberChange(key, e.target.value)}
                      disabled={!editMode}
                      className={`${inputCls} pl-6`}
                    />
                  </div>
                  <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>{hint}</p>
                </div>
              ))}
            </div>

            <div className="space-y-2 pt-2">
              <label className={`text-[11px] font-medium uppercase tracking-wide ${isDark ? "text-[#F5F5F5]/70" : "text-gray-400"}`}>Base Area Keywords</label>

              {/* Existing keyword chips */}
              <div className="flex flex-wrap gap-2">
                {(form.baseAreaKeywords || []).map((word) => (
                  <span
                    key={word}
                    className={`inline-flex items-center gap-1.5 rounded-full pl-3 pr-1.5 py-1 text-xs font-medium ${
                      isDark ? "bg-[#212121] text-[#F5F5F5]/80 border border-[#4FC3F7]/20" : "bg-gray-100 text-gray-700 border border-gray-200"
                    }`}
                  >
                    {word}
                    {editMode && (
                      <button
                        type="button"
                        onClick={() => removeKeyword(word)}
                        aria-label={`Remove ${word}`}
                        className={`rounded-full w-4 h-4 flex items-center justify-center leading-none ${
                          isDark ? "hover:bg-[#4FC3F7]/20 text-[#F5F5F5]/50" : "hover:bg-gray-300 text-gray-500"
                        }`}
                      >
                        ×
                      </button>
                    )}
                  </span>
                ))}
                {(form.baseAreaKeywords || []).length === 0 && (
                  <span className={`text-xs italic ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>No keywords yet — add at least one below.</span>
                )}
              </div>

              {/* Shaded map of every base-area keyword (live preview, incl. unsaved edits) + click-to-add */}
              <AreaMap
                areas={form.baseAreaKeywords || []}
                editable={editMode}
                onAdd={addKeywordValue}
                isDark={isDark}
                addLabel="base area"
              />

              <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>
                Search above the map or click it, then press the + button to add a place — names come from the map or the PH
                location list, so they can't be misspelled. A destination is still
                treated as "base area" if it <strong>contains</strong> the saved word as text — so short/common names can
                still overlap (e.g. "manila" also matches "New Manila," a Quezon City district). Picking a place
                only prevents typos, it doesn't remove that overlap.
              </p>
            </div>
          </Section>

          {/* Security Deposit & Late Fees */}
          <Section isDark={isDark} icon={<IconPeso className={`w-4 h-4 ${isDark ? "text-[#4FC3F7]" : "text-gray-500"}`} />} title="Security Deposit & Late Fees" desc={"The real, refundable deposit collected at pickup, and the late-return penalty rate. Changing these only affects bookings from this point forward — anything already collected keeps its original amount."}>
            <div className="grid sm:grid-cols-3 gap-4">
              {DEPOSIT_FIELDS.map(({ key, label, hint, unit = "₱" }) => (
                <div key={key} className="space-y-1">
                  <label className={`text-[11px] font-medium uppercase tracking-wide ${isDark ? "text-[#F5F5F5]/70" : "text-gray-400"}`}>{label}</label>
                  <div className="relative">
                    <span className={`absolute ${unit === "₱" ? "left-3" : "right-3"} top-1/2 -translate-y-1/2 text-xs ${isDark ? "text-[#F5F5F5]/40" : "text-gray-400"}`}>{unit}</span>
                    <input
                      type="number" min="0" step="1"
                      value={form[key]}
                      onChange={(e) => handleNumberChange(key, e.target.value)}
                      disabled={!editMode}
                      className={`${inputCls} ${unit === "₱" ? "pl-6" : "pr-10"}`}
                    />
                  </div>
                  <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>{hint}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Penalty online fee */}
          <Section isDark={isDark} icon={<IconPeso className={`w-4 h-4 ${isDark ? "text-[#4FC3F7]" : "text-gray-500"}`} />} title="Penalties" desc={"When a customer pays a penalty online, the gateway fee is added only if the penalty is above this amount. It is judged on the penalty's own amount, however it is paid. Changing it applies to penalties that are still unpaid; payments already made and their receipts are not affected."}>
            <div className="grid sm:grid-cols-3 gap-4">
              {PENALTY_FIELDS.map(({ key, label, hint, unit = "₱" }) => (
                <div key={key} className="space-y-1">
                  <label className={`text-[11px] font-medium uppercase tracking-wide ${isDark ? "text-[#F5F5F5]/70" : "text-gray-400"}`}>{label}</label>
                  <div className="relative">
                    <span className={`absolute left-3 top-1/2 -translate-y-1/2 text-xs ${isDark ? "text-[#F5F5F5]/40" : "text-gray-400"}`}>{unit}</span>
                    <input
                      type="number" min="0" step="1"
                      value={form[key] ?? 1000}
                      onChange={(e) => handleNumberChange(key, e.target.value)}
                      disabled={!editMode}
                      className={`${inputCls} pl-6`}
                    />
                  </div>
                  <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>{hint}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {editMode ? (
              <>
                <button
                  onClick={handleSave}
                  disabled={saving || !isDirty}
                  className={`px-6 py-2.5 rounded-xl shadow text-sm font-medium disabled:opacity-50 transition-all ${
                    isDark ? "bg-[#4FC3F7] hover:bg-[#4FC3F7]/90 text-[#212121]" : "bg-teal-600 hover:bg-teal-700 text-white"
                  }`}
                >
                  {saving ? "Saving…" : "Save Changes"}
                </button>
                <button
                  onClick={handleReset}
                  disabled={saving}
                  className={`px-6 py-2.5 rounded-xl border text-sm font-medium disabled:opacity-50 transition-all ${
                    isDark ? "border-[#4FC3F7]/20 text-[#F5F5F5]/70 hover:bg-[#212121]/40" : "border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {isDirty ? "Discard Changes" : "Cancel"}
                </button>
              </>
            ) : (
              <button
                onClick={() => setEditMode(true)}
                className={`px-6 py-2.5 rounded-xl shadow text-sm font-medium transition-all ${
                  isDark ? "bg-[#4FC3F7] hover:bg-[#4FC3F7]/90 text-[#212121]" : "bg-teal-600 hover:bg-teal-700 text-white"
                }`}
              >
                Edit Settings
              </button>
            )}
            {form.createdAt && (
              <span className={`text-[11px] ml-auto ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>
                Last updated {form.updatedBy?.name ? `by ${form.updatedBy.name}` : ""}
              </span>
            )}
          </div>
        </>
      )}
    </div>
  );
}