import { useEffect, useState, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { ROLES } from "../config/pagePermissions";
import ArchiveDetailModal from "../components/shared/ArchiveDetailModal";

const typeBadgeDot = {
  delete: "bg-red-500", update: "bg-blue-500", create: "bg-green-500",
  export: "bg-yellow-400", auth: "bg-gray-400", system: "bg-purple-500",
  REGISTER: "bg-green-500", LOGIN: "bg-gray-400", LOGOUT: "bg-gray-400",
  UPDATE: "bg-blue-500", DELETE: "bg-red-500",
};
const typeBadgeBg = {
  delete: "bg-red-50 border border-red-200", update: "bg-blue-50 border border-blue-200",
  create: "bg-green-50 border border-green-200", export: "bg-yellow-50 border border-yellow-200",
  auth: "bg-gray-50 border border-gray-200", system: "bg-purple-50 border border-purple-200",
  REGISTER: "bg-green-50 border border-green-200", LOGIN: "bg-gray-50 border border-gray-200",
  LOGOUT: "bg-gray-50 border border-gray-200", UPDATE: "bg-blue-50 border border-blue-200",
  DELETE: "bg-red-50 border border-red-200",
};

function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  return d.toLocaleString("en-PH", {
    month: "short", day: "numeric", year: "numeric",
    hour: "numeric", minute: "2-digit", hour12: true,
  });
}
function inRange(iso, from, to) {
  if (!from && !to) return true;
  const d = new Date(iso);
  if (isNaN(d)) return true;
  if (from && d < new Date(from + "T00:00:00")) return false;
  if (to   && d > new Date(to + "T23:59:59")) return false;
  return true;
}

const PAGE_SIZE = 15;

export default function AuditLogsArchivePage() {
  const { effectiveRole } = useAuth();
  const [records, setRecords]       = useState([]);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState(null);
  const [search, setSearch]         = useState("");
  const [dateFrom, setDateFrom]     = useState("");
  const [dateTo, setDateTo]         = useState("");
  const [page, setPage]             = useState(1);
  const [toast, setToast]           = useState(null);
  const [confirmId, setConfirmId]   = useState(null);
  const [restoreConfirmId, setRestoreConfirmId] = useState(null);
  const [actionId, setActionId]     = useState(null);
  const [viewRecord, setViewRecord] = useState(null);
  const [viewDesc, setViewDesc]     = useState(null); // full-description modal

  const token = localStorage.getItem("token");

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchRecords = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/archives/audit-logs`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to load archive.");
      setRecords(data.data || []);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchRecords(); }, [fetchRecords]);

  const handleRestore = async (auditLogsArchivesId) => {
    setRestoreConfirmId(null);
    setActionId(auditLogsArchivesId);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/archives/audit-logs/${auditLogsArchivesId}/restore`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Restore failed.");
      setRecords((prev) => prev.filter((r) => r.auditLogsArchivesId !== auditLogsArchivesId));
      showToast(data.message || "Audit log restored to active table.", "success");
    } catch (err) { showToast(err.message, "error"); }
    finally { setActionId(null); }
  };

  const handleDelete = async (auditLogsArchivesId) => {
    setConfirmId(null);
    setActionId(auditLogsArchivesId);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/archives/audit-logs/${auditLogsArchivesId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Delete failed.");
      setRecords((prev) => prev.filter((r) => r.auditLogsArchivesId !== auditLogsArchivesId));
      showToast("Permanently deleted.", "success");
    } catch (err) { showToast(err.message, "error"); }
    finally { setActionId(null); }
  };

  const filtered = records.filter((r) => {
    const q = search.toLowerCase();
    const matchSearch =
      (r.auditLogsArchivesId || "").toLowerCase().includes(q) ||
      (r.action              || "").toLowerCase().includes(q) ||
      (r.description         || "").toLowerCase().includes(q) ||
      (r.userName            || "").toLowerCase().includes(q) ||
      (r.userID              || "").toLowerCase().includes(q);
    return matchSearch && inRange(r.archivedAt, dateFrom, dateTo);
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated  = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => setPage(1), [search, dateFrom, dateTo]);

  const restoreConfirmRecord = records.find((r) => r.auditLogsArchivesId === restoreConfirmId);

  return (
    <div className="w-full px-6 py-6">

      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-medium text-white ${
          toast.type === "error" ? "bg-red-500" : "bg-teal-600"
        }`}>
          {toast.msg}
        </div>
      )}

      {confirmId && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30">
          <div className="bg-white rounded-2xl shadow-xl p-6 w-80">
            <h3 className="font-semibold text-gray-800 mb-2">Permanently Delete?</h3>
            <p className="text-sm text-gray-500 mb-5">This action cannot be undone.</p>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setConfirmId(null)} className="px-4 py-2 rounded-xl border border-gray-200 text-sm hover:bg-gray-50">Cancel</button>
              <button onClick={() => handleDelete(confirmId)} className="px-4 py-2 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">Delete</button>
            </div>
          </div>
        </div>
      )}

      {restoreConfirmId && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/30">
          <div className="bg-white rounded-2xl shadow-xl p-6 w-96">
            <h3 className="font-semibold text-gray-800 mb-2">Restore this audit log?</h3>
            {restoreConfirmRecord && (
              <p className="text-xs text-gray-500 mb-2">
                {restoreConfirmRecord.action} — {restoreConfirmRecord.userName || restoreConfirmRecord.userID || "—"}
              </p>
            )}
            <p className="text-sm text-gray-500 mb-5">It will move back to the live audit log table.</p>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setRestoreConfirmId(null)} className="px-4 py-2 rounded-xl border border-gray-200 text-sm hover:bg-gray-50">Cancel</button>
              <button onClick={() => handleRestore(restoreConfirmId)} className="px-4 py-2 rounded-xl bg-teal-600 text-white text-sm hover:bg-teal-700">Yes, Restore</button>
            </div>
          </div>
        </div>
      )}

      {viewRecord && (
        <ArchiveDetailModal
          title={`Audit Log Archive — ${viewRecord.auditLogsArchivesId}`}
          record={viewRecord}
          onClose={() => setViewRecord(null)}
          labelOverrides={{ auditLogsArchivesId: "Archive ID", userID: "User ID", userName: "User" }}
        />
      )}

      {/* Full description view modal */}
      {viewDesc && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center bg-black/30 backdrop-blur-sm p-4"
          onClick={() => setViewDesc(null)}
        >
          <div
            className="bg-white rounded-2xl shadow-xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-3 gap-4">
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold text-black ${typeBadgeBg[viewDesc.action] || "bg-gray-50 border border-gray-200"}`}>
                <span className={`w-2 h-2 rounded-full shrink-0 ${typeBadgeDot[viewDesc.action] || "bg-gray-400"}`} />
                {viewDesc.action || "system"}
              </span>
              <button onClick={() => setViewDesc(null)} className="text-gray-400 hover:text-gray-600 text-xl leading-none">×</button>
            </div>
            <p className="text-xs text-gray-400 mb-3">{formatDate(viewDesc.createdAt)}</p>
            <p className="text-sm text-gray-700 whitespace-pre-wrap break-words leading-relaxed">
              {viewDesc.description || "—"}
            </p>
          </div>
        </div>
      )}

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 tracking-tight">AUDIT LOG ARCHIVE</h1>
        <p className="text-sm text-gray-400 mt-1">
          {loading ? "Loading…" : `${filtered.length} archived record${filtered.length !== 1 ? "s" : ""}`}
        </p>
      </div>

      <div className="flex flex-wrap gap-3 mb-5">
        <input
          type="text"
          placeholder="Search by action, description, user…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 w-64"
        />
        <div className="flex items-center gap-2">
          <label className="text-xs text-gray-400 whitespace-nowrap">Archived from</label>
          <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          <label className="text-xs text-gray-400">to</label>
          <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
        </div>
        <button onClick={fetchRecords} disabled={loading} className="px-4 py-2 text-sm rounded-xl bg-teal-700 text-white hover:bg-teal-800 disabled:opacity-50 ml-auto">
          {loading ? "…" : "Refresh"}
        </button>
      </div>

      {error && <div className="mb-4 p-4 rounded-xl bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">Action</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">Description</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">User</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">Timestamp</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">Archived At</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={i} className="border-b border-gray-50">
                  {Array.from({ length: 6 }).map((_, j) => (
                    <td key={j} className="px-4 py-4"><div className="h-3 bg-gray-100 rounded animate-pulse w-3/4" /></td>
                  ))}
                </tr>
              ))
            ) : paginated.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-16 text-gray-400 text-sm">{search || dateFrom || dateTo ? "No records match your filters." : "No archived audit logs found."}</td></tr>
            ) : (
              paginated.map((r, i) => {
                const actionKey = r.action || "system";
                const desc = r.description || "—";
                const isLong = desc.length > 60;
                return (
                  <tr key={r.auditLogsArchivesId} className={`border-b border-gray-50 last:border-0 hover:bg-gray-50/60 transition-colors ${i % 2 !== 0 ? "bg-gray-50/20" : ""}`}>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold text-black ${typeBadgeBg[actionKey] || "bg-gray-50 border border-gray-200"}`}>
                        <span className={`w-2 h-2 rounded-full shrink-0 ${typeBadgeDot[actionKey] || "bg-gray-400"}`} />
                        {actionKey}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-700 max-w-xs">
                      <div className="flex items-center gap-2">
                        <span className="truncate">{desc}</span>
                        {isLong && (
                          <button onClick={() => setViewDesc(r)} className="shrink-0 text-xs text-teal-600 hover:text-teal-800 underline whitespace-nowrap">
                            View
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-600">{r.userName || r.userID || "—"}</td>
                    <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{formatDate(r.createdAt)}</td>
                    <td className="px-4 py-3 text-xs whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 text-xs font-medium">{formatDate(r.archivedAt)}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex gap-2 justify-end">
                        <button onClick={() => setViewRecord(r)} disabled={!!actionId} className="px-3 py-1.5 text-xs rounded-lg bg-gray-50 text-gray-600 border border-gray-200 hover:bg-gray-100 disabled:opacity-40 whitespace-nowrap">
                          View
                        </button>
                        <button onClick={() => setRestoreConfirmId(r.auditLogsArchivesId)} disabled={!!actionId} className="px-3 py-1.5 text-xs rounded-lg bg-teal-600 text-white hover:bg-teal-700 disabled:opacity-40 whitespace-nowrap">
                          {actionId === r.auditLogsArchivesId ? "…" : "Restore"}
                        </button>
                        {effectiveRole === ROLES.OWNER && (
                        <button onClick={() => setConfirmId(r.auditLogsArchivesId)} disabled={!!actionId} className="px-3 py-1.5 text-xs rounded-lg bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 disabled:opacity-40 whitespace-nowrap">
                          Delete
                        </button>
                      )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {!loading && filtered.length > PAGE_SIZE && (
        <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
          <span>Page {page} of {totalPages}</span>
          <div className="flex gap-2">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40">← Prev</button>
            <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40">Next →</button>
          </div>
        </div>
      )}
    </div>
  );
}