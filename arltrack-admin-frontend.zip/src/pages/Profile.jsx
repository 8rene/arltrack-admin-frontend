import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/* ── Icons ── */
const IconMail = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
  </svg>
);

const IconShield = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

const IconFingerprint = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 11c1.5 1.5 1.5 5 0 6M8 10c2-2 6-2 8 0M6 8c3-3 9-3 12 0M4.5 6c4-4 11.5-4 15.5 0M9 15c1 1 3 1 4 0M12 3v1" />
  </svg>
);

const IconLogout = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
  </svg>
);

/* ── Detail row ── */
function DetailRow({ icon, label, value }) {
  return (
    <div className="flex items-center gap-3 py-3.5 border-b border-gray-50 last:border-0">
      <div className="w-9 h-9 rounded-full bg-arl-light flex items-center justify-center text-arl-primary shrink-0">
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-gray-400">{label}</p>
        <p className="text-sm font-medium text-arl-dark truncate">{value || "—"}</p>
      </div>
    </div>
  );
}

// Shared by every role (Owner, Admin, Supervisor, Driver).
export default function Profile() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  if (!user) return null;

  const initials = (user.username || user.email || "U")
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  const handleSignOut = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-6">

      {/* HEADER CARD */}
      <div className="bg-white rounded-2xl border shadow-card overflow-hidden">
        <div className="bg-arl-primary px-6 py-8 flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/15 border-2 border-white/30 flex items-center justify-center text-white text-xl font-bold shrink-0">
            {initials}
          </div>
          <div className="min-w-0">
            <p className="text-white text-lg font-semibold truncate">{user.username || "User"}</p>
            <p className="text-white/70 text-sm truncate">{user.email}</p>
            <span className="inline-block mt-1 text-xs font-semibold text-white bg-white/15 px-2.5 py-0.5 rounded-full">
              {user.role}
            </span>
          </div>
        </div>

        {/* DETAILS */}
        <div className="px-6 py-2">
          <DetailRow icon={<IconMail className="w-4 h-4" />} label="Email" value={user.email} />
          <DetailRow icon={<IconShield className="w-4 h-4" />} label="Role" value={user.role} />
          <DetailRow icon={<IconFingerprint className="w-4 h-4" />} label="User ID" value={user.uid} />
        </div>

        <div className="px-6 pb-4 pt-1">
          <p className="text-xs text-gray-300">Connected to Firebase Auth + JWT</p>
        </div>
      </div>

      {/* ACTIONS */}
      <div className="bg-white rounded-2xl border shadow-card px-6 py-4">
        <button
          onClick={handleSignOut}
          className="flex items-center gap-2 text-red-500 text-sm font-semibold hover:text-red-600 transition-colors"
        >
          <IconLogout className="w-4 h-4" />
          Sign Out
        </button>
      </div>

    </div>
  );
}