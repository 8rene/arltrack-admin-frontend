import { useState, useEffect, useCallback, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import TripMapModal, { TripLocationsMap } from "../../components/TripMapModal";
import TripDetailModal from "../../components/TripDetailModal";
import TripTermsModal, { TripTermsContent } from "../../components/TripTermsModal";
import { readCodingWarnings, warningsByCity } from "../../utils/codingWarnings";

const API_URL = process.env.REACT_APP_API_URL;

// ─── ICONS ───────────────────────────────────────────────────────────────

const IconSteering = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="2.5" />
    <path strokeLinecap="round" d="M12 3v6.5M12 14.5V21M4.2 7.5l5.6 3.2M14.2 13.3l5.6 3.2M19.8 7.5l-5.6 3.2M9.8 13.3l-5.6 3.2" />
  </svg>
);

const IconClock = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3 2" />
  </svg>
);

const IconPin = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s7-7.75 7-13a7 7 0 10-14 0c0 5.25 7 13 7 13z" />
    <circle cx="12" cy="8" r="2.5" />
  </svg>
);

const IconMap = ({ className = "w-3.5 h-3.5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2-6-2z" />
    <path strokeLinecap="round" d="M9 4v14M15 6v14" />
  </svg>
);

const fmtDateTime = (val) => {
  if (!val) return "—";
  const d = new Date(val);
  if (isNaN(d)) return "—";
  return d.toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
};

const fmtDateTimeLong = (val) => {
  if (!val) return "—";
  const d = new Date(val);
  if (isNaN(d)) return "—";
  return d.toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
};

const fmtTime = (val) => {
  if (!val) return null;
  const d = new Date(val);
  if (isNaN(d)) return null;
  return d.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" });
};

// Shared: turn a trip's pickupLocation/dropoffLocation into the `stops`
// shape TripMapModal expects. Both are included whenever present — even
// when dropoff shares pickup's address (e.g. a round trip back to the
// same spot), it's still a real stop the driver needs to log/confirm,
// so it stays on the list rather than being silently collapsed away.
// Roughly "same point" — ~55m, generous enough that a geofence zone
// centered on the exact pickup/dropoff coordinate (which the customer
// backend's makeZone() may include alongside genuine extra stops) is
// recognized as a duplicate rather than shown as its own pin.
const SAME_SPOT_DEG = 0.0005;
const isSameSpot = (a, b) =>
  !!a && !!b && Math.abs(a.lat - b.lat) < SAME_SPOT_DEG && Math.abs(a.lng - b.lng) < SAME_SPOT_DEG;

const tripStops = (trip) => {
  const stops = [];
  if (trip.pickupLocation) stops.push({ key: "pickup", type: "pickup", ...trip.pickupLocation });
  if (trip.dropoffLocation) stops.push({ key: "dropoff", type: "dropoff", ...trip.dropoffLocation });
  // Extra stops selected during booking — the same geofenceZones
  // CarTracking's live map already draws for staff. Filtered to genuine
  // extras: skip anything whose own label calls it out as pickup/dropoff,
  // or that sits on (near) the same coordinate as one — either would just
  // double up a pin that's already shown above.
  (trip.geofenceZones || []).forEach((zone, i) => {
    if (typeof zone.lat !== "number" || typeof zone.lng !== "number") return;
    const label = (zone.label || "").toLowerCase();
    if (label.includes("pickup") || label.includes("drop")) return;
    if (isSameSpot(zone, trip.pickupLocation) || isSameSpot(zone, trip.dropoffLocation)) return;
    stops.push({ key: `stop-${i}`, type: "stop", address: zone.label || `Stop ${i + 1}`, lat: zone.lat, lng: zone.lng });
  });
  return stops;
};

// ── Coding restriction display helpers ──
// "2026-11-03" (a Manila calendar date from the backend) -> "Tue, Nov 3".
const fmtYmd = (ymd) => {
  const d = new Date(`${ymd}T00:00:00+08:00`);
  return isNaN(d) ? ymd : d.toLocaleDateString("en-PH", { weekday: "short", month: "short", day: "numeric", timeZone: "Asia/Manila" });
};
const manilaTodayYmd = () => new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10);
// One row per date + city, with every window that day in a single line.
const groupCodingDays = (days) => {
  const map = new Map();
  (days || []).forEach((d) => {
    const key = `${d.date}|${d.city}|${d.holiday || ""}`;
    if (!map.has(key)) map.set(key, { date: d.date, city: d.city, plateLastDigit: d.plateLastDigit, holiday: d.holiday, windows: [] });
    map.get(key).windows.push(`${d.startTime} – ${d.endTime}`);
  });
  return [...map.values()];
};
const directionsUrl = (st) => `https://www.google.com/maps/dir/?api=1&destination=${st.lat},${st.lng}&travelmode=driving`;
const STOP_DOT = { pickup: "bg-indigo-600", dropoff: "bg-amber-500", stop: "bg-teal-600" };

// Cities to outline on the map: the ones with a real restricted day inside the trip (holidays
// excluded). Older responses without codingSchedule fall back to the booking-time warnings.
const tripCodingAreas = (trip) => {
  const sched = trip?.codingSchedule;
  const list = sched
    ? (sched.days || []).filter((d) => !d.holiday)
    : warningsByCity(readCodingWarnings(trip?.codingWarnings));
  return list.map((d) => ({ city: d.city }));
};

// "Destinations" list shared by the Active tab and the History detail. Tapping a row asks the map
// to fly to that stop (onFocus); each pinned row has a Directions link.
function DestinationsList({ stops, onFocus }) {
  if (!stops.length) return null;
  return (
    <Block title="Destinations">
      <div className="divide-y divide-gray-100">
        {stops.map((st, i) => {
          const pinned = hasPin(st);
          const stopNo = stops.slice(0, i + 1).filter((x) => x.type === "stop").length;
          const label  = st.type === "pickup" ? "Pickup" : st.type === "dropoff" ? "Dropoff" : `Stop ${stopNo}`;
          return (
            <div key={st.key} className="flex items-center gap-3 py-2.5">
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${STOP_DOT[st.type] || STOP_DOT.pickup}`} />
              <button type="button" disabled={!pinned} onClick={() => onFocus?.(st.key)}
                className="flex-1 min-w-0 text-left disabled:cursor-default">
                <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400">{label}</p>
                <p className="text-sm text-gray-800 break-words">{st.address || "—"}</p>
              </button>
              {pinned && (
                <a href={directionsUrl(st)} target="_blank" rel="noopener noreferrer"
                  className="shrink-0 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-indigo-600 border border-indigo-100 hover:bg-indigo-50">
                  Directions
                </a>
              )}
            </div>
          );
        })}
      </div>
    </Block>
  );
}

// mm:ss for the Remind Staff cooldown.
const fmtCountdown = (secs) => `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}`;

// Where the vehicle inspection stands for one phase of a trip. Drivers no
// longer fill the inspection in — a supervisor does — so this is a
// read-only checklist plus a Remind Staff nudge. The button's cooldown is
// enforced by the server (10 min per trip + phase); `remaining` here is
// only the display of it.
function InspectionPanel({ inspection, phase, remaining, sending, onRemind }) {
  if (inspection.complete) {
    return (
      <p className="text-[11px] font-medium text-green-600 mb-1">
        ✓ Vehicle inspection complete — ready for pickup
      </p>
    );
  }
  const Row = ({ done, label }) => (
    <span className={`flex items-center gap-1.5 ${done ? "text-green-700" : "text-gray-500"}`}>
      <span className="font-bold w-3 text-center">{done ? "✓" : "○"}</span> {label}
    </span>
  );
  const cooling = remaining > 0;
  return (
    <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 mb-1 space-y-2">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <p className="text-xs font-semibold text-amber-800">
            Waiting for a supervisor to complete the pickup inspection
          </p>
          <div className="text-[11px] space-y-0.5">
            <Row
              done={inspection.photos}
              label={`Video, or front, side & back photos${
                !inspection.photos && inspection.photoSlots && Object.values(inspection.photoSlots).some(Boolean)
                  ? ` (missing: ${["front", "side", "back"].filter((s) => !inspection.photoSlots[s]).join(", ")})`
                  : ""
              }`}
            />
            <Row done={inspection.parts} label={`Parts condition${inspection.parts ? "" : " (supervisor must confirm it)"}`} />
          </div>
        </div>
        <button
          onClick={onRemind}
          disabled={sending || cooling}
          className="shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-600 text-white hover:bg-amber-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {sending ? "Sending…" : cooling ? `Remind again in ${fmtCountdown(remaining)}` : "🔔 Remind Staff"}
        </button>
      </div>
    </div>
  );
}

const IconShield = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l7 3v5c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-3z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4" />
  </svg>
);

const hasPin = (p) => !!p && typeof p.lat === "number" && typeof p.lng === "number";
const peso = (n) => `₱${Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2 })}`;
const isPaymentReady = (t) =>
  ["approved", "paid"].includes((t.payment?.paymentStatus || "").toLowerCase()) && (t.payment?.balance ?? 0) <= 0;

// ── Same look as the staff Refund Requests page: clickable summary card,
// dot-pill status badge, and bordered label/value blocks. ──
function StatCard({ icon, value, label, sub, color, onClick, active }) {
  const bgColors = {
    teal:   "bg-teal-50 text-teal-600",
    yellow: "bg-yellow-50 text-yellow-600",
    purple: "bg-purple-50 text-purple-600",
    green:  "bg-green-50 text-green-600",
    blue:   "bg-blue-50 text-blue-600",
    red:    "bg-red-50 text-red-600",
  };
  // Flat style (same as the Users page cards) — sits inside TripsGroupBox.
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={!!active}
      className={`rounded-2xl border p-4 flex items-center gap-3 text-left w-full transition-all focus:outline-none ${
        active ? "bg-white border-teal-500 ring-2 ring-teal-100" : "bg-gray-50 border-transparent hover:bg-gray-100"
      }`}
    >
      <div className={`w-11 h-11 shrink-0 flex items-center justify-center rounded-xl ${bgColors[color] || "bg-gray-100 text-gray-600"}`}>{icon}</div>
      <div className="min-w-0">
        <div className="text-2xl font-bold text-gray-800 leading-tight">{value}</div>
        <div className="text-xs text-gray-500">{label}</div>
        {sub && <div className="text-[11px] text-orange-600 font-semibold">{sub}</div>}
      </div>
    </button>
  );
}

const IconRefresh = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M23 4v6h-6M1 20v-6h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M3.51 9a9 9 0 0114.36-3.36L23 10M1 14l5.13 4.36A9 9 0 0020.49 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// One white box like the Users page: summary cards on top, then
// Trips | History tabs on the left and Refresh on the right.
function TripsGroupBox({ cards, tab, setTab, onRefresh, refreshing }) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border">
      <div className="grid gap-3 grid-cols-1 sm:grid-cols-3 p-4">{cards}</div>
      <div className="flex justify-between items-center border-t px-4 py-3">
        <div className="flex gap-2">
          {[["active", "Trips"], ["history", "History"]].map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)}
              className={`px-5 py-2 rounded-xl text-sm font-medium transition-all ${
                tab === key ? "bg-arl-dark text-white shadow" : "text-gray-600 hover:bg-gray-50"
              }`}>
              {label}
            </button>
          ))}
        </div>
        <button onClick={onRefresh} disabled={refreshing}
          className="px-4 py-2 rounded-xl text-sm font-medium bg-arl-primary text-white hover:bg-[#16526a] flex items-center gap-1.5 disabled:opacity-50">
          <IconRefresh className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh"}
        </button>
      </div>
    </div>
  );
}

const STATUS_PILL = {
  upcoming:  { dot: "bg-yellow-500", bg: "bg-yellow-50 border border-yellow-200", label: "Upcoming" },
  ongoing:   { dot: "bg-green-500",  bg: "bg-green-50 border border-green-200",   label: "Ongoing" },
  completed: { dot: "bg-blue-500",   bg: "bg-blue-50 border border-blue-200",     label: "Completed" },
  cancelled: { dot: "bg-red-500",    bg: "bg-red-50 border border-red-200",       label: "Cancelled" },
  stolen:    { dot: "bg-red-900",    bg: "bg-red-100 border border-red-300",      label: "Stolen" },
};
function StatusPill({ status }) {
  const b = STATUS_PILL[status] || { dot: "bg-gray-400", bg: "bg-gray-50 border border-gray-200", label: (status || "—").replace("_", " ") };
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full text-black ${b.bg}`}>
      <span className={`w-2 h-2 rounded-full shrink-0 ${b.dot}`} />{b.label}
    </span>
  );
}

const Line = ({ label, children }) => (
  <div className="flex items-start justify-between gap-4 py-1.5 text-sm">
    <span className="text-gray-500 shrink-0">{label}</span>
    <span className="text-right text-gray-800 min-w-0 break-words">{children}</span>
  </div>
);
const Block = ({ title, children }) => (
  <div className="rounded-xl border border-gray-100 p-4">
    {title && <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">{title}</p>}
    {children}
  </div>
);
const Eyebrow = ({ children }) => (
  <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400">{children}</p>
);

// Simple full-screen viewer for one photo or video (read-only).
/* Read-only inspection media (videos + additional photos) for a past trip. */
const hasInspectionMedia = (doc) =>
  !!(doc && ((Array.isArray(doc.videos) && doc.videos.length) || (Array.isArray(doc.extraPhotos) && doc.extraPhotos.length)));

function VideoTile({ item, onView }) {
  return (
    <div className="relative rounded-2xl overflow-hidden border border-gray-100 bg-black aspect-video">
      <video src={`${item.url}#t=0.5`} preload="metadata" muted playsInline className="w-full h-full object-cover opacity-90" />
      <button
        type="button"
        onClick={() => onView({ url: item.url, label: "Inspection video", type: "video" })}
        className="absolute inset-0 flex items-center justify-center"
        aria-label="Play video"
      >
        <span className="w-11 h-11 rounded-full bg-white/90 text-gray-800 flex items-center justify-center text-lg shadow">▶</span>
      </button>
    </div>
  );
}

function InspectionMediaGallery({ doc, onView }) {
  if (!hasInspectionMedia(doc)) return null;
  const videos = Array.isArray(doc.videos) ? doc.videos : [];
  const photos = Array.isArray(doc.extraPhotos) ? doc.extraPhotos : [];
  return (
    <div className="rounded-xl border border-gray-100 bg-white p-3 space-y-3">
      {videos.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Videos ({videos.length})</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {videos.map((v) => <VideoTile key={v.url} item={v} onView={onView} />)}
          </div>
        </div>
      )}
      {photos.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Additional photos ({photos.length})</p>
          <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
            {photos.map((p) => (
              <button key={p.url} type="button" className="rounded-lg overflow-hidden border border-gray-100 aspect-square"
                onClick={() => onView({ url: p.url, label: p.caption || "Additional photo", type: "image" })}>
                <img src={p.url} alt={p.caption || "Additional"} loading="lazy" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ProofLightbox({ photo, onClose }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className="fixed inset-0 bg-black/70 z-[2100] flex items-center justify-center p-4" onClick={onClose}>
      <div
        className={`bg-white rounded-2xl overflow-hidden w-full shadow-2xl ${photo.type === "video" ? "max-w-3xl" : "max-w-lg"}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <p className="text-sm font-semibold text-gray-800">{photo.label}</p>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-lg leading-none">✕</button>
        </div>
        {photo.type === "video" ? (
          <div className="w-full bg-black">
            <video src={photo.url} controls autoPlay playsInline className="w-full max-h-[70vh]" />
          </div>
        ) : failed ? (
          <div className="w-full h-[50vh] flex flex-col items-center justify-center gap-2 bg-gray-50 text-gray-400">
            <p className="text-xs">Photo failed to load.</p>
            <a href={photo.url} target="_blank" rel="noreferrer" className="text-xs text-indigo-600 font-semibold">Open original link</a>
          </div>
        ) : (
          <div className="w-full h-[60vh] bg-gray-50">
            <img src={photo.url} alt={photo.label} className="w-full h-full object-contain" onError={() => setFailed(true)} />
          </div>
        )}
      </div>
    </div>
  );
}

// Read-only inspection proof (Before / After) for one of the driver's own
// trips. Fetches only for the trip being shown. `refreshKey` changes when
// staff finish an inspection phase, so new photos appear without a reload.
function TripInspectionProof({ tripID, refreshKey, authedFetch }) {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const [phase, setPhase]     = useState("before");
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res  = await authedFetch(`/api/driver-dispatch/my-trips/${tripID}/inspection`);
        const json = await res.json();
        if (!res.ok) throw new Error(json.message || "Couldn't load the inspection.");
        if (!cancelled) { setData(json.data); setError(null); }
      } catch (e) {
        if (!cancelled) setError(e.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [tripID, refreshKey, authedFetch]);

  const hasAny = (r) => !!r && (r.exterior.length || r.videos.length || r.extraPhotos.length);
  const rec = data?.[phase];

  const renderTile = (item) => (
    <button key={item.key} type="button" onClick={() => setViewing({ url: item.url, label: item.label, type: "image" })}
      className="rounded-xl overflow-hidden border border-gray-100 bg-gray-50 text-left">
      <div className="aspect-square">
        <img src={item.url} alt={item.label} loading="lazy" className="w-full h-full object-cover" />
      </div>
      <p className="px-2 py-1 text-[10px] font-semibold text-gray-500 truncate">{item.label}</p>
    </button>
  );

  return (
    <div className="space-y-3">
      <div className="flex gap-1.5">
        {[["before", "Before pickup"], ["after", "After return"]].map(([key, label]) => (
          <button key={key} onClick={() => setPhase(key)}
            className={`flex-1 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
              phase === key ? "bg-arl-dark text-white border-arl-dark" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
            }`}>
            {label}{hasAny(data?.[key]) ? " ✓" : ""}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-xs text-gray-400 py-4 text-center">Loading inspection…</p>
      ) : error ? (
        <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>
      ) : !hasAny(rec) ? (
        <p className="text-xs text-gray-400 bg-gray-50 rounded-lg px-3 py-4 text-center">
          {phase === "before"
            ? "The pickup inspection hasn't been recorded yet."
            : "The return inspection is recorded after the trip ends."}
        </p>
      ) : (
        <div className="space-y-3">
          {rec.exterior.length > 0 && (
            <div className="space-y-1.5">
              <Eyebrow>Exterior</Eyebrow>
              <div className="grid grid-cols-3 gap-2">{rec.exterior.map(renderTile)}</div>
            </div>
          )}

          <InspectionMediaGallery doc={{ videos: rec.videos, extraPhotos: rec.extraPhotos }} onView={setViewing} />
        </div>
      )}

      {viewing && <ProofLightbox photo={viewing} onClose={() => setViewing(null)} />}
    </div>
  );
}

// ─── PENALTIES NOTED ON A TRIP ───────────────────────────────────────────
// What the driver sees of a trip's penalties: what it was for, how much, and where it stands with staff. Never what the
// customer has paid or still owes. A penalty the driver noted can be edited only while it is still "Under review".
const PENALTY_PILL = {
  "Under review": "bg-amber-50 text-amber-700 border-amber-200",
  Accepted:       "bg-green-50 text-green-700 border-green-200",
  Rejected:       "bg-red-50 text-red-700 border-red-200",
  Removed:        "bg-gray-100 text-gray-500 border-gray-200",
};
function TripPenalties({ penalties, onEdit, bare = false }) {
  const list = Array.isArray(penalties) ? penalties : [];
  if (list.length === 0) return null;

  // Modal view (bare): one block per penalty the driver noted — a Label | Price table, with ONE overall status for it.
  if (bare) {
    return (
      <div className="space-y-3">
        {list.map((p) => {
          const items = Array.isArray(p.items) ? p.items : [];
          const perItem = items.length > 1 && items.every((i) => Number.isFinite(Number(i.amount)));
          const rows = perItem
            ? items.map((i, idx) => ({ key: `${p.penaltyID}-${idx}`, label: i.description, amount: i.amount }))
            : [{ key: p.penaltyID, label: items.map((i) => i.description).join(", "), amount: p.amount }];
          return (
            <div key={p.penaltyID} className="rounded-xl border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between gap-3 px-4 py-2 bg-gray-50/60 border-b border-gray-100">
                <span className="text-xs text-gray-400">{p.createdAt ? `Noted ${fmtWhen(p.createdAt)}` : "Noted by you"}</span>
                <span className={`shrink-0 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${PENALTY_PILL[p.status] || PENALTY_PILL.Removed}`}>{p.status}</span>
              </div>
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-[11px] font-semibold uppercase tracking-wide text-gray-400 border-b border-gray-100">
                    <th className="py-2 pl-4 pr-3 text-left">Label</th>
                    <th className="py-2 pl-3 pr-4 text-right">Price</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.key} className="border-b border-gray-50 last:border-0">
                      <td className="py-2.5 pl-4 pr-3 text-gray-800 font-medium break-words">{r.label}</td>
                      <td className="py-2.5 pl-3 pr-4 text-right text-gray-800 font-semibold whitespace-nowrap">{peso(r.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {p.status === "Under review" && <p className="px-4 pb-3 text-[11px] text-gray-400">Waiting for a supervisor to review it.</p>}
              {(p.status === "Rejected" || p.status === "Removed") && p.reason && <p className="px-4 pb-3 text-xs text-gray-500">Reason: {p.reason}</p>}
            </div>
          );
        })}
      </div>
    );
  }

  const body = (
      <div className="space-y-2 mt-1">
        {list.map((p) => (
          <div key={p.penaltyID} className="rounded-lg border border-gray-100 px-3 py-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-sm font-medium text-arl-dark break-words">{p.items.map((i) => i.description).join(", ")}</p>
                <p className="text-xs text-gray-400">{peso(p.amount)} · {p.mine ? "Noted by you" : "Added by staff"}</p>
              </div>
              <span className={`shrink-0 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${PENALTY_PILL[p.status] || PENALTY_PILL.Removed}`}>
                {p.status}
              </span>
            </div>
            {p.status === "Under review" && (
              <p className="text-[11px] text-gray-400 mt-1">Waiting for a supervisor to review it.</p>
            )}
            {(p.status === "Rejected" || p.status === "Removed") && p.reason && (
              <p className="text-xs text-gray-500 mt-1">Reason: {p.reason}</p>
            )}
            {p.canEdit && onEdit && (
              <button onClick={() => onEdit(p)} className="mt-1.5 text-xs font-semibold text-teal-600 hover:underline">Edit</button>
            )}
          </div>
        ))}
      </div>
  );
  return bare ? body : <Block title="Penalties">{body}</Block>;
}

// Coding warnings (what the customer was told at booking) + "Coding restriction during this trip"
// (those hours as real dates, holidays flagged). Shared by the Active Locations tab and the History detail.
function TripCodingInfo({ trip }) {
  const codingByCity = warningsByCity(readCodingWarnings(trip.codingWarnings));
  const sched        = trip.codingSchedule || null;
  const codingRows   = groupCodingDays(sched?.days || []);
  const todayYmd     = manilaTodayYmd();
  return (
    <>
        {/* Coding warnings — the weekly hours the customer was warned about when booking */}
        {codingByCity.length > 0 && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
            <p className="font-semibold">⚠️ Coding warnings</p>
            <ul className="mt-1.5 space-y-0.5">
              {codingByCity.map((c) => (
                <li key={c.city || "city"}>
                  <span className="font-semibold">{c.city || "City"}</span>
                  {c.plateLastDigit != null ? ` (plate ending ${c.plateLastDigit})` : ""}
                  {c.text ? `: ${c.text}` : ""}
                </li>
              ))}
            </ul>
            <p className="mt-1.5 opacity-80">Plan the route around these days and times to avoid a coding violation.</p>
          </div>
        )}

        {/* Coding restriction — those hours as real dates inside this trip, holidays checked */}
        {sched && codingByCity.length > 0 && (
          <Block title="Coding restriction during this trip">
            {sched.holidaysChecked === false && (
              <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5 mb-1.5">
                Couldn't check holidays right now — a day listed below may actually be suspended.
              </p>
            )}
            {codingRows.length === 0 ? (
              <p className="text-xs font-medium text-green-700 bg-green-50 border border-green-200 rounded-lg px-2.5 py-2 mt-1">
                No coding hours fall within this trip's dates.
              </p>
            ) : (
              <div className="divide-y divide-gray-100">
                {codingRows.map((g) => (
                  <div key={`${g.date}|${g.city}`} className="flex items-start justify-between gap-3 py-2">
                    <div className="min-w-0">
                      <p className={`text-sm font-semibold ${g.holiday ? "text-gray-400 line-through" : "text-arl-dark"}`}>
                        {fmtYmd(g.date)}
                        {g.date === todayYmd && <span className="ml-2 no-underline inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-600 align-middle">Today</span>}
                      </p>
                      <p className="text-xs text-gray-400">{g.city || "City"}{g.plateLastDigit != null ? ` · plate ending ${g.plateLastDigit}` : ""}</p>
                    </div>
                    <div className="text-right text-xs shrink-0">
                      {g.holiday ? (
                        <>
                          <span className="inline-block font-semibold px-2 py-0.5 rounded-full bg-green-50 text-green-700 border border-green-200">Suspended · {g.holiday}</span>
                          <p className="text-gray-300 line-through mt-0.5">{g.windows.join(", ")}</p>
                        </>
                      ) : (
                        <span className="font-semibold text-red-600">{g.windows.join(", ")}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Block>
        )}
    </>
  );
}

// The "Locations" section of the History View modal: the same map + destinations list as the Active tab.
function TripLocationsSection({ trip, onFullMap }) {
  const [focusReq, setFocusReq] = useState(null);
  const allStops = tripStops(trip);
  const pinStops = allStops.filter(hasPin);
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={onFullMap} disabled={pinStops.length === 0}
          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border text-teal-700 hover:bg-teal-50 disabled:opacity-40 disabled:cursor-not-allowed">
          <IconMap className="w-3.5 h-3.5" /> Full map
        </button>
      </div>
      {pinStops.length === 0 ? (
        <div className="text-xs bg-gray-50 rounded-xl px-3 py-4 text-center space-y-1">
          <p className="text-gray-400">No map pins saved for this trip.</p>
          {trip.location && trip.location !== "—" && <p className="font-semibold text-gray-700">{trip.location}</p>}
        </div>
      ) : (
        <TripLocationsMap key={trip.id} stops={pinStops} codingAreas={tripCodingAreas(trip)} focusReq={focusReq} />
      )}
      <DestinationsList stops={allStops} onFocus={(key) => setFocusReq({ key, n: Date.now() })} />
      <TripCodingInfo trip={trip} />
    </div>
  );
}

// ─── NOTE / EDIT A PENALTY (driver form) ─────────────────────────────────
const penaltyPeso = (n) => `₱${Number(n || 0).toLocaleString()}`;

const fmtWhen = (iso) =>
  iso
    ? new Date(iso).toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" })
    : "—";

/** What is already written on this trip (what he noted + where each stands with staff), so nothing gets noted twice. */
function ExistingPenalties({ list }) {
  if (!Array.isArray(list) || list.length === 0) return null;
  return (
    <div className="rounded-xl border border-gray-100 bg-gray-50 px-3 py-2.5 space-y-2">
      <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400">Already noted on this trip ({list.length})</p>
      {list.map((p) => (
        <div key={p.penaltyID} className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-sm text-arl-dark break-words">{(p.items || []).map((i) => i.description).join(", ")}</p>
            <p className="text-[11px] text-gray-400">
              {penaltyPeso(p.amount)} · {p.mine ? "Noted by you" : "Added by staff"}
              {p.status === "Under review" ? " · waiting for a supervisor" : ""}
            </p>
            {(p.status === "Rejected" || p.status === "Removed") && p.reason && (
              <p className="text-[11px] text-gray-500">Reason: {p.reason}</p>
            )}
          </div>
          <span className={`shrink-0 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${PENALTY_PILL[p.status] || PENALTY_PILL.Removed}`}>{p.status}</span>
        </div>
      ))}
    </div>
  );
}

/**
 * Read-only "when was it due vs. when did it come back" panel shown above the
 * penalty fields (admin Penalties form and the driver's "Note a penalty"
 * form). `info` is the payload from GET /api/penalties/late-fee-preview/:id.
 *
 * It only SUGGESTS — nothing here fills in or adds a charge. Whoever is
 * noting the penalty types the amount themselves; this is just the system
 * remembering the end time and drop-off time so a late return isn't missed.
 */
function LateFeeSuggestion({ info, loading = false }) {
  if (!info) {
    return loading ? <p className="text-xs text-gray-400">Checking end time and drop-off…</p> : null;
  }

  const { scheduledEndAt, actualReturnAt, lateMinutes, billableHours, graceMinutes, ratePerHour, computedAmount } = info;

  let suggestion;
  let tone = "text-gray-600";
  if (!actualReturnAt) {
    suggestion = "Not dropped off yet — nothing to suggest.";
  } else if (billableHours > 0) {
    suggestion = `${billableHours} hour${billableHours === 1 ? "" : "s"} late: ${penaltyPeso(computedAmount)}`;
    tone = "text-amber-700 font-semibold";
  } else if (lateMinutes > 0) {
    suggestion = `${lateMinutes} min past the end time, within the ${graceMinutes}-min grace — no late fee.`;
  } else {
    suggestion = "Returned on time — no late fee.";
  }

  return (
    <div className="rounded-xl border border-gray-100 bg-gray-50 px-3 py-2.5 text-xs space-y-1">
      <div className="flex justify-between gap-3">
        <span className="text-gray-400">Booking ends</span>
        <span className="text-gray-700">{fmtWhen(scheduledEndAt)}</span>
      </div>
      <div className="flex justify-between gap-3">
        <span className="text-gray-400">Dropped off</span>
        <span className="text-gray-700">{fmtWhen(actualReturnAt)}</span>
      </div>
      <div className="flex justify-between gap-3 pt-1 border-t border-gray-100">
        <span className="text-gray-400">Suggestion</span>
        <span className={`text-right ${tone}`}>{suggestion}</span>
      </div>
      {billableHours > 0 && (
        <p className="text-[11px] text-gray-400 text-right">
          {lateMinutes} min past the end time · {graceMinutes}-min grace · {penaltyPeso(ratePerHour)}/hr
        </p>
      )}
    </div>
  );
}

/**
 * Driver's "Note a penalty" form. Every charge is typed as a line item. The
 * booking's end time, drop-off time and a suggestion ("3 hours late: ₱300")
 * are shown above the fields from the server's late-fee preview, for
 * reference only — nothing is auto-added. What submitting does depends on who is submitting:
 *   needsReview (a driver)   -> the penalty goes to a supervisor for review. The customer is NOT notified and
 *                               nothing is deducted from their deposit until a supervisor confirms it.
 *   otherwise (staff)        -> confirms the penalty right away — the customer and staff are notified, and it counts
 *                               against the deposit (shown as "amount to return") from that moment.
 *
 *   loadLateFee()         -> late-fee preview (end/drop-off times + suggestion) or null
 *   onSubmit(body)        -> POSTs the penalty (throw on error)
 *   needsReview           -> true for the driver's form (changes the wording only; the server decides by role)
 *   editing               -> { items: [{ description, amount }], ... } to edit a penalty the driver already noted
 *                            (while it is still under review): the fields start filled in, the late-fee hint is skipped
 *                            and onSubmit(body) is expected to PATCH instead of POST.
 */
function DriverPenaltyModal({ open, onClose, title, loadLateFee, onSubmit, needsReview = false, editing = null, existing = [] }) {
  const [items, setItems] = useState([{ description: "", amount: "" }]);
  const [late, setLate] = useState(null);      // preview payload
  const [lateLoading, setLateLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;
    setError(null); setLate(null);
    if (editing) {
      setItems((editing.items?.length ? editing.items : [{ description: "", amount: "" }])
        .map((i) => ({ description: i.description || "", amount: i.amount ? String(i.amount) : "" })));
      return undefined;
    }
    setItems([{ description: "", amount: "" }]);
    if (!loadLateFee) return undefined;
    let cancelled = false;
    setLateLoading(true);
    loadLateFee()
      .then((d) => { if (!cancelled) setLate(d || null); })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLateLoading(false); });
    return () => { cancelled = true; };
  }, [open, loadLateFee, editing]);

  if (!open) return null;

  const typed = items.filter((i) => i.description.trim() || Number(i.amount) > 0);
  const lineItems = typed.map((i) => ({ description: i.description.trim(), amount: Number(i.amount) || 0 }));
  const total = lineItems.reduce((s, i) => s + i.amount, 0);
  const valid = lineItems.length > 0 && lineItems.every((i) => i.description && i.amount > 0);

  const submit = async () => {
    setBusy(true); setError(null);
    try {
      await onSubmit({ lineItems, computedAmount: total, amount: total });
      onClose();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  const setItem = (idx, patch) => setItems((arr) => arr.map((it, i) => (i === idx ? { ...it, ...patch } : it)));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto p-5 space-y-3">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-bold text-arl-dark">{editing ? "Edit penalty" : "Note a penalty"}</h3>
            {title && <p className="text-xs text-gray-400">{title}</p>}
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-lg leading-none">×</button>
        </div>
        <p className="text-[11px] text-gray-400">
          {editing
            ? "A supervisor hasn't reviewed this yet, so you can still change it. Once they accept it, it's locked."
            : needsReview
            ? "This goes to a supervisor for review first. The customer isn't notified and nothing is deducted from their deposit until it's confirmed."
            : "The customer is notified right away and this is deducted from their deposit."}
        </p>

        {!editing && <ExistingPenalties list={existing} />}

        {!editing && <LateFeeSuggestion info={late} loading={lateLoading} />}

        {items.map((it, idx) => (
          <div key={idx} className="flex gap-2">
            <input value={it.description} onChange={(e) => setItem(idx, { description: e.target.value })} placeholder="e.g. Cleaning, missing floor mat"
              className="flex-1 min-w-0 border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-arl-light" />
            <input type="number" value={it.amount} onChange={(e) => setItem(idx, { amount: e.target.value })} placeholder="₱"
              className="w-24 border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-arl-light" />
          </div>
        ))}
        <button onClick={() => setItems((a) => [...a, { description: "", amount: "" }])} className="text-xs font-semibold text-teal-600">+ Add another item</button>

        <div className="flex justify-between text-sm border-t border-gray-100 pt-2">
          <span className="font-semibold text-arl-dark">Total</span><span className="font-bold text-red-600">{penaltyPeso(total)}</span>
        </div>
        {error && <p className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</p>}
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2 rounded-xl text-sm text-gray-600 hover:bg-gray-100">Cancel</button>
          <button onClick={submit} disabled={!valid || busy} className="flex-1 py-2 rounded-xl text-sm font-semibold bg-red-600 text-white disabled:opacity-40">
            {busy ? "Saving…" : editing ? "Save changes" : needsReview ? "Submit for review" : "Charge penalty"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── ACTIVE TRIPS TAB (upcoming + ongoing, with pickup/dropoff actions) ──
function ActiveTripsTab({ tab, setTab }) {
  const token = localStorage.getItem("token");
  const [searchParams, setSearchParams] = useSearchParams();

  const [trips, setTrips]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [toast, setToast]     = useState(null);
  const [busyID, setBusyID]   = useState(null);
  const [mapTrip, setMapTrip] = useState(null);
  const [penaltyTrip, setPenaltyTrip] = useState(null);  // driver "Note a penalty" form
  const [termsTrip, setTermsTrip] = useState(null);      // read-only "terms the customer accepted" modal
  const [editPenaltyCtx, setEditPenaltyCtx] = useState(null); // { penalty, trip } — editing one still under review
  // One trip at a time (Previous / Next). Tracked by ID — not position — so
  // the background refresh reordering/removing trips never swaps the page
  // under the driver. lastIdx keeps the position if the current trip vanishes.
  const [currentID, setCurrentID] = useState(null);
  const lastIdx = useRef(0);
  // Active tab of the trip card. Stored with the trip it belongs to, so moving to
  // another trip falls back to "details" without any reset logic.
  const [tripTabState, setTripTabState] = useState({ tripID: null, tab: "details" });
  // Tapping a destination in the Locations list asks the map to fly there ({ key, n } — n bumps so a repeat tap re-fires).
  const [focusReq, setFocusReq] = useState(null);
  // Remind Staff cooldowns: "<tripID>:<phase>" → epoch ms when the button
  // unlocks. Seeded from the server on every fetch (so a page refresh
  // doesn't reset it) and bumped locally right after a reminder is sent.
  const [remindUntil, setRemindUntil]   = useState({});
  const [now, setNow]                   = useState(Date.now());
  const [remindingKey, setRemindingKey] = useState(null);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  const authedFetch = useCallback((path, options = {}) => {
    return fetch(`${API_URL}${path}`, {
      ...options,
      headers: {
        Authorization: `Bearer ${token}`,
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers,
      },
    });
  }, [token]);

  // { silent: true }   = background refresh: no loading spinner, no error toast.
  // { keepList: true } = manual refresh: cards stay on screen (no "Loading…"
  //                      flash) but errors still toast.
  const fetchTrips = useCallback(async (opts) => {
    const silent = opts?.silent === true;
    const keepList = opts?.keepList === true;
    const showSpinner = !silent && !keepList;
    if (showSpinner) setLoading(true);
    try {
      const res  = await authedFetch("/api/driver-dispatch/my-trips");
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to load your trips.");
      setTrips(json.data);

      // Server sends seconds-remaining (not a timestamp) so this phone's
      // clock can't skew the countdown.
      const t0 = Date.now();
      const until = {};
      json.data.forEach((t) => ["before", "after"].forEach((ph) => {
        const secs = t.inspectionReminder?.[ph]?.retryAfterSeconds || 0;
        if (secs > 0) until[`${t.id}:${ph}`] = t0 + secs * 1000;
      }));
      json.data.forEach((t) => {
        const bSecs = t.balanceReminder?.retryAfterSeconds || 0;
        if (bSecs > 0) until[`${t.id}:balance`] = t0 + bSecs * 1000;
      });
      setRemindUntil(until);
      setNow(t0);
    } catch (e) {
      if (!silent) showToast(e.message, "error");
    } finally {
      if (showSpinner) setLoading(false);
    }
  }, [authedFetch]);

  useEffect(() => { fetchTrips(); }, [fetchTrips]);

  // The driver is often standing at the car waiting on a supervisor to
  // finish the inspection, or waiting on a payment to clear, or a new
  // booking to land — none of which the driver themself triggers, so this
  // page needs to notice on its own instead of only updating after the
  // driver's own actions. The bell (Header.jsx) is a live Firestore
  // listener, but it only pings the driver for a new assignment or a
  // discount — it doesn't touch this page's own trip cards (payment
  // status, inspection checklist, reminder cooldown), which come from a
  // plain API call. So this page still refreshes itself:
  //  - a 1-minute poll while the tab is open and visible — the inspection
  //    checklist and Remind Staff cooldown don't need anything tighter, and
  //  - an immediate refetch the moment the app is foregrounded again
  //    (switching back from another app, or waking the phone screen),
  //    rather than waiting for the next poll tick — this is what actually
  //    catches most "just got back to it" cases.
  useEffect(() => {
    // Poll every 15s while any trip is still waiting on staff's inspection
    // (so it flips to "ready" soon after the supervisor saves), else 60s.
    const waiting = trips.some((t) => !(t.status === "ongoing" ? t.afterDocsComplete : t.beforeDocsComplete));
    const id = setInterval(() => {
      if (document.visibilityState === "visible") fetchTrips({ silent: true });
    }, waiting ? 15000 : 60000);
    const onForeground = () => fetchTrips({ silent: true });
    const onVisibilityChange = () => { if (document.visibilityState === "visible") onForeground(); };
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("focus", onForeground);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("focus", onForeground);
    };
  }, [fetchTrips, trips]);

  // Notification deep link (?open=<booking doc id>): once trips have loaded,
  // open the page on that trip, then drop the param.
  useEffect(() => {
    const openID = searchParams.get("open");
    if (!openID || loading) return;
    // The notification's refID can be the booking doc id OR the business
    // bookingID (payment/refund/penalty ones use the latter) — match both.
    const match = trips.find((t) => t.id === openID || t.bookingID === openID);
    if (match) setCurrentID(match.id);
    setSearchParams((prev) => { prev.delete("open"); return prev; }, { replace: true });
  }, [searchParams, setSearchParams, loading, trips]);

  // 1-second tick, only while at least one Remind Staff cooldown is running.
  useEffect(() => {
    if (!Object.values(remindUntil).some((t) => t > now)) return undefined;
    const id = setTimeout(() => setNow(Date.now()), 1000);
    return () => clearTimeout(id);
  }, [remindUntil, now]);

  const remainingFor = (tripID, phase) =>
    Math.max(0, Math.ceil(((remindUntil[`${tripID}:${phase}`] || 0) - now) / 1000));

  // Two hard blocks before pickup, both re-checked server-side:
  //  - unresolved payment.
  //  - vehicle inspection not complete. Drivers can't fill the inspection in
  //    any more (a supervisor does), so instead of being sent to the
  //    inspection page they get the checklist + Remind Staff on the card.
  const handlePickup = (trip) => {
    const paymentReady = ["approved", "paid"].includes((trip.payment?.paymentStatus || "").toLowerCase()) && (trip.payment?.balance ?? 0) <= 0;
    if (!paymentReady) {
      showToast("Payment isn't settled yet — staff need to settle it before pickup.", "error");
      return;
    }
    if (!trip.beforeDocsComplete) {
      showToast("The vehicle inspection isn't complete yet — a supervisor needs to finish it first.", "error");
      return;
    }
    completeTripAction(trip, "pickup", "Pickup complete — GPS tracking is now active.");
  };

  // Driver nudging Owner/Admin/Supervisor because the inspection they're
  // waiting on isn't done. The server enforces the 10-minute cooldown (429
  // carries retryAfterSeconds), so this stays right even across reloads.
  const handleRemindStaff = async (trip, phase) => {
    const key = `${trip.id}:${phase}`;
    setRemindingKey(key);
    try {
      const res  = await authedFetch(`/api/driver-dispatch/my-trips/${trip.id}/remind-inspection`, {
        method: "POST",
        body: JSON.stringify({ phase }),
      });
      const json = await res.json();
      const t0 = Date.now();
      if (res.status === 429) {
        setRemindUntil((prev) => ({ ...prev, [key]: t0 + (json.retryAfterSeconds || 600) * 1000 }));
        setNow(t0);
        showToast("Staff were just reminded — you can remind them again shortly.", "error");
        return;
      }
      if (!res.ok) throw new Error(json.message || "Could not send the reminder.");
      setRemindUntil((prev) => ({ ...prev, [key]: t0 + (json.data?.retryAfterSeconds || 600) * 1000 }));
      setNow(t0);
      showToast("Staff have been reminded.");
    } catch (e) {
      showToast(e.message, "error");
    } finally {
      setRemindingKey(null);
    }
  };

  // Driver rings the CUSTOMER's bell about the balance still owed. Same server-side
  // 10-minute cooldown idea as Remind Staff (key "<trip>:balance").
  const handleRemindCustomer = async (trip) => {
    const key = `${trip.id}:balance`;
    setRemindingKey(key);
    try {
      const res  = await authedFetch(`/api/driver-dispatch/my-trips/${trip.id}/remind-balance`, { method: "POST" });
      const json = await res.json();
      const t0 = Date.now();
      if (res.status === 429) {
        setRemindUntil((prev) => ({ ...prev, [key]: t0 + (json.retryAfterSeconds || 600) * 1000 }));
        setNow(t0);
        showToast("The customer was just reminded — you can remind them again shortly.", "error");
        return;
      }
      if (!res.ok) throw new Error(json.message || "Could not send the reminder.");
      setRemindUntil((prev) => ({ ...prev, [key]: t0 + 600 * 1000 }));
      setNow(t0);
      showToast("The customer has been reminded of their balance.");
    } catch (e) {
      showToast(e.message, "error");
    } finally {
      setRemindingKey(null);
    }
  };

  // "On my way" = heading to the customer's pickup location. NOT Start Pickup (that's
  // when the customer has been received). Same readiness checks as pickup; the server re-checks.
  const handleOnMyWay = (trip) => {
    const paymentReady = isPaymentReady(trip);
    if (!paymentReady) {
      showToast("Payment isn't settled yet — staff need to settle it before you head out.", "error");
      return;
    }
    if (!trip.beforeDocsComplete) {
      showToast("The vehicle inspection isn't complete yet — a supervisor needs to finish it first.", "error");
      return;
    }
    completeTripAction(trip, "on-my-way", "The customer has been told you're on the way.");
  };

  const completeTripAction = async (trip, action, successMsg) => {
    setBusyID(trip.id);
    try {
      const res  = await authedFetch(`/api/driver-dispatch/my-trips/${trip.id}/${action}`, { method: "PATCH" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Action failed.");
      showToast(successMsg);
      await fetchTrips({ silent: true });
    } catch (e) {
      showToast(e.message, "error");
    } finally {
      setBusyID(null);
    }
  };

  const handleDropoff = async (trip) => {
    setBusyID(trip.id);
    try {
      const res  = await authedFetch(`/api/driver-dispatch/my-trips/${trip.id}/dropoff`, { method: "PATCH" });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to mark dropped off.");
      showToast("Marked dropped off.");
      await fetchTrips({ silent: true });
    } catch (e) {
      showToast(e.message, "error");
    } finally {
      setBusyID(null);
    }
  };

  const loadLateFee = useCallback(async () => {
    if (!penaltyTrip) return null;
    const res  = await authedFetch(`/api/penalties/late-fee-preview/${encodeURIComponent(penaltyTrip.bookingID)}`);
    const json = await res.json();
    return res.ok ? json.data : null;
  }, [penaltyTrip, authedFetch]);

  const submitPenalty = async (body) => {
    const res  = await authedFetch(`/api/driver-dispatch/my-trips/${penaltyTrip.id}/penalty`, {
      method: "POST", body: JSON.stringify(body),
    });
    const json = await res.json();
    if (!res.ok) {
      await fetchTrips({ silent: true });   // the trip may have just ended (completed/cancelled): bring this screen up to date
      throw new Error(json.message || "Couldn't charge the penalty.");
    }
    showToast("Penalty sent for review — the customer isn't notified until a supervisor confirms it.");
    await fetchTrips({ silent: true });
  };

  const submitPenaltyEdit = async (body) => {
    const res  = await authedFetch(`/api/driver-dispatch/my-penalties/${editPenaltyCtx.penalty.penaltyID}`, {
      method: "PATCH", body: JSON.stringify(body),
    });
    const json = await res.json();
    if (!res.ok) {
      await fetchTrips({ silent: true });   // it may have just been accepted/rejected: show where it stands now
      throw new Error(json.message || "Couldn't update the penalty.");
    }
    showToast("Penalty updated — staff have been told it changed.");
    await fetchTrips({ silent: true });
  };

  return (
    <div className="space-y-3">
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"
        }`}>{toast.msg}</div>
      )}

      {(() => {
        const curTrip = trips.find((t) => t.id === currentID) || trips[Math.min(lastIdx.current, trips.length - 1)] || null;
        const upcomingTrips = trips.filter((t) => t.status !== "ongoing");
        const ongoingTrips  = trips.filter((t) => t.status === "ongoing");
        const readyTrips    = upcomingTrips.filter((t) => t.beforeDocsComplete && isPaymentReady(t));
        const notReady      = upcomingTrips.length - readyTrips.length;
        const toDropOff     = ongoingTrips.filter((t) => !t.droppedOffTime).length;
        const jump    = (list) => { if (list[0]) setCurrentID(list[0].id); };
        const inGroup = (list) => !!curTrip && list.some((t) => t.id === curTrip.id);
        return (
          <TripsGroupBox
            tab={tab} setTab={setTab} refreshing={refreshing}
            onRefresh={async () => { setRefreshing(true); await fetchTrips({ keepList: true }); setRefreshing(false); }}
            cards={<>
              <StatCard icon={<IconClock className="w-5 h-5" />} value={upcomingTrips.length} label="Upcoming" color="yellow"
                sub={notReady > 0 ? `${notReady} not ready` : null}
                active={inGroup(upcomingTrips)} onClick={() => jump(upcomingTrips)} />
              <StatCard icon={<IconSteering className="w-5 h-5" />} value={ongoingTrips.length} label="Ongoing" color="green"
                sub={toDropOff > 0 ? `${toDropOff} to drop off` : null}
                active={inGroup(ongoingTrips)} onClick={() => jump(ongoingTrips)} />
              <StatCard icon={<IconShield />} value={readyTrips.length} label="Ready for pickup" color="teal"
                active={inGroup(readyTrips)} onClick={() => jump(readyTrips)} />
            </>}
          />
        );
      })()}

      {loading && trips.length === 0 ? (
        <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>
      ) : trips.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-soft p-10 text-center">
          <IconSteering className="w-8 h-8 mx-auto text-gray-300 mb-2" />
          <p className="text-sm font-semibold text-arl-dark">No trips assigned right now</p>
          <p className="text-xs text-gray-400 mt-1">Today's and upcoming trips will show here once dispatched.</p>
        </div>
      ) : (() => {
        // Trips arrive sorted by start time, so index 0 is the closest one
        // (an ongoing trip started earlier, so it naturally comes first).
        const found = trips.findIndex((t) => t.id === currentID);
        const idx   = found >= 0 ? found : Math.min(lastIdx.current, trips.length - 1);
        lastIdx.current = idx;
        const trip = trips[idx];
        const goTo = (i) => { if (trips[i]) setCurrentID(trips[i].id); };

        const isOngoing   = trip.status === "ongoing";
        const droppedOff  = fmtTime(trip.droppedOffTime);
        const codingByCity = warningsByCity(readCodingWarnings(trip.codingWarnings));
        const paymentReady = isPaymentReady(trip);
        const balance     = trip.payment?.balance ?? 0;
        const blocked     = !trip.beforeDocsComplete || !paymentReady;
        const mapStops    = tripStops(trip);                    // everything to list (pickup, dropoff, extra stops)
        const pinStops    = mapStops.filter((st) => hasPin(st)); // only those with coordinates can go on the map
        const inspection  = trip.beforeInspection || { photos: false, parts: false, complete: !!trip.beforeDocsComplete };
        // Dated coding restriction (from the backend: only days inside this trip, holidays flagged).
        // Older responses without it fall back to the plain booking-time warnings.
        const sched          = trip.codingSchedule || null;
        const codingDays     = sched?.days || [];
        const restrictedDays = codingDays.filter((d) => !d.holiday);
        const codingAreas    = tripCodingAreas(trip);
        const activeTab    = tripTabState.tripID === trip.id ? tripTabState.tab : "details";
        const setActiveTab = (tab) => setTripTabState({ tripID: trip.id, tab });
        const tripTabs = [
          { key: "details",    label: "Details" },
          // amber dot = coding applies at some point during this trip
          { key: "locations",  label: "Locations", alert: sched ? restrictedDays.length > 0 : codingByCity.length > 0 },
          // amber dot = pre-trip inspection still outstanding
          { key: "inspection", label: "Inspection", alert: !isOngoing && !trip.beforeDocsComplete },
        ];

        return (
          <div key={trip.id} id={`trip-${trip.id}`} className="space-y-4">
            {/* ONE card for the whole trip: pager → header → tabs → content.
                Previously the pager, Booking, Locations and Inspection were four
                separate cards, so "Trip 1 of 3" looked like it only belonged to
                the first box. The Start Pickup / Dropoff bar below stays outside
                (sticky) so it's reachable from every tab. */}
            <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
              {/* Pager */}
              <div className="p-3 space-y-2.5 border-b border-gray-100">
                <div className="flex items-center justify-between gap-2">
                  <button onClick={() => goTo(idx - 1)} disabled={idx === 0}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed">
                    ‹ Previous
                  </button>
                  <span className="text-xs text-gray-400">Trip <span className="font-semibold text-arl-dark">{idx + 1}</span> of {trips.length}</span>
                  <button onClick={() => goTo(idx + 1)} disabled={idx === trips.length - 1}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed">
                    Next ›
                  </button>
                </div>
                {trips.length > 1 && (
                  <div className="flex gap-1.5 overflow-x-auto pb-0.5">
                    {trips.map((t, i) => (
                      <button key={t.id} onClick={() => goTo(i)} title={`${t.customerName} — ${t.vehicleName}`}
                        className={`shrink-0 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                          i === idx ? "bg-arl-dark text-white" : "text-gray-600 border hover:bg-gray-50"
                        }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${t.status === "ongoing" ? "bg-green-500" : "bg-yellow-500"}`} />
                        {fmtDateTime(t.startDateTime)}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Header */}
              <div className="flex items-start justify-between gap-3 px-5 pt-4 pb-3">
                <div className="min-w-0">
                  <Eyebrow>{isOngoing ? "Ongoing trip" : "Upcoming trip"}{trip.modeOfDriving === "With Chauffeur" ? " · Chauffeur" : ""}</Eyebrow>
                  <h3 className="font-bold text-arl-dark text-lg truncate">{trip.customerName}</h3>
                  <div className="mt-1.5"><StatusPill status={trip.status} /></div>
                </div>
                <div className={`w-11 h-11 shrink-0 flex items-center justify-center rounded-xl ${isOngoing ? "bg-green-50 text-green-600" : "bg-yellow-50 text-yellow-600"}`}>
                  <IconSteering className="w-5 h-5" />
                </div>
              </div>

              {/* Tabs */}
              <div role="tablist" className="flex gap-1 px-5 border-b border-gray-100">
                {tripTabs.map((t) => (
                  <button key={t.key} role="tab" aria-selected={activeTab === t.key} onClick={() => setActiveTab(t.key)}
                    className={`relative px-3 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors ${
                      activeTab === t.key ? "border-arl-dark text-arl-dark" : "border-transparent text-gray-400 hover:text-gray-600"
                    }`}>
                    {t.label}
                    {t.alert && <span className="absolute top-1.5 right-0.5 w-1.5 h-1.5 rounded-full bg-amber-500" title="Needs attention" />}
                  </button>
                ))}
              </div>

              <div className="px-5 py-4 space-y-3">
                {/* ── DETAILS ── */}
                {activeTab === "details" && (
                  <>
                    <button onClick={() => setTermsTrip(trip)}
                      className="text-xs font-semibold text-teal-600 hover:underline">
                      View accepted terms
                    </button>
                    {/* Quick actions: remind the customer to pay (left) and tell them you're on the way (right) */}
                    {!isOngoing && (balance > 0 || !trip.enRouteAt) && (
                      <div className="flex gap-2">
                        {balance > 0 && (
                          <button
                            onClick={() => handleRemindCustomer(trip)}
                            disabled={remainingFor(trip.id, "balance") > 0 || remindingKey === `${trip.id}:balance`}
                            className="flex-1 inline-flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl text-sm font-semibold border border-amber-200 text-amber-700 hover:bg-amber-50 active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                            {remindingKey === `${trip.id}:balance`
                              ? "Sending…"
                              : remainingFor(trip.id, "balance") > 0
                                ? `Remind again in ${fmtCountdown(remainingFor(trip.id, "balance"))}`
                                : "🔔 Remind to pay"}
                          </button>
                        )}
                        {!trip.enRouteAt && (
                          <button onClick={() => handleOnMyWay(trip)}
                            disabled={busyID === trip.id || blocked}
                            className="flex-1 inline-flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl text-sm font-semibold text-teal-700 border border-teal-200 hover:bg-teal-50 active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                            🚗 On my way
                          </button>
                        )}
                      </div>
                    )}

                    <Block title="Booking">
                      <Line label="Vehicle">{trip.vehicleName}</Line>
                      {trip.customerPhone && trip.customerPhone !== "—" && (
                        <Line label="Customer phone">
                          <a href={`tel:${trip.customerPhone}`} className="font-medium text-teal-600 hover:underline">{trip.customerPhone}</a>
                        </Line>
                      )}
                      <Line label="Starts">{fmtDateTimeLong(trip.startDateTime)}</Line>
                      <Line label="Ends">{fmtDateTimeLong(trip.endDateTime)}</Line>
                      {!isOngoing && (
                        <Line label="Heading to pickup">
                          {trip.enRouteAt
                            ? <span className="font-semibold text-green-700">On the way · since {fmtTime(trip.enRouteAt)}</span>
                            : <span className="text-gray-400">Not yet</span>}
                        </Line>
                      )}
                      <Line label="Payment">
                        <span className={`font-semibold ${paymentReady ? "text-green-700" : "text-amber-600"}`}>
                          {paymentReady ? "Settled" : (trip.payment?.paymentStatus || "Pending")}
                          {balance > 0 ? ` · Balance ${peso(balance)}` : ""}
                        </span>
                      </Line>
                    </Block>

                    {isOngoing && (
                      <Block title="Trip progress">
                        <Line label="Picked up"><span className="font-semibold">{fmtTime(trip.startedAt) || "—"}</span></Line>
                        <Line label="Dropped off"><span className="font-semibold">{droppedOff || "Not recorded"}</span></Line>
                      </Block>
                    )}

                    <TripPenalties penalties={trip.penalties} onEdit={(penalty) => setEditPenaltyCtx({ penalty, trip })} />
                  </>
                )}

                {/* ── LOCATIONS ── */}
                {activeTab === "locations" && (
                  <>
                    <div className="flex justify-end">
                      <button onClick={() => setMapTrip(trip)} disabled={pinStops.length === 0}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border text-teal-700 hover:bg-teal-50 disabled:opacity-40 disabled:cursor-not-allowed">
                        <IconMap className="w-3.5 h-3.5" /> Full map
                      </button>
                    </div>

                    {pinStops.length === 0 ? (
                      <div className="text-xs bg-gray-50 rounded-xl px-3 py-4 text-center space-y-1">
                        <p className="text-gray-400">No map pins saved for this trip.</p>
                        {trip.location && trip.location !== "—" && <p className="font-semibold text-gray-700">{trip.location}</p>}
                      </div>
                    ) : (
                      <TripLocationsMap key={trip.id} stops={pinStops} codingAreas={codingAreas} focusReq={focusReq} />
                    )}

                    {/* Destinations — tap one to fly the map to it */}
                    <DestinationsList stops={mapStops} onFocus={(key) => setFocusReq({ key, n: Date.now() })} />

                    {/* Coding warnings + the dated coding restriction for this trip */}
                    <TripCodingInfo trip={trip} />
                  </>
                )}

                {/* ── INSPECTION ── */}
                {activeTab === "inspection" && (
                  <>
                    {!isOngoing && (
                      paymentReady ? (
                        <InspectionPanel
                          inspection={inspection}
                          phase="before"
                          remaining={remainingFor(trip.id, "before")}
                          sending={remindingKey === `${trip.id}:before`}
                          onRemind={() => handleRemindStaff(trip, "before")}
                        />
                      ) : (
                        <div className="space-y-2">
                          <p className="text-xs font-medium text-amber-600 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
                            Waiting for staff to settle payment{balance > 0 ? ` · Balance ${peso(balance)}` : ""}
                          </p>
                        </div>
                      )
                    )}
                    <TripInspectionProof
                      key={trip.id}
                      tripID={trip.id}
                      authedFetch={authedFetch}
                      refreshKey={`${trip.beforeDocsComplete}:${trip.afterDocsComplete}`}
                    />
                  </>
                )}
              </div>

              {/* Actions — inside the trip card (no longer sticky to the screen) */}
              <div className="border-t border-gray-100 p-3 flex gap-2">
              {!isOngoing ? (
                <>
                  <button onClick={() => handlePickup(trip)}
                    disabled={busyID === trip.id || blocked}
                    className="flex-1 inline-flex items-center justify-center gap-1 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-arl-dark hover:opacity-90 active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                    {busyID === trip.id ? "…" : blocked ? "Not Available Yet" : "▶ Start Pickup"}
                  </button>
                </>
              ) : (
                <>
                  <button onClick={() => setPenaltyTrip(trip)}
                    className="flex-1 inline-flex items-center justify-center gap-1 px-4 py-2.5 rounded-xl text-sm font-semibold text-red-600 border border-red-200 hover:bg-red-50 active:scale-[0.99] transition-all">
                    Penalty
                  </button>
                  {!droppedOff && (
                    <button onClick={() => handleDropoff(trip)} disabled={busyID === trip.id}
                      className="flex-[1.6] inline-flex items-center justify-center gap-1 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-green-600 hover:bg-green-700 active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                      {busyID === trip.id ? "…" : <><IconPin className="w-3.5 h-3.5" /> Mark Dropped Off</>}
                    </button>
                  )}
                </>
              )}
              </div>
            </div>
          </div>
        );
      })()}

      <TripMapModal
        open={!!mapTrip}
        onClose={() => setMapTrip(null)}
        title={mapTrip ? `${mapTrip.customerName} — ${mapTrip.vehicleName}` : "Trip Route"}
        stops={mapTrip ? tripStops(mapTrip) : []}
        codingAreas={mapTrip ? tripCodingAreas(mapTrip) : []}
      />
      <TripTermsModal open={!!termsTrip} onClose={() => setTermsTrip(null)} trip={termsTrip} token={token} />
      <DriverPenaltyModal
        open={!!penaltyTrip}
        onClose={() => setPenaltyTrip(null)}
        title={penaltyTrip ? `${penaltyTrip.customerName} — ${penaltyTrip.vehicleName}` : ""}
        loadLateFee={loadLateFee}
        existing={(trips.find((t) => t.id === penaltyTrip?.id) || penaltyTrip)?.penalties || []}
        onSubmit={submitPenalty}
        needsReview
      />
      <DriverPenaltyModal
        open={!!editPenaltyCtx}
        onClose={() => setEditPenaltyCtx(null)}
        title={editPenaltyCtx ? `${editPenaltyCtx.trip.customerName} — ${editPenaltyCtx.trip.vehicleName}` : ""}
        editing={editPenaltyCtx?.penalty || null}
        onSubmit={submitPenaltyEdit}
        needsReview
      />
    </div>
  );
}

// ─── HISTORY TAB (completed/cancelled/stolen) ─────────────────────────────
// ─── History table helpers (same look/behaviour as the Bookings page) ───
const HISTORY_PAGE_SIZE = 10;

const HISTORY_SEARCH_BY = [
  { key: "customer", label: "Customer",   type: "text" },
  { key: "phone",    label: "Contact No.", type: "text" },
  { key: "vehicle",  label: "Vehicle",    type: "text" },
  { key: "location", label: "Location",   type: "text" },
  { key: "start",    label: "Trip Start", type: "date" },
  { key: "end",      label: "Trip End",   type: "date" },
  { key: "booking",  label: "Booking ID", type: "text" },
];

// "YYYY-MM-DD" (local day) of a date value, or null — what the date picker is compared against.
const historyDayKey = (val) => {
  if (!val) return null;
  const d = new Date(val);
  if (isNaN(d)) return null;
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
const fmtDayOnly = (val) => {
  if (!val) return "—";
  const d = new Date(val);
  if (isNaN(d)) return "—";
  return d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
};
const fmtTimeOnly = (val) => {
  if (!val) return "";
  const d = new Date(val);
  if (isNaN(d)) return "";
  return d.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" });
};

const IconChevronsUpDown = ({ className = "w-3.5 h-3.5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none">
    <path d="M7 15l5 5 5-5M7 9l5-5 5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const IconSortArrow = ({ dir, className = "w-3.5 h-3.5" }) => (
  <svg className={`${className} transition-transform ${dir === "desc" ? "rotate-180" : ""}`} viewBox="0 0 24 24" fill="none">
    <path d="M12 19V5M5 12l7-7 7 7" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

function HistorySortableTh({ label, sortKey, activeKey, sortDir, onSort }) {
  const active = activeKey === sortKey;
  return (
    <th className="px-4 py-3 text-left select-none">
      <button onClick={() => onSort(sortKey)}
        className={`flex items-center gap-1.5 uppercase tracking-wide text-xs font-semibold px-2 py-1 -mx-2 rounded-lg transition-colors ${
          active ? "text-teal-700 bg-teal-50" : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
        }`}>
        {label}
        {active ? <IconSortArrow dir={sortDir} /> : <IconChevronsUpDown />}
      </button>
    </th>
  );
}

function HistoryPagination({ page, totalPages, onChange, start, pageSize, count }) {
  if (count === 0) return null;
  const nums = [1];
  for (let n = page - 1; n <= page + 1; n++) if (n > 1 && n < totalPages) nums.push(n);
  if (totalPages > 1) nums.push(totalPages);
  const dedup = [...new Set(nums)].sort((a, b) => a - b);
  const rangeEnd = Math.min(start + pageSize, count);
  return (
    <div className="flex items-center justify-between px-5 py-3 border-t bg-gray-50/50">
      <p className="text-xs text-gray-400">Showing {count === 0 ? 0 : start + 1}–{rangeEnd} of {count}</p>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange(Math.max(1, page - 1))} disabled={page === 1}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">Prev</button>
        {dedup.map((n, i) => (
          <span key={n} className="flex items-center">
            {i > 0 && n - dedup[i - 1] > 1 && <span className="px-1.5 text-gray-300 text-xs">…</span>}
            <button onClick={() => onChange(n)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${n === page ? "bg-arl-primary text-white shadow" : "border text-gray-600 hover:bg-white"}`}>{n}</button>
          </span>
        ))}
        <button onClick={() => onChange(Math.min(totalPages, page + 1))} disabled={page === totalPages}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">Next</button>
      </div>
    </div>
  );
}

function HistoryTab({ tab, setTab }) {
  const token = localStorage.getItem("token");

  const [trips, setTrips]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const [mapTrip, setMapTrip] = useState(null);
  const [detailTrip, setDetailTrip] = useState(null);
  const [editPenaltyCtx, setEditPenaltyCtx] = useState(null); // { penalty, trip } — editing one still under review
  const [statusF, setStatusF] = useState("All");   // click a summary card to filter, click again to clear
  const [search, setSearch]     = useState("");
  const [searchBy, setSearchBy] = useState("customer");
  const [dateValue, setDateValue] = useState("");
  const [sortKey, setSortKey]   = useState("start");
  const [sortDir, setSortDir]   = useState("desc");
  const [page, setPage]         = useState(1);

  const authedFetch = useCallback((path, options = {}) => fetch(`${API_URL}${path}`, {
    ...options,
    headers: { Authorization: `Bearer ${token}`, ...options.headers },
  }), [token]);

  const fetchHistory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res  = await fetch(`${API_URL}/api/driver-dispatch/my-trips/history`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to load trip history.");
      setTrips(json.data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  // History shows the penalties the driver himself wrote (with their price and where each one ended up).
  const minePenalties = (t) => (Array.isArray(t.penalties) ? t.penalties : []).filter((p) => p.mine);

  const submitPenaltyEdit = async (body) => {
    const res  = await fetch(`${API_URL}/api/driver-dispatch/my-penalties/${editPenaltyCtx.penalty.penaltyID}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    if (!res.ok) {
      await fetchHistory();   // it may have just been accepted/rejected: show where it stands now
      throw new Error(json.message || "Couldn't update the penalty.");
    }
    await fetchHistory();
  };

  return (
    <div className="space-y-3">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl p-3">{error}</div>
      )}

      {(() => {
        const count = (st) => trips.filter((t) => t.status === st).length;
        const card = (st, icon, label, color) => (
          <StatCard icon={icon} value={count(st)} label={label} color={color}
            active={statusF === st} onClick={() => { setStatusF(statusF === st ? "All" : st); setPage(1); }} />
        );
        return (
          <TripsGroupBox
            tab={tab} setTab={setTab} refreshing={loading} onRefresh={fetchHistory}
            cards={<>
              {card("completed", <IconShield />, "Completed", "blue")}
              {card("cancelled", <IconClock className="w-5 h-5" />, "Cancelled", "yellow")}
              {card("stolen", <IconPin className="w-5 h-5" />, "Flagged stolen", "red")}
            </>}
          />
        );
      })()}

      {(() => {
        const searchType = HISTORY_SEARCH_BY.find((o) => o.key === searchBy)?.type || "text";
        const q = search.trim().toLowerCase();
        const filtered = trips.filter((t) => {
          if (statusF !== "All" && t.status !== statusF) return false;
          if (searchType === "date") {
            if (!dateValue) return true;
            return historyDayKey(searchBy === "start" ? t.startDateTime : t.endDateTime) === dateValue;
          }
          if (!q) return true;
          const hay = {
            customer: t.customerName, phone: t.customerPhone, vehicle: t.vehicleName,
            location: t.location, booking: t.bookingID || t.id,
          }[searchBy];
          return String(hay || "").toLowerCase().includes(q);
        });
        const ts = (v) => { const n = new Date(v).getTime(); return isNaN(n) ? 0 : n; };
        const sorted = [...filtered].sort((a, b) => {
          const av = ts(sortKey === "end" ? a.endDateTime : a.startDateTime);
          const bv = ts(sortKey === "end" ? b.endDateTime : b.startDateTime);
          return sortDir === "asc" ? av - bv : bv - av;
        });
        const count = sorted.length;
        const totalPages = Math.max(1, Math.ceil(count / HISTORY_PAGE_SIZE));
        const safePage = Math.min(page, totalPages);
        const start = (safePage - 1) * HISTORY_PAGE_SIZE;
        const pageItems = sorted.slice(start, start + HISTORY_PAGE_SIZE);
        const handleSort = (key) => {
          if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
          else { setSortKey(key); setSortDir("desc"); }
          setPage(1);
        };
        const COLS = 9;

        return (
          <div className="bg-white rounded-2xl border overflow-hidden">
            <div className="flex flex-wrap gap-3 items-end p-4 border-b">
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Search by</span>
                <select value={searchBy}
                  onChange={(e) => { setSearchBy(e.target.value); setSearch(""); setDateValue(""); setPage(1); }}
                  className="px-3 py-2 border rounded-xl text-sm text-gray-700 outline-none bg-white">
                  {HISTORY_SEARCH_BY.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
                </select>
              </div>
              {searchType === "date" ? (
                <input type="date" value={dateValue}
                  onChange={(e) => { setDateValue(e.target.value); setPage(1); }}
                  className="flex-1 min-w-52 px-4 py-2 border rounded-xl text-sm outline-none" />
              ) : (
                <input type="text"
                  placeholder={`Enter ${(HISTORY_SEARCH_BY.find((o) => o.key === searchBy)?.label || "").toLowerCase()}...`}
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                  className="flex-1 min-w-52 px-4 py-2 border rounded-xl text-sm outline-none" />
              )}
              <select value={statusF} onChange={(e) => { setStatusF(e.target.value); setPage(1); }}
                className="px-3 py-2 border rounded-xl text-sm text-gray-700 outline-none bg-white">
                <option value="All">All statuses</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
                <option value="stolen">Flagged stolen</option>
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-gray-400 text-xs uppercase tracking-wide">
                  <tr>
                    <HistorySortableTh label="Trip Start" sortKey="start" activeKey={sortKey} sortDir={sortDir} onSort={handleSort} />
                    <HistorySortableTh label="Trip End" sortKey="end" activeKey={sortKey} sortDir={sortDir} onSort={handleSort} />
                    <th className="px-4 py-3 text-left">Customer</th>
                    <th className="px-4 py-3 text-left">Contact No.</th>
                    <th className="px-4 py-3 text-left">Vehicle</th>
                    <th className="px-4 py-3 text-left">Location</th>
                    <th className="px-4 py-3 text-left">Penalties</th>
                    <th className="px-4 py-3 text-left">Status</th>
                    <th className="pl-4 pr-8 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && trips.length === 0 ? (
                    Array.from({ length: 6 }).map((_, i) => (
                      <tr key={i} className="border-t">
                        {Array.from({ length: COLS }).map((__, j) => (
                          <td key={j} className="px-4 py-3"><div className="h-4 bg-gray-100 rounded animate-pulse" /></td>
                        ))}
                      </tr>
                    ))
                  ) : count === 0 ? (
                    <tr><td colSpan={COLS} className="text-center text-gray-400 py-12">
                      {trips.length === 0 ? "No completed trips yet — trips you've finished, cancelled, or flagged will show here." : "No trips found"}
                    </td></tr>
                  ) : (
                    pageItems.map((trip) => (
                      <tr key={trip.id} className="border-t hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="text-gray-700">{fmtDayOnly(trip.startDateTime)}</span>
                          <span className="mx-1.5 text-gray-300">|</span>
                          <span className="text-gray-500">{fmtTimeOnly(trip.startDateTime)}</span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="text-gray-700">{fmtDayOnly(trip.endDateTime)}</span>
                          <span className="mx-1.5 text-gray-300">|</span>
                          <span className="text-gray-500">{fmtTimeOnly(trip.endDateTime)}</span>
                        </td>
                        <td className="px-4 py-3 font-medium text-gray-800">
                          {trip.customerName}
                          {trip.modeOfDriving === "With Chauffeur" && <span className="ml-1.5 text-xs text-gray-400 font-normal">· Chauffeur</span>}
                        </td>
                        <td className="px-4 py-3 text-gray-700 whitespace-nowrap">
                          {trip.customerPhone && trip.customerPhone !== "—"
                            ? <a href={`tel:${trip.customerPhone}`} className="text-teal-600 hover:underline">{trip.customerPhone}</a>
                            : "—"}
                        </td>
                        <td className="px-4 py-3 text-gray-700">{trip.vehicleName}</td>
                        <td className="px-4 py-3 text-gray-600 max-w-[16rem] truncate" title={trip.location}>{trip.location}</td>
                        <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{minePenalties(trip).length || "—"}</td>
                        <td className="px-4 py-3"><StatusPill status={trip.status} /></td>
                        <td className="pl-4 pr-8 py-3 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-2">
                            <button onClick={() => setDetailTrip(trip)}
                              className="px-3.5 py-1 rounded-lg text-xs font-semibold bg-arl-primary text-white hover:bg-[#16526a] transition-colors">View</button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                  {/* Same as Bookings: pad a short page with empty rows so the table always keeps its 10-row height. */}
                  {!loading && pageItems.length > 0 && Array.from({ length: Math.max(0, HISTORY_PAGE_SIZE - pageItems.length) }).map((_, i) => (
                    <tr key={`filler-${i}`} aria-hidden="true" className="border-t">
                      <td colSpan={COLS} className="h-[53px]">&nbsp;</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <HistoryPagination page={safePage} totalPages={totalPages} onChange={setPage} start={start} pageSize={HISTORY_PAGE_SIZE} count={count} />
          </div>
        );
      })()}

      <TripMapModal
        open={!!mapTrip}
        onClose={() => setMapTrip(null)}
        title={mapTrip ? `${mapTrip.customerName} — ${mapTrip.vehicleName}` : "Trip Route"}
        stops={mapTrip ? tripStops(mapTrip) : []}
        codingAreas={mapTrip ? tripCodingAreas(mapTrip) : []}
      />
      <TripDetailModal
        key={detailTrip?.id || "none"}
        open={!!detailTrip}
        onClose={() => setDetailTrip(null)}
        trip={detailTrip}
        sections={detailTrip ? [
          { key: "penalties", title: `Penalties you noted (${minePenalties(detailTrip).length})`, render: () => (
            minePenalties(detailTrip).length === 0
              ? <p className="text-xs text-gray-400 bg-gray-50 rounded-lg px-3 py-4 text-center">You didn't note any penalties on this trip.</p>
              : <TripPenalties penalties={minePenalties(detailTrip)} bare />
          ) },
          { key: "map", title: "Locations", render: () => (
            <TripLocationsSection trip={detailTrip} onFullMap={() => { setMapTrip(detailTrip); setDetailTrip(null); }} />
          ) },
          { key: "inspection", title: "Vehicle inspection", render: () => (
            <TripInspectionProof key={detailTrip.id} tripID={detailTrip.id} authedFetch={authedFetch} refreshKey="history" />
          ) },
          { key: "terms", title: "Terms & Conditions", render: () => (
            <TripTermsContent key={detailTrip.id} tripID={detailTrip.id} token={token} />
          ) },
        ] : []}
        // No "View Full Inspection" link: Vehicle Inspections is staff-only.
      />
      <DriverPenaltyModal
        open={!!editPenaltyCtx}
        onClose={() => setEditPenaltyCtx(null)}
        title={editPenaltyCtx ? `${editPenaltyCtx.trip.customerName} — ${editPenaltyCtx.trip.vehicleName}` : ""}
        editing={editPenaltyCtx?.penalty || null}
        onSubmit={submitPenaltyEdit}
        needsReview
      />
    </div>
  );
}

// ─── MAIN: My Trips (Active | History tabs) ───────────────────────────────
// /my-trips/history used to be its own page — now it's just this page with
// ?tab=history, see the redirect in App.jsx for old links/bookmarks.
export default function MyTrips() {
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get("tab") === "history" ? "history" : "active";

  const setTab = (t) => setSearchParams(t === "active" ? {} : { tab: t }, { replace: true });

  return (
    <div className="w-full px-4 space-y-4">
      <div className="shrink-0">
        <h1 className="text-2xl font-bold text-arl-dark">My Trips</h1>
      </div>

      {tab === "active" ? <ActiveTripsTab tab={tab} setTab={setTab} /> : <HistoryTab tab={tab} setTab={setTab} />}
    </div>
  );
}