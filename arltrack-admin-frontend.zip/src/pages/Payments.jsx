import { useEffect, useState, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import usePolling from "../hooks/usePolling";
import { useCurrency } from "../context/CurrencyContext";
import { useAuth } from "../context/AuthContext";
import { ROLES } from "../config/pagePermissions";
import PaymentEntriesPanel from "../components/shared/PaymentEntriesPanel";

// ─── SVG ICONS ───────────────────────────────────────────────────────────────

const IconMoney = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="6" width="20" height="13" rx="2" stroke="currentColor" strokeWidth="1.75" />
    <circle cx="12" cy="12.5" r="2.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M6 6V5M18 6V5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const IconCheck = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconClock = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.75" />
    <path d="M12 7v5l3 3" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
  </svg>
);

const IconCreditCard = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="5" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="1.75" />
    <path d="M2 10h20" stroke="currentColor" strokeWidth="1.75" />
    <path d="M6 15h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const IconX = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const IconChevronDown = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// ─── SORT HEADER (same pattern as Bookings.jsx / Users.jsx) ──────────────────
// Neutral up/down chevrons when a column isn't the active sort (reads as
// "sortable" even before it's clicked), a bold single arrow in the active
// color once it is — toggles asc/desc on repeat clicks of the same column.
const IconChevronsUpDown = ({ className = "w-3.5 h-3.5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7 15l5 5 5-5M7 9l5-5 5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconSortArrow = ({ dir, className = "w-3.5 h-3.5" }) => (
  <svg
    className={`${className} transition-transform ${dir === "desc" ? "rotate-180" : ""}`}
    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M12 19V5M5 12l7-7 7 7" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

function SortableTh({ label, sortKey: key, sortKeyState, sortDir, onSort, className = "" }) {
  const active = sortKeyState === key;
  return (
    <th className={`px-4 py-3 text-left select-none ${className}`}>
      <button
        onClick={() => onSort(key)}
        className={`flex items-center gap-1.5 uppercase tracking-wide text-xs font-semibold px-2 py-1 -mx-2 rounded-lg transition-colors ${
          active ? "text-teal-700 bg-teal-50" : "text-gray-400 hover:text-gray-700 hover:bg-gray-100"
        }`}
      >
        {label}
        {active ? <IconSortArrow dir={sortDir} /> : <IconChevronsUpDown />}
      </button>
    </th>
  );
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function peso(n, fmtFn) {
  if (n == null || n === "") return "—";
  if (fmtFn) return fmtFn(n);
  return `₱${Number(n).toLocaleString("en-PH", { minimumFractionDigits: 2 })}`;
}
function fmtDateOnly(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
}

function fmtTimeOnly(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" });
}

function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  return d.toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
}

// ─── BADGE MAPS ───────────────────────────────────────────────────────────────

const statusDot = {
  Pending:   "bg-yellow-400",
  Approved:  "bg-green-500",
  Rejected:  "bg-red-500",
  Cancelled: "bg-gray-400",
  Paid:      "bg-green-500",
  Failed:    "bg-red-500",
  Refunded:  "bg-purple-500",
  Partial:      "bg-orange-400",
  Completed:    "bg-green-500",
  "For Refund": "bg-amber-500",
};
const statusBg = {
  Pending:   "bg-yellow-50 border border-yellow-200",
  Approved:  "bg-green-50 border border-green-200",
  Rejected:  "bg-red-50 border border-red-200",
  Cancelled: "bg-gray-100 border border-gray-200",
  Paid:      "bg-green-50 border border-green-200",
  Failed:    "bg-red-50 border border-red-200",
  Refunded:  "bg-purple-50 border border-purple-200",
  Partial:      "bg-orange-50 border border-orange-200",
  Completed:    "bg-green-50 border border-green-200",
  "For Refund": "bg-amber-50 border border-amber-200",
};
function StatusBadge({ status }) {
  const dot = statusDot[status] || "bg-gray-400";
  const bg  = statusBg[status]  || "bg-gray-50 border border-gray-200";
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full text-black ${bg}`}>
      <span className={`w-2 h-2 rounded-full shrink-0 ${dot}`} />
      {status}
    </span>
  );
}

const PAGE_SIZE = 15;
const STATUSES  = ["All", "Pending", "Partial", "Completed", "For Refund", "Refunded", "Cancelled", "Failed"];
const stageOf   = (p) => p.paymentStage || p.status;

const CHANNEL_LABEL = { gcash: "GCash", paymaya: "Maya", qrph: "QRPH" };
const channelOf = (p) => CHANNEL_LABEL[String(p.paymongoChannel || "").toLowerCase()] || p.paymongoChannel || p.paymentMethod;
const TIME_RANGES = ["All Time", "Today", "Last 7 Days", "This Month", "Custom Range"];

// ─── PAGINATION (same shared pattern as Bookings.jsx / Users.jsx) ─────────────
function usePagination(items, pageSize = PAGE_SIZE) {
  const [page, setPage] = useState(1);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  // Clamp if the list shrinks (filter/search/refresh) and we were on a now-empty page.
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;
  const pageItems = items.slice(start, start + pageSize);
  return { page: safePage, setPage, totalPages, pageItems, start, count: items.length };
}

function Pagination({ page, totalPages, onChange, start, pageSize, count }) {
  if (totalPages <= 1) return null;

  const nums = [];
  const add = (n) => nums.push(n);
  add(1);
  for (let n = page - 1; n <= page + 1; n++) if (n > 1 && n < totalPages) add(n);
  if (totalPages > 1) add(totalPages);
  const dedup = [...new Set(nums)].sort((a, b) => a - b);

  const rangeEnd = Math.min(start + pageSize, count);

  return (
    <div className="flex items-center justify-between px-5 py-3 border-t bg-gray-50/50">
      <p className="text-xs text-gray-400">
        Showing {count === 0 ? 0 : start + 1}–{rangeEnd} of {count}
      </p>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange(Math.max(1, page - 1))} disabled={page === 1}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Prev
        </button>
        {dedup.map((n, i) => (
          <span key={n} className="flex items-center">
            {i > 0 && n - dedup[i - 1] > 1 && <span className="px-1.5 text-gray-300 text-xs">…</span>}
            <button onClick={() => onChange(n)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                n === page ? "bg-teal-600 text-white shadow" : "border text-gray-600 hover:bg-white"
              }`}>
              {n}
            </button>
          </span>
        ))}
        <button onClick={() => onChange(Math.min(totalPages, page + 1))} disabled={page === totalPages}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Next
        </button>
      </div>
    </div>
  );
}

// Is createdAt (ISO string) within the selected time range?
function inTimeRange(iso, range, customFrom, customTo) {
  if (range === "All Time") return true;
  if (!iso) return false;
  const d = new Date(iso);
  if (isNaN(d)) return false;
  const now = new Date();

  if (range === "Today") {
    return d.toDateString() === now.toDateString();
  }
  if (range === "Last 7 Days") {
    const cutoff = new Date(now);
    cutoff.setDate(cutoff.getDate() - 7);
    return d >= cutoff && d <= now;
  }
  if (range === "This Month") {
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }
  if (range === "Custom Range") {
    if (!customFrom && !customTo) return true; // no bounds picked yet — don't filter anything out
    const from = customFrom ? new Date(`${customFrom}T00:00:00`) : null;
    const to   = customTo   ? new Date(`${customTo}T23:59:59`)   : null;
    if (from && d < from) return false;
    if (to   && d > to)   return false;
    return true;
  }
  return true;
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────

export default function Payments() {
  const [payments, setPayments]           = useState([]);
  const [loading, setLoading]             = useState(true);
  const [error, setError]                 = useState(null);
  const [search, setSearch]               = useState("");
  const [statusF, setStatusF]             = useState("All");
  const [methodF, setMethodF]             = useState("All");
  const [timeF, setTimeF]                 = useState("All Time");
  const [customFrom, setCustomFrom]       = useState("");
  const [customTo, setCustomTo]           = useState("");
  const [selected, setSelected]           = useState(null);
  const { effectiveRole } = useAuth();
  const canRecordInStore = [ROLES.OWNER, ROLES.ADMIN, ROLES.SUPERVISOR].includes(effectiveRole);
  const [detailLoading, setDetailLoading] = useState(false);
  const [toast, setToast]                 = useState(null);
  const [updating, setUpdating]           = useState(false);
  const [applyingDiscount, setApplyingDiscount] = useState(false);
  const [discountInput, setDiscountInput] = useState("");
  const [discountReasonInput, setDiscountReasonInput] = useState("");
  // The discount is given ONCE and can't be edited afterwards, so it goes through an "are you sure?" first.
  const [confirmDiscount, setConfirmDiscount] = useState(false);
  const [notifying, setNotifying] = useState(false);
  // In-store receipts (Supervisor / Admin / Owner): payment mode + reference number on record.
  const [inStoreOpen, setInStoreOpen] = useState(false);
  const [inStoreMethod, setInStoreMethod] = useState("Cash");
  const [inStoreRef, setInStoreRef] = useState("");
  const [savingInStore, setSavingInStore] = useState(false);
  const [refundMethod, setRefundMethod] = useState("Cash");
  const [refundRef, setRefundRef] = useState("");
  const [markingRefund, setMarkingRefund] = useState(false);
  const [detailTab, setDetailTab] = useState("summary");     // which tab of the payment modal is open
  const [entriesSummary, setEntriesSummary] = useState(null); // totals from All money movements (refunded amount etc.)
  const [sortKey, setSortKey]             = useState("submitted"); // default: newest submitted first
  const [sortDir, setSortDir]             = useState("desc");
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const token = localStorage.getItem("token");
  const currentUser = (() => {
    try { return JSON.parse(localStorage.getItem("user")); } catch { return null; }
  })();
  const receivedBy = currentUser?.name || currentUser?.username || currentUser?.email || "You";
  const { fmt: fmtCurrency } = useCurrency();

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  // `silent` skips the loading spinner — used by the live-refresh listener below
  // so a change from another admin (or a customer's payment/refund action)
  // doesn't flash the whole table blank.
  const fetchPayments = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/payments`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to load payments.");
      setPayments(data.data || []);
    } catch (e) { if (!silent) setError(e.message); }
    finally { if (!silent) setLoading(false); }
  }, [token]);

  useEffect(() => { fetchPayments(); }, [fetchPayments]);

  // ── Live refresh ────────────────────────────────────────────────────────────
  // Same approach as Bookings.jsx: the REST endpoint does the real work
  // (joins, formatting), so we just listen for any change to the payments
  // collection and re-run the existing fetch, debounced to coalesce bursts.
  // CHANGED: was onSnapshot(collection(db, "payments")) — a full-collection read
  // on every page open + every change. Now re-runs the API fetch every 45s
  // while the tab is visible.
  usePolling(() => fetchPayments(true), 45_000, { immediate: false });

  // Deep-link from other pages (e.g. Car Tracking's payment modal linking
  // here with ?bookingID=...) — pre-fill the search box so the relevant
  // payment is right there in the filtered table, and jump straight into
  // its detail panel if it's the only match.
  useEffect(() => {
    // ?paymentID= (e.g. from Refund Requests) is the precise link; ?bookingID=
    // is the looser one and can match more than one payment.
    const paymentID = searchParams.get("paymentID");
    const bookingID = searchParams.get("bookingID");
    const key = paymentID || bookingID;
    if (!key || payments.length === 0) return;
    setSearch(key);
    const matches = paymentID
      ? payments.filter((p) => p.paymentID === paymentID || p.id === paymentID)
      : payments.filter((p) => p.bookingID === bookingID);
    if (matches.length === 1) openDetail(matches[0].id);
    // The link has been used, so take it out of the URL (same as Bookings.jsx does with ?open=). Without this the
    // effect runs again every time `payments` changes -- the 45-second refresh, a status change, recording a payment
    // -- and re-opened the details no matter how the user closed them.
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.delete("paymentID");
      next.delete("bookingID");
      return next;
    }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payments, searchParams]);

  // Payment modal: Escape closes it (or the discount confirm on top of it first), and the page behind it
  // doesn't scroll. The receipt popup listens for Escape in the CAPTURE phase and stops the event, so while a
  // receipt is open Escape closes only the receipt -- this listener is deliberately the bubble-phase one.
  const modalOpen = !!(selected || detailLoading);
  useEffect(() => {
    if (!modalOpen) return undefined;
    const onKey = (e) => {
      if (e.key !== "Escape") return;
      if (confirmDiscount) setConfirmDiscount(false); else setSelected(null);
    };
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = prevOverflow; };
  }, [modalOpen, confirmDiscount]);

  const openDetail = async (id) => {
    setDetailLoading(true); setSelected(null); setEntriesSummary(null); setDetailTab("summary");
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setSelected(data.data);
      setDiscountInput("");
      setDiscountReasonInput("");
      setInStoreOpen(false); setInStoreMethod("Cash"); setInStoreRef("");
      setRefundMethod("Cash"); setRefundRef("");
    } catch (e) { showToast(e.message, "error"); }
    finally { setDetailLoading(false); }
  };

  const updateStatus = async (id, status) => {
    setUpdating(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/${id}/status`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      showToast(`Status updated to ${status}.`);
      setPayments((prev) => prev.map((p) => p.id === id ? { ...p, status } : p));
      setSelected((prev) => prev ? { ...prev, status } : prev);
    } catch (e) { showToast(e.message, "error"); }
    finally { setUpdating(false); }
  };

  // How much a discount can be at most: the remaining balance while the payment is partial,
  // otherwise what the customer has paid (capped at the total fee). The server enforces the same rule.
  const discountMax = (p) => (p.balance > 0 ? p.balance : Math.min(p.totalFee || 0, p.amountPaid || 0));

  // One discount per booking: no editing, no re-sending. Partial payment -> comes off the remaining
  // balance. Fully paid -> PayMongo refunds it. The drawer re-opens afterwards so the new balance and
  // the refund line show straight away.
  const submitDiscount = async () => {
    if (!selected) return;
    const amount = Number(discountInput);
    if (!Number.isFinite(amount) || amount <= 0) return;
    setApplyingDiscount(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/booking/${selected.bookingID}/discount`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ amount, reason: discountReasonInput.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      const how = data.data?.refundedVia;
      showToast(
        how === "paymongo" ? "Discount given — the refund was sent through PayMongo."
        : how === "in_store" ? "Discount given — return the amount in store, then record it here."
        : "Discount given — deducted from the remaining balance."
      );
      await openDetail(selected.id);
      await fetchPayments(true);
    } catch (e) { showToast(e.message, "error"); }
    finally { setApplyingDiscount(false); setConfirmDiscount(false); }
  };

  // Checks first, then asks "are you sure?" -- the discount can't be changed once it's given.
  const handleApplyDiscount = () => {
    if (!selected) return;
    const amount = Number(discountInput);
    if (!Number.isFinite(amount) || amount <= 0) return;
    const max = discountMax(selected);
    if (amount > max) {
      showToast(`The discount can't be more than ${peso(max, fmtCurrency)}.`, "error");
      return;
    }
    setConfirmDiscount(true);
  };

  // "Notify customer to pay": a bell notification AND an email asking them to pay the remaining balance online.
  // The server allows one reminder per booking every 6 hours.
  const handleNotifyBalance = async () => {
    if (!selected) return;
    setNotifying(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/booking/${selected.bookingID}/notify-balance`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      showToast(data?.data?.emailed
        ? "Customer notified by app and email."
        : `Customer notified in the app. ${data?.data?.emailNote || "The email was not sent."}`);
      await openDetail(selected.id);
    } catch (e) { showToast(e.message, "error"); }
    finally { setNotifying(false); }
  };

  // The exception: the customer pays the remaining balance IN STORE. Supervisor / Admin / Owner only,
  // with the payment mode and (for anything but cash) the reference number on record.
  const submitInStorePayment = async () => {
    if (!selected) return;
    if (inStoreMethod !== "Cash" && !inStoreRef.trim()) {
      showToast(`Enter the ${inStoreMethod} reference number.`, "error");
      return;
    }
    setSavingInStore(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/booking/${selected.bookingID}/collect-balance`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ paymentMethod: inStoreMethod, referenceNumber: inStoreRef.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      showToast("In-store payment recorded.");
      await openDetail(selected.id);
      await fetchPayments(true);
    } catch (e) { showToast(e.message, "error"); }
    finally { setSavingInStore(false); }
  };

  // Only for a refund that could NOT go through PayMongo (the money was received in store): record how it
  // was handed back. Supervisor / Admin / Owner only, same details as an in-store payment.
  const handleMarkRefundIssued = async () => {
    if (!selected) return;
    if (refundMethod !== "Cash" && !refundRef.trim()) {
      showToast(`Enter the ${refundMethod} reference number.`, "error");
      return;
    }
    setMarkingRefund(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payments/booking/${selected.bookingID}/refund-issued`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ paymentMethod: refundMethod, referenceNumber: refundRef.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      showToast("Refund recorded as returned.");
      await openDetail(selected.id);
      await fetchPayments(true);
    } catch (e) { showToast(e.message, "error"); }
    finally { setMarkingRefund(false); }
  };

  // ── filter ──
  const methods = ["All", ...new Set(payments.map((p) => p.paymentMethod).filter((m) => m && m !== "—"))];

  const filtered = payments.filter((p) => {
    const q = search.toLowerCase();
    const matchQ = !q || (p.paymentID || "").toLowerCase().includes(q)
      || (p.customerName || "").toLowerCase().includes(q)
      || (p.bookingID || "").toLowerCase().includes(q)
      || (p.vehicleName || "").toLowerCase().includes(q);
    const matchS = statusF === "All" || stageOf(p) === statusF;
    const matchM = methodF === "All" || p.paymentMethod === methodF;
    const matchT = inTimeRange(p.createdAt, timeF, customFrom, customTo);
    return matchQ && matchS && matchM && matchT;
  });

  // ── sort (numeric/date columns only — everything else stays in API/insertion order) ──
  const sorted = [...filtered].sort((a, b) => {
    if (!sortKey) return 0;
    let av, bv;
    if (sortKey === "totalFee") { av = a.totalFee ?? -Infinity; bv = b.totalFee ?? -Infinity; }
    else if (sortKey === "amountPaid") { av = a.amountPaid ?? -Infinity; bv = b.amountPaid ?? -Infinity; }
    else if (sortKey === "balance") { av = a.balance ?? -Infinity; bv = b.balance ?? -Infinity; }
    else if (sortKey === "discount") { av = a.discountAmount ?? 0; bv = b.discountAmount ?? 0; }
    else if (sortKey === "submitted") { av = a.createdAt ? new Date(a.createdAt).getTime() : -Infinity; bv = b.createdAt ? new Date(b.createdAt).getTime() : -Infinity; }
    else return 0;
    return sortDir === "asc" ? av - bv : bv - av;
  });

  const { page, setPage, totalPages, pageItems: paginated, start, count } = usePagination(sorted, PAGE_SIZE);
  useEffect(() => setPage(1), [search, statusF, methodF, timeF, customFrom, customTo]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── stat cards ──
  const totalCollected = payments.filter(p => ["Approved","Paid"].includes(p.status)).reduce((s,p) => s + p.amountPaid, 0);
  const completed = payments.filter(p => stageOf(p) === "Completed").length;
  const pending   = payments.filter(p => stageOf(p) === "Pending").length;
  // Nothing is owed on cancelled/rejected bookings, failed payments, or refunded ones.
  const totalBal  = payments.filter(p => !["Cancelled","Rejected","Failed","Refunded"].includes(p.status)).reduce((s,p) => s + p.balance, 0);

  return (
    <div className="w-full px-4 space-y-5">

      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"
        }`}>{toast.msg}</div>
      )}

      {/* Payment Details — centered modal laid out like Bookings' "Booking Details": title + status, who / what,
          tabs, a scrolling body and a pinned footer. Clicking the dimmed area or pressing Escape closes it.
          z-[60], not z-40: the app's top Header bar is z-50 (see Header.jsx), so z-40 let the navbar draw over
          the top of this modal. The confirm dialogs below use z-[70] for the same reason. */}
      {(selected || detailLoading) && (
        <div
          className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4"
          onClick={() => { if (!confirmDiscount) setSelected(null); }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="payment-detail-title"
            className="bg-white rounded-2xl shadow-xl w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {detailLoading ? (
              <div className="flex-1 flex items-center justify-center text-gray-400 text-sm py-20">Loading…</div>
            ) : selected && (
              <>
                {/* Header */}
                <div className="px-6 pt-5 shrink-0">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <h2 id="payment-detail-title" className="font-bold text-lg text-gray-800">Payment Details</h2>
                      <StatusBadge status={stageOf(selected)} />
                    </div>
                    <button onClick={() => setSelected(null)} aria-label="Close" className="text-gray-400 hover:text-gray-600 shrink-0">
                      <IconX className="w-5 h-5" />
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 mt-1 truncate">
                    {selected.customerName || "—"}{selected.vehicleName ? ` · ${selected.vehicleName}` : ""}
                  </p>
                  <p className="text-xs text-gray-400 mt-0.5 truncate">
                    <span className="font-mono">{selected.paymentID}</span>
                    {selected.methodOfPayment && selected.methodOfPayment !== "—" ? ` · ${selected.methodOfPayment}` : ""}
                    {` · Submitted ${fmtDate(selected.createdAt)}`}
                  </p>
                  <div className="flex border-b border-gray-100 mt-3" role="tablist">
                    {[
                      ["summary", "Summary"],
                      ["movements", `Money movements${entriesSummary?.count ? ` (${entriesSummary.count})` : ""}`],
                    ].map(([key, label]) => (
                      <button
                        key={key}
                        role="tab"
                        aria-selected={detailTab === key}
                        onClick={() => setDetailTab(key)}
                        className={`px-5 py-2.5 text-sm font-semibold border-b-2 -mb-px transition ${
                          detailTab === key ? "border-teal-600 text-teal-700" : "border-transparent text-gray-400 hover:text-gray-600"
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Body. Both tabs stay mounted (the inactive one is just hidden) so the money movements load once,
                    and the Refunded amount in the Fee Breakdown is ready before anyone opens that tab. */}
                <div className="flex-1 min-h-0 overflow-y-auto px-6 py-5">
                  <div className={detailTab === "summary" ? "" : "hidden"}>
                    {selected.status === "Pending" && (
                      <div className="flex items-center justify-between gap-4 pb-5">
                        <p className="text-sm text-gray-500">
                          Waiting for the customer to pay through PayMongo — it's marked as paid automatically the moment they do.
                        </p>
                        <button disabled={updating} onClick={() => updateStatus(selected.id, "Rejected")}
                          className="shrink-0 px-3 py-1.5 text-xs font-semibold bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50">
                          Reject
                        </button>
                      </div>
                    )}

                    {/* The three numbers staff look for first. */}
                    <div className="grid grid-cols-3 border-y border-gray-100 py-4 mb-5">
                      <KeyFigure label="Total fee" value={peso(selected.totalFee, fmtCurrency)} />
                      <KeyFigure label="Amount paid" value={peso(selected.amountPaid, fmtCurrency)} />
                      <KeyFigure
                        label="Balance"
                        value={peso(selected.balance, fmtCurrency)}
                        color={selected.balance > 0 ? "text-red-500" : "text-green-600"}
                        note={
                          selected.balance > 0
                            ? `Remaining${selected.balanceStatus === "pending" ? " · payment in progress" : ""}`
                            : ["Cancelled", "Refunded", "Failed"].includes(stageOf(selected)) ? "No balance due" : "Fully paid"
                        }
                      />
                    </div>

                    {selected.heldAfterCancel && (
                      <p className="mb-5 rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-700">
                        This booking was cancelled but {peso(selected.amountPaid, fmtCurrency)} the customer paid is still being held and no refund has been opened. Ask the customer to request one, or arrange the return.
                      </p>
                    )}

                    {/* The sections sit in their own wrapper so the first one has no hairline of its own
                        (the figures above already end in one). */}
                    <div>
                      <Section
                        title="Customer"
                        action={selected.bookingID && selected.bookingID !== "—" ? (
                          <button
                            type="button"
                            onClick={() => navigate(`/bookings?search=${encodeURIComponent(selected.bookingID)}`)}
                            className="text-xs font-semibold text-teal-700 hover:underline"
                          >
                            View booking →
                          </button>
                        ) : null}
                      >
                        <Row label="Name" value={selected.customerName} />
                        <Row label="Booking ID" value={selected.bookingID} mono />
                        <Row label="Vehicle" value={selected.vehicleName} />
                        <Row
                          label="Balance"
                          hint="What the customer still has to pay. A discount on a partial payment comes off this amount."
                          value={peso(selected.balance, fmtCurrency)}
                          bold
                          color={selected.balance > 0 ? "text-red-500" : "text-green-600"}
                        />

                        {/* Still owed: the customer pays it online; this nudges them. In store is the exception. */}
                        {selected.balance > 0 && selected.status === "Approved" && !selected.refundRequestID && selected.balanceStatus !== "pending" && (
                          <div className="pt-3 space-y-2.5">
                            <p className="text-xs text-gray-500">
                              The remaining {peso(selected.balance, fmtCurrency)} is paid online through PayMongo from the customer's booking.
                            </p>
                            <div className="flex flex-wrap gap-2">
                              <button onClick={handleNotifyBalance} disabled={notifying}
                                className="px-4 py-2 text-sm font-semibold rounded-xl border border-teal-200 bg-teal-50 text-teal-700 hover:bg-teal-100 transition disabled:opacity-50">
                                {notifying ? "Sending…" : "Notify customer to pay"}
                              </button>
                              {canRecordInStore && !inStoreOpen && (
                                <button onClick={() => setInStoreOpen(true)}
                                  className="px-4 py-2 text-sm font-semibold rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition">
                                  Record in-store payment
                                </button>
                              )}
                            </div>
                            {selected.balanceReminderAt && (
                              <p className="text-[11px] text-gray-400">Last reminded {fmtDate(selected.balanceReminderAt)}.</p>
                            )}
                            {inStoreOpen && canRecordInStore && (
                              <InStoreForm
                                amountLabel={peso(selected.balance, fmtCurrency)}
                                method={inStoreMethod} setMethod={setInStoreMethod}
                                reference={inStoreRef} setReference={setInStoreRef}
                                receivedByLabel="Received by" receivedBy={receivedBy}
                                onSubmit={submitInStorePayment} onCancel={() => setInStoreOpen(false)}
                                saving={savingInStore} submitLabel="Record payment"
                              />
                            )}
                          </div>
                        )}
                        {selected.balanceStatus === "pending" && selected.balance > 0 && (
                          <p className="text-xs text-amber-600 pt-2">The customer has a balance payment in progress on PayMongo — it will show as paid once it clears.</p>
                        )}
                      </Section>

                      {/* What the booking cost, what was paid, and what happened to the deposit / discount / refund. */}
                      <Section title="Fee Breakdown">
                        <Row label="Rental Fee" value={peso(selected.rentalFee, fmtCurrency)} />
                        <Row label="Extra Fee" value={peso(selected.extraFee, fmtCurrency)} />
                        {selected.driversFee > 0 && <Row label="Driver's Fee" value={peso(selected.driversFee, fmtCurrency)} />}
                        <Row label={selected.serviceFeeRate > 0 ? `Service Fee (${selected.serviceFeeRate}% of rental)` : "Service Fee"} value={peso(selected.serviceFee, fmtCurrency)} />
                        {selected.gatewayFee > 0 && <Row label={selected.gatewayFeeRate > 0 ? `Gateway Fee (${selected.gatewayFeeRate}% of ${peso(selected.gatewayFeeBase, fmtCurrency)})` : "Gateway Fee"} value={peso(selected.gatewayFee, fmtCurrency)} />}
                        {selected.securityDeposit > 0 && <Row label="Security Deposit (refundable)" value={peso(selected.securityDeposit, fmtCurrency)} />}
                        <div className="border-t border-gray-100 mt-2 pt-2">
                          <Row label="Total Fee" value={peso(selected.totalFee, fmtCurrency)} bold />
                          {selected.discountAmount > 0 ? (
                            <>
                              <Row label="Discount Given" value={`−${peso(selected.discountAmount, fmtCurrency)}`} bold color="text-red-500" />
                              {selected.discountReason && <Row label="Discount Reason" value={selected.discountReason} />}
                              {selected.discountAt && <Row label="Discount Given On" value={`${fmtDate(selected.discountAt)}${selected.discountBy ? ` · ${selected.discountBy}` : ""}`} />}
                            </>
                          ) : (
                            <Row label="Discount Given" value={peso(0, fmtCurrency)} color="text-gray-400" />
                          )}
                          <Row label="Amount Paid" value={peso(selected.amountPaid, fmtCurrency)} bold />
                        </div>
                        {(selected.securityDeposit > 0 && (selected.depositSettled > 0 || selected.depositReturned > 0)) && (
                          <div className="border-t border-gray-100 mt-2 pt-2">
                            {selected.depositSettled > 0 && <Row label="Deposit Settled (used for penalties)" value={peso(selected.depositSettled, fmtCurrency)} />}
                            {selected.depositReturned > 0 && <Row label="Deposit Returned" value={peso(selected.depositReturned, fmtCurrency)} />}
                          </div>
                        )}
                        {entriesSummary && entriesSummary.refundedOut > 0 && (
                          <div className="border-t border-gray-100 mt-2 pt-2">
                            <Row label="Refunded Amount" value={`−${peso(entriesSummary.refundedOut, fmtCurrency)}`} bold color="text-purple-700" />
                          </div>
                        )}
                      </Section>

                      {/* The gateway fee the customer paid us vs. what PayMongo kept, one line per online charge. */}
                      <GatewayBreakdown payment={selected} fmt={fmtCurrency} />

                      {/* Every penalty charged on this booking: charged, paid, waived. Waived / voided ones are listed
                          but never counted toward what is owed, and never touch the booking's balance or discount. */}
                      <PenaltyBreakdown penalties={selected.penalties} payment={selected} fmt={fmtCurrency} />

                      {selected.refundDue > 0 && (
                        <Section title="Refund Due to Customer (in store)">
                          <div className="rounded-xl border border-red-200 bg-red-50 p-4 space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="font-semibold text-red-700">Amount owed back</span>
                              <span className="font-bold text-red-700">{peso(selected.refundDue, fmtCurrency)}</span>
                            </div>
                            <p className="text-xs text-red-600">
                              A discount was given on money the customer paid in store, so it can't go back through PayMongo.
                              Return it in store, then record how it was returned.
                            </p>
                            {canRecordInStore ? (
                              <InStoreForm
                                amountLabel={peso(selected.refundDue, fmtCurrency)}
                                method={refundMethod} setMethod={setRefundMethod}
                                reference={refundRef} setReference={setRefundRef}
                                receivedByLabel="Returned by" receivedBy={receivedBy}
                                onSubmit={handleMarkRefundIssued}
                                saving={markingRefund} submitLabel={`Record ${peso(selected.refundDue, fmtCurrency)} as returned`}
                              />
                            ) : (
                              <p className="text-xs text-gray-500">Only a Supervisor, Admin or Owner can record this.</p>
                            )}
                          </div>
                        </Section>
                      )}
                    </div>
                  </div>

                  {/* Every money movement on this payment (deposit, balance, penalties, refunds, deposit returned,
                      pending / failed attempts) as a plain list, newest first, each with its own receipt. */}
                  <div className={detailTab === "movements" ? "" : "hidden"}>
                    <PaymentEntriesPanel
                      key={`${selected.paymentID}-${selected.status}-${selected.amountPaid}-${selected.refundIssued}`}
                      query={{ paymentID: selected.paymentID || selected.id }}
                      title="All money movements"
                      hideSummary
                      onLoaded={setEntriesSummary}
                    />
                  </div>
                </div>

                {/* sticky footer: Give Discount + Close stay put while the rest scrolls */}
                <div className="shrink-0 border-t bg-white px-6 py-4 rounded-b-2xl space-y-3">
                  {(() => {
                    const canGiveDiscount =
                      !(selected.discountAmount > 0) && selected.status === "Approved" && !selected.refundRequestID &&
                      !["For Refund", "Refunded", "Cancelled"].includes(stageOf(selected));
                    if (selected.refundRequestID) {
                      return (
                        <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 flex items-center justify-between gap-3">
                          <p className="text-xs text-amber-800">
                            A refund request ({selected.refundRequestStatus}) is open for this payment — manage it on the Refund Requests page.
                          </p>
                          <button
                            type="button"
                            onClick={() => navigate(`/refund-requests?search=${encodeURIComponent(selected.refundRequestID || selected.paymentID)}`)}
                            className="shrink-0 px-3 py-1.5 text-xs font-semibold text-amber-800 bg-white border border-amber-300 rounded-lg hover:bg-amber-100 transition-colors whitespace-nowrap"
                          >
                            View refund request →
                          </button>
                        </div>
                      );
                    }
                    if (!canGiveDiscount) return null;
                    return (
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Give Discount</p>
                        <div className="flex items-center gap-2">
                          <div className="relative w-28 shrink-0">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">₱</span>
                            <input
                              type="number" min="1" max={discountMax(selected)} step="1" placeholder="0"
                              value={discountInput}
                              onChange={(e) => setDiscountInput(e.target.value)}
                              className="w-full pl-7 pr-2 py-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-arl-light"
                            />
                          </div>
                          <input
                            type="text" placeholder="Reason (optional)"
                            value={discountReasonInput}
                            onChange={(e) => setDiscountReasonInput(e.target.value)}
                            className="flex-1 min-w-0 px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-arl-light"
                          />
                          <button
                            onClick={handleApplyDiscount}
                            disabled={applyingDiscount || !(Number(discountInput) > 0) || Number(discountInput) > discountMax(selected)}
                            className="px-4 py-2 text-sm font-semibold rounded-xl border border-arl-dark text-arl-dark hover:bg-gray-50 transition disabled:opacity-50 whitespace-nowrap"
                          >
                            Give discount
                          </button>
                        </div>
                        {Number(discountInput) > discountMax(selected) ? (
                          <p className="text-xs text-red-500">The discount can't be more than {peso(discountMax(selected), fmtCurrency)}.</p>
                        ) : (
                          <p className="text-[11px] text-gray-400">
                            {selected.balance > 0
                              ? `Comes off the remaining balance (up to ${peso(selected.balance, fmtCurrency)}).`
                              : `Payment is complete, so PayMongo refunds it to the customer (up to ${peso(discountMax(selected), fmtCurrency)}).`}
                            {" "}One discount only — you'll confirm first.
                          </p>
                        )}
                      </div>
                    );
                  })()}
                  <button onClick={() => setSelected(null)} className="w-full py-2 border rounded-xl text-sm hover:bg-gray-50">Close</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Confirm the one-time discount. There is no editing or re-sending afterwards, and on a fully paid
          booking the refund goes out through PayMongo straight away, so this restates exactly what will happen. */}
      {confirmDiscount && selected && (
        <div className="fixed inset-0 z-[70] bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div>
              <h3 className="font-bold text-arl-dark text-lg">Give this discount?</h3>
              <p className="text-sm text-gray-600 mt-2">
                {selected.balance > 0 ? (
                  <>
                    <span className="font-semibold">{peso(Number(discountInput) || 0, fmtCurrency)}</span> will be deducted from the remaining balance
                    ({peso(selected.balance, fmtCurrency)} → {peso(Math.max(0, selected.balance - (Number(discountInput) || 0)), fmtCurrency)}).
                  </>
                ) : (
                  <>
                    <span className="font-semibold">{peso(Number(discountInput) || 0, fmtCurrency)}</span> will be refunded to the customer through PayMongo.
                  </>
                )}
              </p>
              <p className="text-xs text-red-500 mt-2">A discount can only be given once. After you confirm, it can't be edited, corrected or given again.</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setConfirmDiscount(false)} disabled={applyingDiscount}
                className="flex-1 px-4 py-2 border rounded-xl text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50">
                Cancel
              </button>
              <button onClick={submitDiscount} disabled={applyingDiscount}
                className="flex-1 px-4 py-2 bg-arl-dark text-white rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50">
                {applyingDiscount ? "Saving…" : `Yes, give ${peso(Number(discountInput) || 0, fmtCurrency)}`}
              </button>
            </div>
          </div>
        </div>
      )}


      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard icon={<IconMoney      className="w-5 h-5" />} value={peso(totalCollected, fmtCurrency)} label="Total Collected"    color="teal" />
        <StatCard icon={<IconCheck      className="w-5 h-5" />} value={completed}            label="Fully Paid"         color="green"
          active={statusF === "Completed"}
          onClick={() => setStatusF(statusF === "Completed" ? "All" : "Completed")} />
        <StatCard icon={<IconClock      className="w-5 h-5" />} value={pending}              label="Awaiting Payment"   color="yellow"
          active={statusF === "Pending"}
          onClick={() => setStatusF(statusF === "Pending" ? "All" : "Pending")} />
        <StatCard icon={<IconCreditCard className="w-5 h-5" />} value={peso(totalBal, fmtCurrency)} label="Total Balance Due"  color="purple" />
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl shadow-soft flex flex-wrap gap-3 items-center">
        <input type="text" placeholder="Search by customer, ref, booking…"
          value={search} onChange={(e) => setSearch(e.target.value)}
          className="flex-1 min-w-[180px] px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-arl-light" />
        <div className="relative">
          <select value={statusF} onChange={(e) => setStatusF(e.target.value)}
            className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-xl text-sm bg-white">
            {STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
          <IconChevronDown className="w-4 h-4 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
        <div className="relative">
          <select value={methodF} onChange={(e) => setMethodF(e.target.value)}
            className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-xl text-sm bg-white">
            {methods.map((m) => <option key={m}>{m}</option>)}
          </select>
          <IconChevronDown className="w-4 h-4 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
        <div className="relative">
          <select value={timeF} onChange={(e) => setTimeF(e.target.value)}
            className="appearance-none pl-3 pr-8 py-2 border border-gray-200 rounded-xl text-sm bg-white">
            {TIME_RANGES.map((t) => <option key={t}>{t}</option>)}
          </select>
          <IconChevronDown className="w-4 h-4 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
        {timeF === "Custom Range" && (
          <div className="flex items-center gap-1.5">
            <input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)}
              max={customTo || undefined}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white" />
            <span className="text-gray-400 text-xs">to</span>
            <input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)}
              min={customFrom || undefined}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white" />
          </div>
        )}
        <button onClick={fetchPayments} disabled={loading}
          className="px-4 py-2 text-sm rounded-xl bg-arl-dark text-white hover:opacity-90 disabled:opacity-50">
          {loading ? "…" : "Refresh"}
        </button>
      </div>

      {/* Error */}
      {error && <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>}

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-soft border border-gray-100">
        <div className="flex justify-between items-center px-5 py-4 border-b border-gray-100">
          <h2 className="font-bold text-arl-dark">
            All Payment Records{" "}
            <span className="text-gray-400 text-sm font-normal">({filtered.length} results)</span>
          </h2>
        </div>
        <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[800px]">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <SortableTh label="Submitted Date" sortKey="submitted" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Submitted Time</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Customer</th>
              <SortableTh label="Total Fee" sortKey="totalFee" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Payment Type</th>
              <SortableTh label="Discount" sortKey="discount" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
              <SortableTh label="Amount Paid" sortKey="amountPaid" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
              <SortableTh label="Balance" sortKey="balance" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Method</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider"></th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={i} className="border-b border-gray-50">
                  {Array.from({ length: 10 }).map((_, j) => (
                    <td key={j} className="px-4 py-4"><div className="h-3 bg-gray-100 rounded animate-pulse w-3/4" /></td>
                  ))}
                </tr>
              ))
            ) : paginated.length === 0 ? (
              <tr><td colSpan={10} className="text-center py-16 text-gray-400 text-sm">
                {search || statusF !== "All" || methodF !== "All" || timeF !== "All Time" ? "No payments match your filters." : "No payments found."}
              </td></tr>
            ) : paginated.map((p, i) => (
              <tr key={p.id} className={`border-b border-gray-50 last:border-0 hover:bg-arl-light/30 transition-colors ${i % 2 === 1 ? "bg-gray-50/30" : ""}`}>
                <td className="px-4 py-3 text-xs text-gray-700 whitespace-nowrap">{fmtDateOnly(p.createdAt)}</td>
                <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{fmtTimeOnly(p.createdAt)}</td>
                <td className="px-4 py-3">
                  <div className="font-semibold text-gray-800 text-xs">{p.customerName}</div>
                </td>
                <td className="px-4 py-3 text-xs font-semibold text-gray-800">{peso(p.totalFee, fmtCurrency)}</td>
                <td className="px-4 py-3">
                  {p.methodOfPayment && p.methodOfPayment !== "—" ? (
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      p.methodOfPayment.toLowerCase().includes("full")
                        ? "bg-blue-100 text-blue-700"
                        : p.methodOfPayment.toLowerCase().includes("down")
                        ? "bg-purple-100 text-purple-700"
                        : "bg-orange-100 text-orange-700"
                    }`}>{p.methodOfPayment}</span>
                  ) : (
                    <span className="text-gray-300 text-xs">—</span>
                  )}
                </td>
                <td className="px-4 py-3 text-xs font-semibold">
                  {p.discountAmount > 0
                    ? <span className="text-red-500">−{peso(p.discountAmount, fmtCurrency)}</span>
                    : <span className="text-gray-300">—</span>}
                </td>
                <td className="px-4 py-3 text-xs font-semibold text-gray-800">{peso(p.amountPaid, fmtCurrency)}</td>
                <td className={`px-4 py-3 text-xs font-semibold ${p.balance > 0 ? "text-red-500" : "text-green-600"}`}>
                  {peso(p.balance, fmtCurrency)}
                </td>
                <td className="px-4 py-3 text-xs text-gray-600">{channelOf(p)}</td>
                <td className="px-4 py-3"><StatusBadge status={stageOf(p)} /></td>
                <td className="px-4 py-3">
                  <button onClick={() => openDetail(p.id)}
                    className="px-3 py-1 border rounded-lg text-xs hover:bg-gray-50">View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
        <Pagination page={page} totalPages={totalPages} onChange={setPage} start={start} pageSize={PAGE_SIZE} count={count} />
      </div>
    </div>
  );
}

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────

// Optional onClick makes the card a filter shortcut (used for Approved / Awaiting
// Review on this page). `active` highlights it while its filter is applied;
// clicking it again clears the filter back to "All".
function StatCard({ icon, value, label, color, onClick, active }) {
  const bgColors = {
    teal:   "bg-teal-50 text-teal-600",
    green:  "bg-green-50 text-green-600",
    yellow: "bg-yellow-50 text-yellow-600",
    purple: "bg-purple-50 text-purple-600",
  };
  const body = (
    <>
      <div className={`w-11 h-11 flex items-center justify-center rounded-xl ${bgColors[color] || "bg-gray-100 text-gray-600"}`}>
        {icon}
      </div>
      <div>
        <div className="text-xl font-bold text-arl-dark">{value}</div>
        <div className="text-xs text-gray-500">{label}</div>
      </div>
    </>
  );

  if (!onClick) {
    return <div className="bg-white rounded-2xl shadow-soft p-4 flex items-center gap-4">{body}</div>;
  }

  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={!!active}
      title={active ? "Click to clear this filter" : `Filter by ${label}`}
      className={`bg-white rounded-2xl shadow-soft p-4 flex items-center gap-4 text-left w-full transition-shadow hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-arl-light ${active ? "ring-2 ring-arl-light" : ""}`}
    >
      {body}
    </button>
  );
}

// A flat block of the detail modal: a heading, then its rows, separated from the previous block by a hairline
// (no grey boxes). `action` is an optional link / button shown at the right of the heading.
function Section({ title, action = null, children }) {
  return (
    <section className="py-5 border-t border-gray-100 first:border-t-0 first:pt-0">
      <div className="flex items-center justify-between gap-3 mb-1.5">
        <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
        {action}
      </div>
      <div>{children}</div>
    </section>
  );
}

// `hint` (a short description of the row, e.g. how a figure was worked out) is hidden until the small "?" circle
// beside the label is clicked, so the rows stay clean. Every row with a hint gets the same button.
function Row({ label, hint, value, mono, bold, color }) {
  const [showHint, setShowHint] = useState(false);
  return (
    <div className="py-1.5">
      <div className="flex justify-between items-start gap-4">
        <div className="min-w-0 shrink-0 max-w-[65%] flex items-center gap-1.5">
          <span className="text-sm text-gray-500">{label}</span>
          {hint && (
            <button
              type="button"
              onClick={() => setShowHint((v) => !v)}
              aria-expanded={showHint}
              aria-label="What is this?"
              title={showHint ? "Hide description" : "What is this?"}
              className={`w-4 h-4 shrink-0 rounded-full border text-[10px] leading-none font-semibold flex items-center justify-center transition-colors ${
                showHint ? "border-teal-600 bg-teal-50 text-teal-700" : "border-gray-300 text-gray-400 hover:border-gray-500 hover:text-gray-600"
              }`}
            >
              ?
            </button>
          )}
        </div>
        <span className={`text-sm text-right break-all ${mono ? "font-mono" : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-800"}`}>
          {value ?? "—"}
        </span>
      </div>
      {hint && showHint && <p className="text-xs text-gray-400 mt-1 pr-8">{hint}</p>}
    </div>
  );
}

// One of the three headline numbers at the top of the Summary tab.
function KeyFigure({ label, value, note, color }) {
  return (
    <div className="px-4 first:pl-0 last:pr-0 border-l border-gray-100 first:border-l-0 min-w-0">
      <p className="text-xs text-gray-500">{label}</p>
      <p className={`text-lg font-bold truncate ${color || "text-gray-800"}`}>{value}</p>
      {note && <p className="text-xs text-gray-400 truncate">{note}</p>}
    </div>
  );
}

// ─── Gateway breakdown ───────────────────────────────────────────────────────
// Two different things are called "gateway fee" here, so they are shown side by side:
//   received  = the gateway fee the CUSTOMER paid us (payments.gatewayFee, set at booking time)
//   PayMongo  = what PayMongo itself kept, one fee per online charge (deposit, balance), read from the
//               payment's paymentEntries rows (transactionFee)
//   total     = all PayMongo fees added up
//   sale      = received − total: what is left of the gateway fee after PayMongo took its cut
//               (negative = the business absorbed the difference)
// Penalties paid online count too (p.penaltyGateway): the customer pays the same gateway % on top of the penalty, so
// that fee is part of "received", and what PayMongo kept on those charges is one more line in the box.
const PHASE_NAME = { deposit: "Deposit", balance: "Balance", penalty: "Penalties" };

const round2 = (n) => Math.round(n * 100) / 100;
const signed = (n, fmtFn) => (n < 0 ? `−${peso(Math.abs(n), fmtFn)}` : peso(n, fmtFn));

function buildGatewayBreakdown(p) {
  const pg = p.penaltyGateway || null;
  const bookingReceived = Number(p.gatewayFee) || 0;
  const penaltyReceived = pg ? Number(pg.received) || 0 : 0;
  const received = round2(bookingReceived + penaltyReceived);
  const tx = Array.isArray(p.paymongoTransactions) ? p.paymongoTransactions : [];
  const fees = [];
  ["deposit", "balance"].forEach((phase) => {
    // A charge paid IN STORE never goes through PayMongo, so PayMongo kept nothing: listed at ₱0.00 so it is
    // visible here (with its method and reference) instead of looking like a missing record.
    const inStoreTx = tx.find((x) => x.phase === phase && x.source === "in_person" && x.status === "Paid");
    if (inStoreTx) {
      fees.push({
        phase, inStore: true, amount: 0,
        channel: inStoreTx.channel || null,
        charged: inStoreTx.amount != null ? Number(inStoreTx.amount) : null,
        ref: inStoreTx.ref || null,
      });
      return;
    }
    const raw = p.paymongoFee ? p.paymongoFee[phase] : null;
    if (raw === null || raw === undefined) return;          // no fee recorded for this charge
    const t = tx.find((x) => x.phase === phase && x.source === "online") || {};
    const channelRaw = t.channel || p.paymongoChannel || "";
    fees.push({
      phase,
      amount: Number(raw) || 0,
      channel: CHANNEL_LABEL[String(channelRaw).toLowerCase()] || channelRaw || null,
      charged: t.amount != null ? Number(t.amount) : null,   // what that online charge was for
    });
  });
  // The total only counts PayMongo's real fees (in-store rows are ₱0 and must not make "no fee recorded" look like ₱0).
  const onlineFees = fees.filter((f) => !f.inStore);
  const storedTotal = p.paymongoFee ? p.paymongoFee.total : null;
  const bookingTotal = storedTotal !== null && storedTotal !== undefined
    ? Number(storedTotal) || 0
    : onlineFees.length ? round2(onlineFees.reduce((s, f) => s + f.amount, 0)) : null;

  // Penalties paid online: what PayMongo kept on them is its own line, and it is added to the total.
  // (null = PayMongo's fee wasn't recorded for them, so no line and nothing added.)
  const penaltyFee = pg && pg.paymongoFee !== null && pg.paymongoFee !== undefined ? Number(pg.paymongoFee) || 0 : null;
  if (penaltyFee !== null) {
    fees.push({ phase: "penalty", amount: penaltyFee, channel: null, charged: pg.charged != null ? Number(pg.charged) : null });
  }
  const total = penaltyFee === null ? bookingTotal : round2((bookingTotal || 0) + penaltyFee);

  return {
    received,
    bookingReceived,
    penaltyReceived,
    rate: Number(p.gatewayFeeRate) || 0,
    base: Number(p.gatewayFeeBase) || 0,
    fees,
    total,
    sale: total === null ? null : round2(received - total),
    show: received > 0 || total !== null || fees.length > 0,
  };
}

function GatewayBreakdown({ payment, fmt }) {
  const g = buildGatewayBreakdown(payment);
  if (!g.show) return null;
  const saleColor = g.sale === null ? "" : g.sale >= 0 ? "text-green-600" : "text-red-500";
  return (
    <Section title="Gateway Breakdown">
      {/* What the customer paid us for the gateway (green: money in). */}
      <Row
        label="Gateway received"
        hint={[
          g.rate > 0 ? `${g.rate}% of ${peso(g.base, fmt)}, paid by the customer` : "Gateway fee the customer paid",
          g.penaltyReceived > 0 ? `includes ${peso(g.penaltyReceived, fmt)} paid on penalties` : null,
        ].filter(Boolean).join(" · ")}
        value={peso(g.received, fmt)}
        bold
        color="text-green-600"
      />

      {/* What PayMongo kept, grouped in one box: one line per payment, then the total (reddish: money out). */}
      {(g.fees.length > 0 || g.total !== null) && (
        <div className="my-2 rounded-xl border border-red-100 bg-red-50/40 px-4 py-1.5">
          {g.fees.map((f, i) => (
            <Row
              key={f.phase}
              label={`Payment ${i + 1} · ${PHASE_NAME[f.phase]}${f.inStore ? " (in store)" : ""}`}
              hint={f.inStore
                ? ["Paid in store, so PayMongo charged no fee", f.channel, f.charged != null ? `received ${peso(f.charged, fmt)}` : null, f.ref ? `ref ${f.ref}` : null].filter(Boolean).join(" · ")
                : ([f.channel, f.charged != null ? `charged ${peso(f.charged, fmt)}` : null].filter(Boolean).join(" · ") || null)}
              value={peso(f.amount, fmt)}
              color={f.inStore ? "text-gray-400" : "text-red-400"}
            />
          ))}
          {g.total !== null && (
            <div className={g.fees.length > 0 ? "border-t border-red-100 mt-1 pt-1" : ""}>
              <Row label="Gateway total" hint="All PayMongo fees added up" value={peso(g.total, fmt)} bold color="text-red-600" />
            </div>
          )}
        </div>
      )}

      {/* Outside the box: what is left of the gateway fee after PayMongo's cut (green; red if PayMongo cost more). */}
      {g.total !== null ? (
        <Row label="Gateway sale" hint="Gateway received minus gateway total" value={signed(g.sale, fmt)} bold color={saleColor} />
      ) : (
        <p className="text-xs text-gray-400 pt-2">
          PayMongo's own fee isn't recorded for this payment (cash payment, or paid before fee tracking started).
        </p>
      )}
    </Section>
  );
}

// ─── Penalty breakdown ───────────────────────────────────────────────────────
//   charged     = confirmed penalties only (waived / voided ones were never owed)
//   paid        = what has been paid toward them (deposit offset, in store or online)
//   outstanding = charged − paid
//   waived      = forgiven penalties, shown for the record; separate from "Discount Given" on purpose, because a
//                 waived penalty never touched this payment's balance (a discount does)
function penaltyState(p) {
  if (p.status === "Waived") return { label: "Waived", color: "text-amber-600" };
  if (p.status === "Voided") return { label: "Voided", color: "text-gray-400" };
  if (p.paidAmount >= p.amount && p.amount > 0) return { label: "Paid", color: "text-green-600" };
  if (p.paidAmount > 0) return { label: "Partially paid", color: "text-orange-500" };
  return { label: "Unpaid", color: "text-red-500" };
}

function PenaltyBreakdown({ penalties, payment, fmt }) {
  const list = Array.isArray(penalties) ? penalties : [];
  const hasDeposit = Number(payment?.securityDeposit) > 0;
  const live = list.filter((p) => p.status === "Confirmed");
  const charged = round2(live.reduce((n, p) => n + p.amount, 0));
  const paid = round2(live.reduce((n, p) => n + Math.min(p.paidAmount, p.amount), 0));
  const outstanding = round2(Math.max(0, charged - paid));
  const waived = round2(list.filter((p) => p.status === "Waived").reduce((n, p) => n + p.amount, 0));
  const voided = round2(list.filter((p) => p.status === "Voided").reduce((n, p) => n + p.amount, 0));
  return (
    <Section title="Penalty Breakdown">
      {list.length === 0 && <p className="text-xs text-gray-400 py-1.5">No penalties have been charged on this booking.</p>}
      {list.map((p, i) => {
        const st = penaltyState(p);
        const gone = p.status !== "Confirmed";
        return (
          <Row
            key={p.penaltyID}
            label={<><span className="text-gray-400 mr-1.5">{i + 1}</span>{p.description} · <span className={st.color}>{st.label}</span></>}
            hint={gone
              ? `${p.status} on ${fmtDate(p.createdAt)}${p.statusReason ? ` — ${p.statusReason}` : ""}. Not counted as owed.`
              : `Charged ${fmtDate(p.createdAt)}${p.paidAmount > 0 ? ` · ${peso(Math.min(p.paidAmount, p.amount), fmt)} paid so far` : ""}`}
            value={peso(p.amount, fmt)}
            color={gone ? "text-gray-400 line-through" : undefined}
          />
        );
      })}
      <div className="border-t border-gray-100 mt-2 pt-2">
        <Row label="Total charged" hint="Confirmed penalties only. Waived and voided ones are not included." value={peso(charged, fmt)} bold />
        <Row label="Paid" hint="Covered by the held deposit, paid in store, or paid online." value={peso(paid, fmt)} />
        <Row label="Outstanding" hint="Total charged minus paid: what the customer still owes for penalties." value={peso(outstanding, fmt)} bold color={outstanding > 0 ? "text-red-500" : "text-green-600"} />
        <Row
          label="Penalties waived"
          hint="Forgiven by staff. Shown for the record; it does not change the booking's balance or discount."
          value={waived > 0 ? `−${peso(waived, fmt)}` : peso(0, fmt)}
          color={waived > 0 ? "text-amber-600" : "text-gray-400"}
        />
        {voided > 0 && <Row label="Penalties voided" hint="Removed as a mistake. Not counted as owed." value={`−${peso(voided, fmt)}`} color="text-gray-400" />}
        {hasDeposit && (
          <>
            <Row
              label="Deposit settled"
              hint="Part of the security deposit used to pay penalties when the booking was settled."
              value={peso(Number(payment.depositSettled) || 0, fmt)}
              bold={Number(payment.depositSettled) > 0}
              color={Number(payment.depositSettled) > 0 ? undefined : "text-gray-400"}
            />
            {(Number(payment.depositReturned) > 0 || payment.depositStatus === "Settled") && (
              <Row label="Deposit returned" hint="What was left of the deposit and went back to the customer." value={peso(Number(payment.depositReturned) || 0, fmt)} />
            )}
          </>
        )}
      </div>
    </Section>
  );
}

// ─── In-store record form ────────────────────────────────────────────────────
// Used for an in-store payment and for returning a refund in store: payment mode,
// reference number (required for anything but cash) and who handled it.
const IN_STORE_METHODS = ["Cash", "GCash", "Bank Transfer"];

function InStoreForm({ amountLabel, method, setMethod, reference, setReference, receivedByLabel, receivedBy, onSubmit, onCancel, saving, submitLabel }) {
  const needsRef = method !== "Cash";
  return (
    <div className="rounded-xl border border-gray-200 bg-gray-50 p-4 space-y-3">
      <Row label="Amount" value={amountLabel} bold />
      <label className="block">
        <span className="text-xs font-semibold text-gray-500">Payment mode</span>
        <select
          value={method}
          onChange={(e) => setMethod(e.target.value)}
          className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-arl-light"
        >
          {IN_STORE_METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
      </label>
      <label className="block">
        <span className="text-xs font-semibold text-gray-500">{needsRef ? "Reference number (required)" : "Official receipt no. (optional)"}</span>
        <input
          type="text" maxLength={64}
          value={reference}
          onChange={(e) => setReference(e.target.value)}
          placeholder={needsRef ? `${method} reference number` : "Receipt number"}
          className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-arl-light"
        />
      </label>
      <Row label={receivedByLabel} value={receivedBy} />
      <div className="flex gap-2">
        {onCancel && (
          <button onClick={onCancel} disabled={saving}
            className="flex-1 px-4 py-2 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-white disabled:opacity-50">
            Cancel
          </button>
        )}
        <button onClick={onSubmit} disabled={saving || (needsRef && !reference.trim())}
          className="flex-1 px-4 py-2 rounded-xl text-sm font-semibold bg-arl-dark text-white hover:opacity-90 disabled:opacity-50">
          {saving ? "Saving…" : submitLabel}
        </button>
      </div>
    </div>
  );
}