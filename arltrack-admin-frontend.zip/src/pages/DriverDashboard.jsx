import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { collection, query, where, getDocs } from "firebase/firestore";
import usePolling from "../hooks/usePolling";
import { useAuth } from "../context/AuthContext";
import { db } from "../fireabase";

const API_URL = process.env.REACT_APP_API_URL;

// Same threshold as Account.jsx and the backend's LICENSE_WARNING_DAYS.
const LICENSE_WARNING_DAYS = 14;
const DAY_MS = 24 * 60 * 60 * 1000;
const TZ = "Asia/Manila"; // the backend formats in Manila time; don't let a phone's timezone shift trip times

// ─── ICONS ───────────────────────────────────────────────────────────────
const IconSteering = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="2.5" />
    <path strokeLinecap="round" d="M12 3v6.5M12 14.5V21M4.2 7.5l5.6 3.2M14.2 13.3l5.6 3.2M19.8 7.5l-5.6 3.2M9.8 13.3l-5.6 3.2" />
  </svg>
);

const IconClock = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3 2" />
  </svg>
);

const IconCar = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 17h8M3 11l2-5h14l2 5M5 11h14M5 17v2m14-2v2" />
  </svg>
);

const IconTimer = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M7 3h10M7 21h10M8 3v3a4 4 0 001.2 2.8L12 12l2.8-3.2A4 4 0 0016 6V3M8 21v-3a4 4 0 011.2-2.8L12 12l2.8 3.2A4 4 0 0116 18v3" />
  </svg>
);

const IconCheck = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M20 6L9 17l-5-5" />
  </svg>
);

const IconCalendar = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="5" width="18" height="16" rx="2" />
    <path strokeLinecap="round" d="M16 3v4M8 3v4M3 10h18" />
  </svg>
);

const IconWarning = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4M12 17h.01M10.29 3.86L1.82 18a1.5 1.5 0 001.29 2.25h17.78A1.5 1.5 0 0022.18 18L13.71 3.86a1.5 1.5 0 00-2.42 0z" />
  </svg>
);

const IconInfo = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <path strokeLinecap="round" d="M12 11v5M12 8h.01" />
  </svg>
);

const IconPin = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s-7-6.2-7-11a7 7 0 1114 0c0 4.8-7 11-7 11z" />
    <circle cx="12" cy="10" r="2.5" />
  </svg>
);

// ─── FORMATTERS ──────────────────────────────────────────────────────────
// Every formatter bails out on null/invalid — `new Date(null)` is the 1970 epoch, not Invalid Date.
const toDate = (val) => {
  if (!val) return null;
  const d = new Date(val);
  return isNaN(d) ? null : d;
};

const fmtDateTime = (val) => {
  const d = toDate(val);
  return d ? d.toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZone: TZ }) : "—";
};

const fmtDay = (val) => {
  const d = toDate(val);
  return d ? d.toLocaleDateString("en-PH", { weekday: "short", month: "short", day: "numeric", timeZone: TZ }) : "—";
};

const fmtClock = (val) => {
  const d = toDate(val);
  return d ? d.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit", timeZone: TZ }) : "";
};

const fmtPeso = (n) =>
  `₱${Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// "7 days 22 hrs" / "3 days" / "6 hrs" — whole hours are plenty for a rental
// window; under an hour falls back to minutes.
const fmtDuration = (start, end) => {
  const ms = new Date(end) - new Date(start);
  if (!start || !end || isNaN(ms) || ms <= 0) return "—";
  const totalHrs = Math.round(ms / 3_600_000);
  if (totalHrs < 1) return `${Math.max(1, Math.round(ms / 60_000))} mins`;
  const days = Math.floor(totalHrs / 24);
  const hrs  = totalHrs % 24;
  const d = days ? `${days} ${days === 1 ? "day" : "days"}` : "";
  const h = hrs  ? `${hrs} ${hrs === 1 ? "hr" : "hrs"}`     : "";
  return [d, h].filter(Boolean).join(" ");
};

// Compact "how long" for the live countdown: "2d 4h" / "2h 15m" / "12m".
const fmtSpan = (ms) => {
  const mins = Math.max(0, Math.floor(ms / 60_000));
  if (mins < 1) return "less than a minute";
  const d = Math.floor(mins / 1440);
  const h = Math.floor((mins % 1440) / 60);
  const m = mins % 60;
  if (d >= 1) return h ? `${d}d ${h}h` : `${d}d`;
  if (h >= 1) return m ? `${h}h ${m}m` : `${h}h`;
  return `${m}m`;
};

// The one line + tone that answers "when?" for a trip, relative to `now`.
//   upcoming → "Starts in 2h 15m" (grey) · "Start time passed 20m ago" (amber) · "Starting now"
//   ongoing  → "Ends in 1d 3h" (grey)    · "Return overdue by 2h" (red)
function tripTiming(trip, now) {
  const start = toDate(trip.startDateTime);
  const end   = toDate(trip.endDateTime);
  if (trip.status === "ongoing") {
    if (!end) return null;
    const left = end - now;
    return left >= 0
      ? { text: `Ends in ${fmtSpan(left)}`, tone: "neutral" }
      : { text: `Return overdue by ${fmtSpan(-left)}`, tone: "danger" };
  }
  if (!start) return null;
  const until = start - now;
  if (until > 60_000)  return { text: `Starts in ${fmtSpan(until)}`, tone: "neutral" };
  if (until >= -60_000) return { text: "Starting now", tone: "warn" };
  return { text: `Start time passed ${fmtSpan(-until)} ago`, tone: "warn" };
}

const TONE = {
  neutral: "bg-gray-100 text-gray-700 border-gray-200",
  warn:    "bg-amber-50 text-amber-700 border-amber-200",
  danger:  "bg-red-50 text-red-700 border-red-200",
  good:    "bg-green-50 text-green-700 border-green-200",
};

// Same rule the backend uses to let Start Pickup / "On my way" through
// (driverDispatch.service.js): payment approved/paid AND nothing owing.
function tripReadiness(trip) {
  const pay = trip.payment || {};
  const balance = Number(pay.balance) || 0;
  const paymentReady = ["approved", "paid"].includes(String(pay.paymentStatus || "").toLowerCase()) && balance <= 0;
  return {
    paymentReady,
    balance,
    inspectionReady: !!trip.beforeDocsComplete,
  };
}

function Chip({ tone = "neutral", children }) {
  return (
    <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-lg border ${TONE[tone]}`}>
      {children}
    </span>
  );
}

const parseExpiry = (val) => {
  if (!val) return null;
  if (typeof val === "string") return toDate(val);
  if (typeof val?.toDate === "function") return val.toDate();
  if (val?._seconds !== undefined) return new Date(val._seconds * 1000);
  return null;
};

// Stat card — same design as the admin Dashboard.jsx cards (p-5, border, uppercase label, 2xl value).
function StatCard({ icon, label, value, tint }) {
  return (
    <div className="bg-white p-5 rounded-2xl border shadow-sm flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${tint}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-xs text-gray-500 font-medium uppercase tracking-wide">{label}</div>
        <div className="text-2xl font-bold text-gray-800 mt-0.5">{value}</div>
      </div>
    </div>
  );
}

// Parses defensively: a 502 from the host returns HTML, and `res.json()` would
// otherwise surface "Unexpected token <" to the driver.
async function readJson(res) {
  try { return await res.json(); } catch { return {}; }
}

export default function DriverDashboard() {
  const navigate = useNavigate();
  const { user, previewRole } = useAuth();
  const token = localStorage.getItem("token");

  const [liveTrips, setLiveTrips] = useState([]);   // upcoming + ongoing
  const [pastTrips, setPastTrips] = useState([]);   // completed/cancelled/stolen
  const [loading, setLoading]     = useState(true);
  // Live trips and history fail independently. The live list is what the
  // screen is for, so only ITS failure replaces the "nothing on your plate"
  // empty state; a failed history just blanks the "accomplished" count.
  const [liveError, setLiveError]       = useState(null);
  const [historyError, setHistoryError] = useState(false);
  // A background refresh failed after a good load: keep showing the last data, but say so.
  const [refreshFailed, setRefreshFailed] = useState(false);
  const [lastUpdated, setLastUpdated]     = useState(null);

  const [license, setLicense] = useState(null); // { status: "expired" | "expiring", daysLeft } | null
  const [now, setNow] = useState(() => Date.now());

  // An Admin using "preview as Driver" hits this same component, but the
  // /my-trips endpoints are driver-only (403 for anyone else) and there is no
  // "show me driver X's trips". So in preview we don't call them at all.
  const isPreviewingAsDriver = previewRole === "Driver" && user?.role !== "Driver";

  const authedFetch = useCallback((path) =>
    fetch(`${API_URL}${path}`, { headers: { Authorization: `Bearer ${token}` } }),
  [token]);

  const fetchLive = useCallback(async () => {
    const res  = await authedFetch("/api/driver-dispatch/my-trips");
    const json = await readJson(res);
    if (!res.ok) throw new Error(json.message || "Failed to load your trips");
    return Array.isArray(json.data) ? json.data : [];
  }, [authedFetch]);

  const fetchHistory = useCallback(async () => {
    const res  = await authedFetch("/api/driver-dispatch/my-trips/history");
    const json = await readJson(res);
    if (!res.ok) throw new Error(json.message || "Failed to load your trip history");
    return Array.isArray(json.data) ? json.data : [];
  }, [authedFetch]);

  // History is only used for the "accomplished" count, and the backend shapes
  // every past trip (payment + customer + session lookups each) to produce it.
  // So it is loaded once, not on every poll — see the liveCount effect below
  // for when it is refreshed.
  const loadHistory = useCallback(async () => {
    try {
      setPastTrips(await fetchHistory());
      setHistoryError(false);
    } catch {
      setHistoryError(true);
    }
  }, [fetchHistory]);

  // `silent` skips the spinner and the error banner — used by the 30s refresh so a
  // newly-assigned trip doesn't blank the screen while it reloads.
  const loadLive = useCallback(async (silent = false) => {
    if (!silent) { setLoading(true); setLiveError(null); }
    try {
      setLiveTrips(await fetchLive());
      setLiveError(null);
      setRefreshFailed(false);
      setLastUpdated(new Date());
    } catch (e) {
      if (silent) setRefreshFailed(true);
      else setLiveError(e.message || "Couldn't load your trips. Check your connection and try again.");
    } finally {
      if (!silent) setLoading(false);
    }
  }, [fetchLive]);

  const retry = useCallback(() => {
    loadLive();
    loadHistory();
  }, [loadLive, loadHistory]);

  useEffect(() => {
    if (isPreviewingAsDriver) { setLoading(false); return; }
    loadLive();
    loadHistory();
  }, [isPreviewingAsDriver, loadLive, loadHistory]);

  // 30s refresh, live trips only. (Was onSnapshot on the whole bookings
  // collection — a full read per open tab; polling pauses while the tab is hidden.)
  usePolling(() => loadLive(true), 30_000, { immediate: false, enabled: !isPreviewingAsDriver });

  // When a trip leaves the live list (completed / cancelled), the history count is
  // out of date — refresh it then, instead of polling it every 30 seconds.
  const prevLiveCount = useRef(null);
  useEffect(() => {
    if (loading) return;
    if (prevLiveCount.current !== null && liveTrips.length < prevLiveCount.current) loadHistory();
    prevLiveCount.current = liveTrips.length;
  }, [liveTrips.length, loading, loadHistory]);

  // Ticks the countdowns. Purely local — no network.
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30_000);
    const onVisible = () => { if (!document.hidden) setNow(Date.now()); };
    document.addEventListener("visibilitychange", onVisible);
    return () => { clearInterval(t); document.removeEventListener("visibilitychange", onVisible); };
  }, []);

  // License expiry — one read on mount, same collection Account.jsx reads. A person can
  // have several userDocument records (re-uploads), so the LATEST expiry wins (same as
  // the backend). Any failure just hides the banner; Account still shows the full status.
  useEffect(() => {
    if (user?.role !== "Driver" || isPreviewingAsDriver || !user?.uid) return undefined;
    let cancelled = false;
    (async () => {
      try {
        const snap = await getDocs(query(collection(db, "userDocument"), where("userID", "==", user.uid)));
        let latest = null;
        snap.forEach((d) => {
          const exp = parseExpiry(d.data().driverLicenseExpiry);
          if (exp && (!latest || exp > latest)) latest = exp;
        });
        if (cancelled || !latest) return;
        const daysLeft = Math.ceil((latest.getTime() - Date.now()) / DAY_MS);
        if (latest.getTime() < Date.now()) setLicense({ status: "expired", daysLeft });
        else if (daysLeft <= LICENSE_WARNING_DAYS) setLicense({ status: "expiring", daysLeft });
      } catch { /* banner is a convenience; stay quiet */ }
    })();
    return () => { cancelled = true; };
  }, [user?.uid, user?.role, isPreviewingAsDriver]);

  const ongoing  = liveTrips.filter((t) => t.status === "ongoing");
  const upcoming = liveTrips.filter((t) => t.status === "upcoming")
    .sort((a, b) => new Date(a.startDateTime) - new Date(b.startDateTime));
  const completedCount = pastTrips.filter((t) => t.status === "completed").length;

  // "Next up" = the ongoing trip if there is one (needs attention now),
  // otherwise the soonest upcoming booking.
  const nextTrip = ongoing[0] || upcoming[0] || null;
  // Everything else coming up — never repeats the Next Up card.
  const moreUpcoming = upcoming.filter((t) => t !== nextTrip);

  const firstName = user?.username?.split(" ")[0] || "there";

  const showCounts = !loading && !liveError;
  const nextTiming = nextTrip ? tripTiming(nextTrip, now) : null;
  const nextReady  = nextTrip && nextTrip.status === "upcoming" ? tripReadiness(nextTrip) : null;
  const nextPlace  = nextTrip?.location && nextTrip.location !== "—" ? nextTrip.location : null;

  return (
    <div className="w-full px-4 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-arl-dark">Hi, {firstName} 👋</h1>
      </div>

      {isPreviewingAsDriver && (
        <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-xl text-xs flex items-center gap-2">
          <IconInfo className="w-4 h-4 shrink-0" />
          Preview mode: a driver's trips are tied to their own login, so there's nothing to load here.
        </div>
      )}

      {license && (
        <div className={`px-4 py-3 rounded-xl text-sm flex items-center justify-between gap-3 border ${
          license.status === "expired" ? "bg-red-50 border-red-200 text-red-700" : "bg-yellow-50 border-yellow-200 text-yellow-800"
        }`}>
          <span className="flex items-center gap-2">
            <IconWarning className="w-4 h-4 shrink-0" />
            {license.status === "expired"
              ? "Your driver's license has expired. Upload your renewed license so you can keep getting trips."
              : `Your driver's license expires in ${license.daysLeft} ${license.daysLeft === 1 ? "day" : "days"}. Upload your renewed license before then.`}
          </span>
          <button onClick={() => navigate("/account")} className="font-semibold underline text-xs shrink-0">Go to Account</button>
        </div>
      )}

      {liveError && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center justify-between">
          <span className="flex items-center gap-2">
            <IconWarning className="w-4 h-4 shrink-0" />
            {liveError}
          </span>
          <button onClick={retry} className="text-red-600 font-semibold underline text-xs ml-4 shrink-0">Retry</button>
        </div>
      )}

      {!liveError && refreshFailed && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2.5 rounded-xl text-xs flex items-center justify-between">
          <span className="flex items-center gap-2">
            <IconWarning className="w-4 h-4 shrink-0" />
            Couldn't refresh. Showing your trips as of {lastUpdated ? fmtClock(lastUpdated) : "the last load"}.
          </span>
          <button onClick={retry} className="font-semibold underline ml-4 shrink-0">Retry</button>
        </div>
      )}

      {/* STATS — blank ("—") rather than a misleading 0 when the data didn't load */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <StatCard
          icon={<IconCalendar className="w-6 h-6 text-indigo-600" />}
          tint="bg-indigo-50"
          label="Upcoming Bookings"
          value={loading ? "…" : liveError ? "—" : upcoming.length}
        />
        <StatCard
          icon={<IconSteering className="w-6 h-6 text-amber-600" />}
          tint="bg-amber-50"
          label="Ongoing Now"
          value={loading ? "…" : liveError ? "—" : ongoing.length}
        />
        <StatCard
          icon={<IconCheck className="w-6 h-6 text-green-600" />}
          tint="bg-green-50"
          label="Bookings Accomplished"
          value={loading ? "…" : historyError ? "—" : completedCount}
        />
      </div>

      {/* NEXT UP */}
      <div>
        <h2 className="text-lg font-semibold text-gray-800 mb-3 flex items-center gap-2">Next Up</h2>
        {loading ? (
          <div className="bg-white rounded-2xl border shadow-sm p-6 h-28 animate-pulse" />
        ) : liveError ? null : !nextTrip ? (
          <div className="bg-white rounded-2xl border shadow-sm p-8 text-center">
            <IconSteering className="w-7 h-7 mx-auto text-gray-300 mb-2" />
            <p className="text-sm font-semibold text-arl-dark">Nothing on your plate right now</p>
            <p className="text-xs text-gray-400 mt-1">New bookings assigned to you will show up here.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border shadow-sm p-5 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`inline-block text-xs font-bold uppercase tracking-wide px-3 py-1 rounded-lg ${
                nextTrip.status === "ongoing" ? "bg-green-50 text-green-700 border border-green-200" : "bg-yellow-50 text-yellow-700 border border-yellow-200"
              }`}>{nextTrip.status}</span>
              {nextTiming && <Chip tone={nextTiming.tone}><IconClock className="w-3.5 h-3.5" /> {nextTiming.text}</Chip>}
              {nextTrip.enRouteAt && nextTrip.status === "upcoming" && <Chip tone="good">On your way</Chip>}
            </div>

            {/* When is the whole point of this card, so it gets the big type.
                Customer details etc. live behind the button. */}
            <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-2">
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-0.5">
                <p className="text-base font-bold text-arl-dark leading-tight">
                  {fmtDay(nextTrip.startDateTime)} <span className="text-arl-primary">· {fmtClock(nextTrip.startDateTime)}</span>
                </p>
                <p className="text-xs text-gray-500">
                  until <span className="font-semibold text-arl-dark">{fmtDay(nextTrip.endDateTime)}, {fmtClock(nextTrip.endDateTime)}</span>
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500">
                <span className="flex items-center gap-1"><IconTimer /> {fmtDuration(nextTrip.startDateTime, nextTrip.endDateTime)}</span>
                <span className="flex items-center gap-1"><IconCar /> {nextTrip.vehicleName}</span>
              </div>
            </div>

            {nextPlace && (
              <p className="text-xs text-gray-600 flex items-start gap-1.5">
                <IconPin className="w-4 h-4 shrink-0 text-gray-400" />
                <span className="font-semibold">{nextPlace}</span>
              </p>
            )}

            {/* Can I actually start? Same two gates the backend enforces at Start Pickup. */}
            {nextReady && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {nextReady.paymentReady
                  ? <Chip tone="good"><IconCheck className="w-3.5 h-3.5" /> Payment settled</Chip>
                  : nextReady.balance > 0
                    ? <Chip tone="warn"><IconWarning className="w-3.5 h-3.5" /> {fmtPeso(nextReady.balance)} balance due</Chip>
                    : <Chip tone="warn"><IconWarning className="w-3.5 h-3.5" /> Payment not approved yet</Chip>}
                {nextReady.inspectionReady
                  ? <Chip tone="good"><IconCheck className="w-3.5 h-3.5" /> Inspection done</Chip>
                  : <Chip tone="warn"><IconWarning className="w-3.5 h-3.5" /> Inspection pending</Chip>}
              </div>
            )}

            <button onClick={() => navigate("/my-trips")}
              className="w-full py-2 rounded-xl text-sm font-semibold bg-teal-700 text-white hover:bg-teal-800 active:scale-[0.99] transition-all">
              {nextTrip.status === "ongoing" ? "Manage This Trip" : "Go to My Trips →"}
            </button>
          </div>
        )}
      </div>

      {/* MORE UPCOMING — every other upcoming trip, never repeating the Next Up card */}
      {!liveError && moreUpcoming.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-semibold text-gray-800">Also Coming Up</h2>
            <button onClick={() => navigate("/my-trips")} className="text-xs text-arl-primary font-medium hover:underline">
              View all →
            </button>
          </div>
          <div className="space-y-2">
            {moreUpcoming.slice(0, 4).map((trip) => (
              <div key={trip.id} className="bg-white rounded-2xl border shadow-sm p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-arl-dark truncate">{trip.vehicleName}</p>
                  <p className="text-xs text-gray-400 truncate">{fmtDuration(trip.startDateTime, trip.endDateTime)}</p>
                </div>
                <span className="text-sm font-bold text-arl-dark shrink-0 flex items-center gap-1">
                  <IconClock /> {fmtDateTime(trip.startDateTime)}
                </span>
              </div>
            ))}
          </div>
          {moreUpcoming.length > 4 && (
            <p className="text-xs text-gray-400 mt-2 text-center">+{moreUpcoming.length - 4} more in My Trips</p>
          )}
        </div>
      )}
    </div>
  );
}