import { useState, useEffect, useCallback, useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import usePolling from "../../hooks/usePolling";
import { useCurrency } from "../../context/CurrencyContext";
import { useAuth } from "../../context/AuthContext";
import DeleteBundleModal from "../../components/shared/DeleteBundleModal";
import { ROLES } from "../../config/pagePermissions";
import TripMapModal from "../../components/shared/TripMapModal";
import { readCodingWarnings, warningsByCity } from "../../utils/codingWarnings";

// Same shape MyTrips.jsx's tripStops() builds for TripMapModal — pickup,
// dropoff, and any extra stops the customer selected at booking time
// (booking.geofenceZones, now resolved by getAllBookings alongside
// pickupLocation/dropoffLocation — see booking.service.js's
// resolveHistoryInfo). Kept as its own small copy here rather than a
// shared import: duplicating small resolvers/helpers per-module is the
// existing convention in this codebase (see driverDispatch.service.js).
const SAME_SPOT_DEG = 0.0005;
const isSameSpot = (a, b) =>
  !!a && !!b && Math.abs(a.lat - b.lat) < SAME_SPOT_DEG && Math.abs(a.lng - b.lng) < SAME_SPOT_DEG;

function tripStops(booking) {
  const stops = [];
  if (booking.pickupLocation) stops.push({ key: "pickup", type: "pickup", ...booking.pickupLocation });
  if (booking.dropoffLocation) stops.push({ key: "dropoff", type: "dropoff", ...booking.dropoffLocation });
  (booking.geofenceZones || []).forEach((zone, i) => {
    if (typeof zone.lat !== "number" || typeof zone.lng !== "number") return;
    const label = (zone.label || "").toLowerCase();
    if (label.includes("pickup") || label.includes("drop")) return;
    if (isSameSpot(zone, booking.pickupLocation) || isSameSpot(zone, booking.dropoffLocation)) return;
    stops.push({ key: `stop-${i}`, type: "stop", address: zone.label || `Stop ${i + 1}`, lat: zone.lat, lng: zone.lng });
  });
  return stops;
}

// ─── SVG ICONS ───────────────────────────────────────────────────────────────

const IconWarning = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="12" y1="9" x2="12" y2="13" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
    <line x1="12" y1="17" x2="12.01" y2="17" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
  </svg>
);

const IconCheck = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconClock = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.75" />
    <path d="M12 7v5l3 3" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" />
  </svg>
);

const IconRefresh = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M23 4v6h-6M1 20v-6h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M3.51 9a9 9 0 0114.36-3.36L23 10M1 14l5.13 4.36A9 9 0 0020.49 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconX = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

// Used for the "All Bookings" stat tab icon.
const IconGrid = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="3" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
    <rect x="14" y="3" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
    <rect x="3" y="14" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
    <rect x="14" y="14" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
  </svg>
);

// Used for the "Ongoing" stat tab icon — a pulse/activity line.
const IconActivity = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 12h4l3 8 4-16 3 8h4" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// ─── DATA ────────────────────────────────────────────────────────────────────

// "To Pay" = the customer created the booking but the deposit hasn't cleared yet.
// Nothing has been paid, so staff can't act on it (no pickup/driver) — it's listed so
// pending bookings (and the car being held for them) are visible. It flips to
// "Upcoming" by itself the moment the deposit is paid, or auto-cancels after 12 hours.
const STATUS_TABS = ["All", "To Pay", "Upcoming", "Ongoing", "Cancelled", "Completed"];

// Icon + color per stat tab — colors match STATUS_DOT/STATUS_BG below so a
// status looks the same in the tab card as it does in the table badge.
const TAB_ICON = {
  All:       IconGrid,
  "To Pay":  IconClock,
  Upcoming:  IconClock,
  Ongoing:   IconActivity,
  Cancelled: IconX,
  Completed: IconCheck,
};

const TAB_ICON_COLOR = {
  All:       "bg-teal-50 text-teal-600",
  "To Pay":  "bg-orange-50 text-orange-600",
  Upcoming:  "bg-yellow-50 text-yellow-600",
  Ongoing:   "bg-blue-50 text-blue-600",
  Cancelled: "bg-red-50 text-red-600",
  Completed: "bg-green-50 text-green-600",
};

// STATUS_DOT / STATUS_BG / StatusBadge — kept identical to the copy in
// Dashboard.jsx so the same status always looks the same on both pages.
// If a new status is added, update both files.
const STATUS_DOT = {
  "to pay":  "bg-orange-400",
  upcoming:  "bg-yellow-400",
  ongoing:   "bg-blue-500",
  completed: "bg-green-500",
  cancelled: "bg-red-500",
  stolen:    "bg-red-700",
};

const STATUS_BG = {
  "to pay":  "bg-orange-50 border border-orange-200",
  upcoming:  "bg-yellow-50 border border-yellow-200",
  ongoing:   "bg-blue-50 border border-blue-200",
  completed: "bg-green-50 border border-green-200",
  cancelled: "bg-red-50 border border-red-200",
  stolen:    "bg-red-100 border border-red-300",
};

function StatusBadge({ status }) {
  const s   = (status || "").toLowerCase();
  const dot = STATUS_DOT[s] || "bg-gray-400";
  const bg  = STATUS_BG[s]  || "bg-gray-50 border border-gray-200";
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full capitalize text-black ${bg}`}>
      <span className={`w-2 h-2 rounded-full shrink-0 ${dot}`} />
      {status?.replace("_", " ")}
    </span>
  );
}

const fmtDate = (val) => {
  if (!val) return "—";
  try {
    let d;
    if (typeof val?.toDate === "function") d = val.toDate();
    else if (val?._seconds !== undefined) d = new Date(val._seconds * 1000);
    else d = new Date(val);
    if (isNaN(d.getTime())) return "—";
    return d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
  } catch { return "—"; }
};

// Same parsing as fmtDate, but keeps the time — used for "Created", where the
// exact moment the booking was made matters (two bookings can share a date).
const fmtDateTime = (val) => {
  if (!val) return "—";
  try {
    let d;
    if (typeof val?.toDate === "function") d = val.toDate();
    else if (val?._seconds !== undefined) d = new Date(val._seconds * 1000);
    else if (val?.seconds !== undefined) d = new Date(val.seconds * 1000);
    else d = new Date(val);
    if (isNaN(d.getTime())) return "—";
    return d.toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
  } catch { return "—"; }
};

// Same Firestore-Timestamp-or-string-or-seconds handling as fmtDate above,
// but returns a raw millisecond number (or -Infinity for unparsable/empty
// values) so sort() has something numeric to compare rather than strings.
const toMillis = (val) => {
  if (!val) return -Infinity;
  try {
    let d;
    if (typeof val?.toDate === "function") d = val.toDate();
    else if (val?._seconds !== undefined) d = new Date(val._seconds * 1000);
    else if (val?.seconds !== undefined) d = new Date(val.seconds * 1000);
    else d = new Date(val);
    const ms = d.getTime();
    return isNaN(ms) ? -Infinity : ms;
  } catch { return -Infinity; }
};

// Time-of-day only (e.g. "3:45 PM") — shown in its own "Time" column next to "Date".
const fmtTime = (val) => {
  const ms = toMillis(val);
  if (!isFinite(ms)) return "—";
  return new Date(ms).toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" });
};

// "YYYY-MM-DD" (local day) of any date value the table shows, or null — what
// the date picker in "Search by" is compared against.
const dayKey = (val) => {
  const ms = toMillis(val);
  if (!isFinite(ms)) return null;
  const d = new Date(ms);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

// "Search by" options — mirror the table's columns. Status is NOT here: it has
// its own dropdown. Booking ID has no column but stays searchable because
// Payments / Refund Requests link in with ?search=<bookingID>.
const SEARCH_BY = [
  { key: "created",  label: "Created At", type: "date" },
  { key: "customer", label: "Customer",   type: "text" },
  { key: "phone",    label: "Contact No.", type: "text" },
  { key: "vehicle",  label: "Vehicle",    type: "text" },
  { key: "start",    label: "Trip Start", type: "date" },
  { key: "end",      label: "Trip End",   type: "date" },
  { key: "phase",    label: "Phase",      type: "text" },
  { key: "booking",  label: "Booking ID", type: "text" },
];

// ─── SORT HEADER ────────────────────────────────────────────────────────────
// Clickable <th> that toggles asc/desc on the given sortKey. Shows a neutral
// up/down chevrons icon when the column isn't the active sort (so it reads
// as "sortable" even before you've clicked it), and a bold single arrow in
// the active color once it is. Keeps Bookings/Users sort UI visually and
// behaviorally identical.
const IconChevronsUpDown = ({ className = "w-3.5 h-3.5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7 15l5 5 5-5M7 9l5-5 5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconSortArrow = ({ dir, className = "w-3.5 h-3.5" }) => (
  <svg
    className={`${className} transition-transform ${dir === "desc" ? "rotate-180" : ""}`}
    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M12 19V5M5 12l7-7 7 7" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

function SortableTh({ label, sortKey: key, sortKeyState, sortDir, onSort, className = "" }) {
  const active = sortKeyState === key;
  return (
    <th className={`px-4 py-3 text-left select-none ${className}`}>
      <button
        onClick={() => onSort(key)}
        className={`flex items-center gap-1.5 uppercase tracking-wide text-xs font-semibold px-2 py-1 -mx-2 rounded-lg transition-colors ${
          active ? "text-teal-700 bg-teal-50" : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
        }`}
      >
        {label}
        {active ? <IconSortArrow dir={sortDir} /> : <IconChevronsUpDown />}
      </button>
    </th>
  );
}

// Admin refund/cancel only applies before the trip starts — an ongoing trip goes through the customer's cancellation request instead.
const canRefundCancel = (status) => ["to pay", "upcoming"].includes(status?.toLowerCase());

const PAGE_SIZE = 10;

// ─── PAGINATION ───────────────────────────────────────────────────────────────
function usePagination(items, pageSize = PAGE_SIZE) {
  const [page, setPage] = useState(1);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  // Clamp if the list shrinks (filter/search/refresh) and we were on a now-empty page.
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;
  const pageItems = items.slice(start, start + pageSize);
  return { page: safePage, setPage, totalPages, pageItems, start, count: items.length };
}

function Pagination({ page, totalPages, onChange, start, pageSize, count }) {
  if (count === 0) return null;

  const nums = [];
  const add = (n) => nums.push(n);
  add(1);
  for (let n = page - 1; n <= page + 1; n++) if (n > 1 && n < totalPages) add(n);
  if (totalPages > 1) add(totalPages);
  const dedup = [...new Set(nums)].sort((a, b) => a - b);

  const rangeEnd = Math.min(start + pageSize, count);

  return (
    <div className="flex items-center justify-between px-5 py-3 border-t bg-gray-50/50">
      <p className="text-xs text-gray-400">
        Showing {count === 0 ? 0 : start + 1}–{rangeEnd} of {count}
      </p>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange(Math.max(1, page - 1))} disabled={page === 1}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Prev
        </button>
        {dedup.map((n, i) => (
          <span key={n} className="flex items-center">
            {i > 0 && n - dedup[i - 1] > 1 && <span className="px-1.5 text-gray-300 text-xs">…</span>}
            <button onClick={() => onChange(n)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                n === page ? "bg-arl-primary text-white shadow" : "border text-gray-600 hover:bg-white"
              }`}>
              {n}
            </button>
          </span>
        ))}
        <button onClick={() => onChange(Math.min(totalPages, page + 1))} disabled={page === totalPages}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border text-gray-600 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed">
          Next
        </button>
      </div>
    </div>
  );
}


// ─── ADD NOTE MODAL ───────────────────────────────────────────────────────────
// Staff can only add / update the admin note here. Status changes and moving locations
// are handled elsewhere (Payments, Car Tracking, Refund / Cancel).

function EditModal({ booking, onClose, onSave }) {
  const [notesAdmin, setNotesAdmin] = useState(booking.notesAdmin || "");
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState(null);
  const { getToken } = useAuth();

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/bookings/${booking.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ notesAdmin }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to save");
      onSave();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
        <h2 className="font-bold text-lg text-gray-800">Add Note</h2>
        {error && <div className="text-red-600 text-sm bg-red-50 border border-red-200 p-3 rounded-xl">{error}</div>}
        <label className="block text-sm font-medium text-gray-700">Admin Note
          <textarea rows={4} autoFocus className="mt-1 w-full border rounded-xl px-3 py-2 text-sm outline-none resize-none focus:border-teal-500" value={notesAdmin} onChange={(e) => setNotesAdmin(e.target.value)} placeholder="Write a note for this booking…" />
        </label>
        <div className="flex gap-3 justify-end pt-2">
          <button onClick={onClose} className="px-4 py-2 border rounded-xl text-sm">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="px-4 py-2 bg-arl-primary text-white rounded-xl text-sm disabled:opacity-50 disabled:cursor-not-allowed">
            {saving ? "Saving…" : "Save Note"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── REFUND & CANCEL MODAL ────────────────────────────────────────────────────
// Admin/Owner only. Three refund types, each hitting the server, which sends the PayMongo refund(s), cancels the booking
// + GPS session, flips the refund-request/payment records and notifies the customer:
//   Full refund      -- our issue: deposit returned, gateway fee returned     POST /refund-cancel { refundType: "full" }
//   Normal refund    -- deposit returned, gateway fee kept                    POST /refund-cancel { refundType: "normal" }
//   No Deposit Refund -- deposit and gateway fee kept, everything else returned  POST /no-show
// "Cancel only" cancels without returning any money.

function RefundCancelModal({ booking, onClose, onDone }) {
  const { fmt } = useCurrency();
  const { getToken } = useAuth();
  const [preview, setPreview]   = useState(null);
  const [loading, setLoading]   = useState(true);
  const [mode, setMode]         = useState("full"); // "full" | "normal" | "no_show" | "cancel"
  const [reason, setReason]     = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]       = useState(null);
  const [notice, setNotice]     = useState(null); // set when part of the money has to be settled by staff after the cancel went through
  const [confirming, setConfirming] = useState(false); // "Cancel only" keeps the customer's money: ask once more first
  const navigate = useNavigate();
  const api = `${process.env.REACT_APP_API_URL}/api/bookings/${booking.id}`;

  useEffect(() => {
    let alive = true;
    fetch(`${api}/refund-preview`, { headers: { Authorization: `Bearer ${getToken()}` } })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j })))
      .then(({ ok, j }) => {
        if (!alive) return;
        if (!ok) throw new Error(j.message || "Could not load refund preview.");
        setPreview(j.data);
        if (!(j.data.total > 0)) setMode("cancel"); // nothing to refund → plain cancel
      })
      .catch((e) => alive && setError(e.message))
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking.id]);

  useEffect(() => { setConfirming(false); }, [mode]);

  const hasMoney = (preview?.total || 0) > 0;
  const blocked  = !!preview?.existingRequest && (mode === "cancel" || mode === "no_show");
  const ns       = preview?.noShow;
  const nm       = preview?.normal;
  // No pickup check any more: the option is always offered while there is a payment to refund.
  const canNoDeposit = !!ns && !preview?.alreadyRefunded;
  // A customer's open refund request is approved as a Full refund, so Normal / No-show can't be chosen meanwhile.
  const hasOpenRequest = !!preview?.existingRequest;
  const canNormal = !!nm && nm.available && !hasOpenRequest && !preview?.alreadyRefunded;
  const isRefundMode = mode === "full" || mode === "normal" || mode === "no_show";
  // The figures of the option that is selected.
  const sel = mode === "full" ? { total: preview?.total || 0, online: preview?.onlineAmount || 0, manual: preview?.manualAmount || 0, scheduled: false, sendAfter: null }
    : mode === "normal" && nm ? { total: nm.total, online: nm.onlineAmount, manual: nm.manualAmount, scheduled: !!nm.scheduled, sendAfter: nm.sendAfter }
    : mode === "no_show" && ns ? { total: ns.total, online: ns.onlineAmount, manual: ns.manualAmount, scheduled: !!ns.scheduled, sendAfter: ns.sendAfter }
    : null;
  const paidSoFar = ns?.grossPaid ?? nm?.grossPaid ?? 0;
  const sendDay = (v) => {
    const d = v ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleDateString("en-PH", { timeZone: "Asia/Manila", month: "long", day: "numeric", year: "numeric" }) : "after midnight";
  };

  const submit = async () => {
    setSubmitting(true); setError(null);
    try {
      // "No Deposit Refund" keeps the deposit and refunds the rest.
      const res  = await fetch(mode === "no_show" ? `${api}/no-show` : `${api}/refund-cancel`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify(mode === "no_show" ? { reason: reason.trim() } : { reason: reason.trim(), refund: mode !== "cancel", refundType: mode === "normal" ? "normal" : "full" }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Request failed.");
      // The booking IS cancelled and the online part is on its way. If some money can't go back online, keep the
      // modal open with what staff still have to do instead of closing on a toast they might miss.
      if (json.data?.followUp) { setNotice({ message: json.message || "Booking cancelled.", ...json.data.followUp }); return; }
      onDone(json.message || "Booking cancelled.");
    } catch (e) { setError(e.message); }
    finally { setSubmitting(false); }
  };

  // disabledWhy: when set the option is greyed out and this says why (instead of the option silently disappearing).
  const opt = (value, title, desc, disabledWhy = null) => (
    <label className={`flex items-start gap-3 p-3 rounded-xl border ${disabledWhy ? "border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed" : `cursor-pointer ${mode === value ? "border-teal-500 bg-teal-50" : "border-gray-200"}`}`}>
      <input type="radio" className="mt-1" checked={mode === value} disabled={!!disabledWhy} onChange={() => setMode(value)} />
      <div>
        <p className="text-sm font-semibold text-gray-800">{title}</p>
        <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
        {disabledWhy && <p className="text-xs text-amber-700 mt-0.5">{disabledWhy}</p>}
      </div>
    </label>
  );

  // Partial refund: amber notice (not a red error) with what is left to do and a way straight to the payment.
  if (notice) {
    const finish = () => onDone(notice.message);
    const toPayments = () => { finish(); navigate(notice.paymentID ? `/payments?paymentID=${encodeURIComponent(notice.paymentID)}` : "/payments"); };
    return (
      <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[92vh] flex flex-col">
          <div className="px-6 pt-5 pb-3 shrink-0">
            <h2 className="font-bold text-lg text-gray-800">{notice.onlineAmount > 0 ? "Partial refund sent" : "Booking cancelled"}</h2>
            <p className="text-xs text-gray-400 font-mono break-all mt-1">{booking.bookingID || booking.id}</p>
          </div>
          <div className="px-6 pb-4 space-y-4 overflow-y-auto flex-1 min-h-0">
          <div className="text-sm bg-amber-50 border border-amber-200 text-amber-900 p-3 rounded-xl space-y-2">
            {notice.onlineAmount > 0 && (
              <div className="flex justify-between gap-4"><span>Going back through PayMongo</span><span className="font-semibold">{fmt(notice.onlineAmount)}</span></div>
            )}
            {notice.inStoreAmount > 0 && (
              <div className="flex justify-between gap-4"><span>Can't be refunded online, settle in store</span><span className="font-semibold text-orange-700">{fmt(notice.inStoreAmount)}</span></div>
            )}
            {notice.unrefundableAmount > 0 && (
              <div className="flex justify-between gap-4"><span>Paid online, no PayMongo payment ID</span><span className="font-semibold text-red-600">{fmt(notice.unrefundableAmount)}</span></div>
            )}
          </div>
          <p className="text-sm text-gray-600">
            {notice.inStoreAmount > 0
              ? "The booking is cancelled. Please settle the in-store amount with the customer, then record it on the payment."
              : "The booking is cancelled. Refund the remaining amount from the PayMongo dashboard."}
          </p>
          </div>
          <div className="px-6 py-4 border-t border-gray-100 shrink-0">
            <div className="flex flex-col gap-1.5">
              <button onClick={toPayments} className="w-full px-3 py-1.5 bg-arl-primary text-white font-semibold rounded-xl text-sm hover:bg-[#16526a] transition-colors">Continue to Payments &rarr;</button>
              <button onClick={finish} className="w-full py-1.5 border rounded-xl text-sm">Done</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 pt-5 pb-3 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-bold text-lg text-gray-800">Cancel Booking</h2>
            <button onClick={onClose} disabled={submitting} className="text-gray-400 hover:text-gray-600 shrink-0 disabled:opacity-50">
              <IconX className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-gray-400 font-mono break-all mt-1">{booking.bookingID || booking.id}</p>
        </div>

        {/* Body */}
        <div className="px-6 pb-4 space-y-4 overflow-y-auto flex-1 min-h-0">
        {error && <div className="text-red-600 text-sm bg-red-50 border border-red-200 p-3 rounded-xl">{error}</div>}

        {loading ? (
          <div className="text-sm text-gray-400">Checking payment…</div>
        ) : preview && (
          <>
            {preview.alreadyRefunded ? (
              <div className="text-sm bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-xl">This payment was already refunded — cancelling will just close the booking.</div>
            ) : hasMoney ? null : (
              <div className="text-sm bg-gray-50 border border-gray-200 text-gray-600 p-3 rounded-xl">{preview.unrefundableAmount > 0 ? "Nothing can be refunded through PayMongo for this booking." : "Nothing has been paid on this booking, so there is nothing to refund."}</div>
            )}

            {!preview.alreadyRefunded && preview.unrefundableAmount > 0 && (
              <div className="text-sm bg-red-50 border border-red-200 text-red-700 p-3 rounded-xl">
                <span className="font-semibold">{fmt(preview.unrefundableAmount)} — Payment ID does not exist.</span>{" "}
                It was paid online but no PayMongo payment ID is on record, so it can't be refunded through PayMongo{hasMoney ? " (the amount below is only the part that can be)" : ""}. Fix the payment record or refund it from the PayMongo dashboard.
              </div>
            )}

            {preview.existingRequest && (
              <div className="text-xs bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-xl">
                The customer already has a refund request ({preview.existingRequest.status}). Refunding here will approve that same request as a Full refund — no double refund.
              </div>
            )}

            {hasMoney && (
              <div className="space-y-2">
                {opt("full", "Full refund", "Use this when it's our issue. The deposit and the online payment fee are both returned to the customer.")}
                {opt(
                  "normal",
                  "Normal refund",
                  "The deposit is returned, but the online payment fee is not.",
                  canNormal ? null : hasOpenRequest ? "Not available while the customer's own refund request is open." : "This booking has no online payment fee to keep, so it would be the same as a Full refund."
                )}
                {opt(
                  "no_show",
                  "No Deposit Refund",
                  "The deposit and the online payment fee are not returned. Everything else the customer paid is refunded.",
                  canNoDeposit ? null : "Not available for this booking."
                )}
                {opt("cancel", "Cancel only (no refund)", "Cancels the booking but keeps the customer's money. Use only when the cancellation isn't refundable.")}
              </div>
            )}

            {hasMoney && isRefundMode && sel && (
              <div className={`text-sm border p-3 rounded-xl space-y-1 ${mode === "full" ? "bg-gray-50 border-gray-200" : "bg-amber-50 border-amber-200"}`}>
                {paidSoFar > 0 && <div className="flex justify-between"><span className="text-gray-600">Customer paid</span><span className="font-semibold">{fmt(paidSoFar)}</span></div>}
                {mode === "no_show" && ns && <div className="flex justify-between text-amber-700"><span>Deposit not refunded</span><span className="font-semibold">-{fmt(ns.forfeit)}</span></div>}
                {mode === "no_show" && ns && Number(ns.gatewayFeeKept) > 0 && <div className="flex justify-between text-amber-700"><span>Online payment fee kept</span><span className="font-semibold">-{fmt(ns.gatewayFeeKept)}</span></div>}
                {mode === "normal" && nm && <div className="flex justify-between text-amber-700"><span>Online payment fee kept</span><span className="font-semibold">-{fmt(nm.gatewayFeeKept)}</span></div>}
                <div className="flex justify-between border-t border-black/10 pt-1"><span className="font-bold text-gray-800">Refund</span><span className="font-black">{fmt(sel.total)}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Via PayMongo (automatic)</span><span>{fmt(sel.online)}</span></div>
                {sel.manual > 0 && <div className="flex justify-between"><span className="text-gray-500">Hand back in person</span><span>{fmt(sel.manual)}</span></div>}
                {sel.scheduled && (
                  <p className="text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-lg p-2 mt-1">
                    The customer paid today, and PayMongo can't send a partial refund on the day of payment. The booking is cancelled now and {fmt(sel.online)} is sent by PayMongo on {sendDay(sel.sendAfter)} (after midnight). The customer is told.
                  </p>
                )}
              </div>
            )}

            <label className="block text-sm font-medium text-gray-700">Reason (shown to the customer)
              <textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)}
                className="mt-1 w-full border rounded-xl px-3 py-2 text-sm outline-none resize-none" />
            </label>
            {blocked && <p className="text-xs text-red-600">Resolve the customer's open refund request first, or choose Full refund.</p>}
            {confirming && (
              <div className="text-sm bg-red-50 border border-red-300 text-red-800 p-3 rounded-xl space-y-1">
                <p className="font-semibold">Cancel without a refund?</p>
                <p className="text-xs">
                  The customer's money ({fmt(preview?.total || 0)}) is kept, the deposit is not returned, and the customer is told no refund was issued.
                  If you change your mind, a refund can still be recorded afterwards from the cancelled booking's details.
                </p>
              </div>
            )}
          </>
        )}

        </div>

        {/* Actions — stacked full-width, same as the Booking Details window */}
        <div className="px-6 py-4 border-t border-gray-100 shrink-0">
          <div className="flex flex-col gap-1.5">
          <button
            onClick={() => (mode === "cancel" && hasMoney && !confirming ? setConfirming(true) : submit())}
            disabled={submitting || loading || !preview || !reason.trim() || blocked}
            className="w-full px-3 py-1.5 bg-red-600 text-white font-semibold rounded-xl text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-red-700 transition-colors"
          >
            {submitting ? "Processing…" : confirming ? "Yes, cancel without refund" : !hasMoney || mode === "cancel" ? "Cancel Booking" : mode === "no_show" ? "No Deposit Refund & Cancel" : mode === "normal" ? "Normal Refund & Cancel" : "Full Refund & Cancel"}
          </button>
          <button onClick={onClose} disabled={submitting} className="w-full py-1.5 border rounded-xl text-sm disabled:opacity-50">Back</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── REFUND AFTER CANCEL MODAL ────────────────────────────────────────────────
// Admin/Owner only. For a booking that was cancelled WITHOUT a refund ("Cancel only"): record that some of the money goes back.
// Nothing is sent to PayMongo. It is handed back in store and marked as handed back on the Refund Requests page.
//   Full refund      -- our issue: nothing kept
//   Normal refund    -- deposit returned, gateway fee kept (the customer's loss is the fee)
//   No deposit refund -- deposit and gateway fee kept (the customer's loss is the deposit and the fee)
//   Custom amount    -- staff type the amount, up to what the customer paid
function RefundAfterCancelModal({ booking, onClose, onDone }) {
  const { fmt } = useCurrency();
  const { getToken } = useAuth();
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode]       = useState("full"); // "full" | "normal" | "no_show" | "manual"
  const [amount, setAmount]   = useState("");
  const [reason, setReason]   = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]     = useState(null);
  const api = `${process.env.REACT_APP_API_URL}/api/bookings/${booking.id}`;

  useEffect(() => {
    let alive = true;
    fetch(`${api}/refund-after-cancel-preview`, { headers: { Authorization: `Bearer ${getToken()}` } })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j })))
      .then(({ ok, j }) => {
        if (!alive) return;
        if (!ok) throw new Error(j.message || "Could not load the refund options.");
        setPreview(j.data);
      })
      .catch((e) => alive && setError(e.message))
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking.id]);

  const opts   = preview?.options;
  const paid   = preview?.paid || 0;
  const typed  = Number(amount);
  const manualOk = Number.isFinite(typed) && typed > 0 && typed <= (opts?.manual?.max || 0);
  // What the selected option returns and what the customer loses.
  const refund = !opts ? 0 : mode === "full" ? opts.full.total : mode === "normal" ? opts.normal.total : mode === "no_show" ? opts.no_show.total : (manualOk ? typed : 0);
  const kept   = Math.max(0, Math.round((paid - refund) * 100) / 100);
  const canSubmit = !!opts && !!reason.trim() && !submitting && (mode !== "manual" || manualOk)
    && (mode !== "normal" || opts.normal.available) && (mode !== "no_show" || opts.no_show.available);

  const submit = async () => {
    setSubmitting(true); setError(null);
    try {
      const res = await fetch(`${api}/refund-after-cancel`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ option: mode, reason: reason.trim(), ...(mode === "manual" ? { amount: typed } : {}) }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Request failed.");
      onDone(json.message || "Refund recorded.");
    } catch (e) { setError(e.message); }
    finally { setSubmitting(false); }
  };

  const opt = (value, title, desc, disabledWhy = null) => (
    <label className={`flex items-start gap-3 p-3 rounded-xl border ${disabledWhy ? "border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed" : `cursor-pointer ${mode === value ? "border-teal-500 bg-teal-50" : "border-gray-200"}`}`}>
      <input type="radio" className="mt-1" checked={mode === value} disabled={!!disabledWhy} onChange={() => setMode(value)} />
      <div className="flex-1">
        <p className="text-sm font-semibold text-gray-800">{title}</p>
        <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
        {disabledWhy && <p className="text-xs text-amber-700 mt-0.5">{disabledWhy}</p>}
        {value === "manual" && mode === "manual" && (
          <input type="number" min="0" step="0.01" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)}
            placeholder={`Amount (up to ${fmt(opts?.manual?.max || 0)})`}
            className="mt-2 w-full border rounded-lg px-3 py-2 text-sm outline-none" />
        )}
      </div>
    </label>
  );

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 space-y-4 max-h-[90vh] overflow-y-auto">
        <h2 className="font-bold text-lg text-gray-800">Refund Cancelled Booking</h2>
        <p className="text-xs text-gray-400 font-mono break-all">{booking.bookingID || booking.id}</p>
        {error && <div className="text-red-600 text-sm bg-red-50 border border-red-200 p-3 rounded-xl">{error}</div>}

        {loading ? (
          <div className="text-sm text-gray-400">Checking payment…</div>
        ) : preview && !preview.eligible ? (
          <div className="text-sm bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-xl">{preview.blockedReason || "A refund can't be recorded for this booking."}</div>
        ) : opts && (
          <>
            <p className="text-xs text-gray-500">This booking was cancelled without a refund, so the customer's money is being kept. Choose what goes back. It is handed back in store, nothing is sent to PayMongo.</p>
            <div className="space-y-2">
              {opt("full", "Full refund", `Our issue. Everything the customer paid goes back: ${fmt(opts.full.total)}.`)}
              {opt("normal", "Normal refund",
                opts.normal.available ? `The deposit goes back but the ${fmt(opts.normal.gatewayFeeKept)} online payment fee is not returned: ${fmt(opts.normal.total)} back.` : "The deposit goes back but the online payment fee is not.",
                opts.normal.available ? null : "This booking has no online payment fee to keep, so it would be the same as a Full refund.")}
              {opt("no_show", "No deposit refund",
                opts.no_show.available ? `The ${fmt(opts.no_show.forfeit)} deposit${Number(opts.no_show.gatewayFeeKept) > 0 ? ` and the ${fmt(opts.no_show.gatewayFeeKept)} online payment fee are` : " is"} kept, the rest goes back: ${fmt(opts.no_show.total)} back.` : "The deposit and the online payment fee are kept, everything else goes back.",
                opts.no_show.available ? null : "The deposit and the fee are all that was paid, so nothing would go back.")}
              {opt("manual", "Custom amount", `You decide how much goes back (up to ${fmt(opts.manual.max)}). The rest is kept.`)}
            </div>

            <div className={`text-sm border p-3 rounded-xl space-y-1 ${kept > 0 ? "bg-amber-50 border-amber-200" : "bg-gray-50 border-gray-200"}`}>
              <div className="flex justify-between"><span className="text-gray-600">Customer paid</span><span className="font-semibold">{fmt(paid)}</span></div>
              {kept > 0 && <div className="flex justify-between text-amber-700"><span>Kept (customer's loss)</span><span className="font-semibold">-{fmt(kept)}</span></div>}
              <div className="flex justify-between border-t border-black/10 pt-1"><span className="font-bold text-gray-800">Hand back in store</span><span className="font-black">{fmt(refund)}</span></div>
            </div>

            <label className="block text-sm font-medium text-gray-700">Reason (kept in the audit log)
              <textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)}
                className="mt-1 w-full border rounded-xl px-3 py-2 text-sm outline-none resize-none" />
            </label>
          </>
        )}

        <div className="flex gap-3 justify-end pt-1">
          <button onClick={onClose} disabled={submitting} className="px-4 py-2 border rounded-xl text-sm disabled:opacity-50">Back</button>
          {preview?.eligible && (
            <button onClick={submit} disabled={!canSubmit}
              className="px-4 py-2 bg-arl-primary text-white rounded-xl text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#16526a] transition-colors">
              {submitting ? "Recording…" : "Record refund"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── VIEW DETAILS MODAL ───────────────────────────────────────────────────────

// ─── CUSTOMER PROFILE MODAL ─────────────────────────────────────────────
// Opened from the Customer name in either the table row or ViewModal,
// instead of navigating to /users. Pulls the base user doc (by-uid, which
// also carries the profile photo + referral info) and the userDetails doc
// (details).
//
// Booking counts come from the `bookings` list this page already loaded
// (/api/bookings?status=all returns every booking with its userID), so
// showing "how many bookings has this person made" costs no extra request.
//
// The invited-users list only shows each person's booking count plus a
// "View" button. View swaps THIS modal's content to a brief profile of that
// invited user (same modal, no stacking); the back arrow returns to the
// original customer's view.
const IconArrowLeft = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <line x1="19" y1="12" x2="5" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <polyline points="12 19 5 12 12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// Profile photo with an initials fallback (no photo, or the image fails to load).
function ProfileAvatar({ src, initials, className = "w-16 h-16 text-xl" }) {
  const [failed, setFailed] = useState(false);
  const base = `${className} rounded-xl flex-shrink-0`;
  if (src && !failed) {
    return <img src={src} alt="" onError={() => setFailed(true)} className={`${base} object-cover bg-gray-100`} />;
  }
  return <div className={`${base} bg-teal-600 text-white flex items-center justify-center font-bold`}>{initials}</div>;
}

// Loads one customer's base doc + details. Safe to call with a null id (idle).
function useCustomerProfile(userID) {
  const { getToken } = useAuth();
  const [state, setState] = useState({ basic: null, details: null, loading: !!userID, error: null });

  useEffect(() => {
    if (!userID) { setState({ basic: null, details: null, loading: false, error: null }); return; }
    let cancelled = false;
    setState({ basic: null, details: null, loading: true, error: null });
    const headers = { Authorization: `Bearer ${getToken()}` };
    Promise.all([
      fetch(`${process.env.REACT_APP_API_URL}/api/users/by-uid/${userID}`, { headers }).then((r) => r.json()),
      fetch(`${process.env.REACT_APP_API_URL}/api/users/details/${userID}`, { headers }).then((r) => r.json()).catch(() => null),
    ])
      .then(([basicRes, detailsRes]) => {
        if (cancelled) return;
        if (!basicRes?.success) throw new Error(basicRes?.message || "Could not load customer profile.");
        // Details 404s for a customer who never filled in personal info —
        // that's a normal state here, not an error worth surfacing.
        setState({ basic: basicRes.data, details: detailsRes?.success ? detailsRes.data : null, loading: false, error: null });
      })
      .catch((e) => !cancelled && setState({ basic: null, details: null, loading: false, error: e.message }));
    return () => { cancelled = true; };
  }, [userID, getToken]);

  return state;
}

const profileFullName = (details, basic) =>
  (details
    ? `${details.firstName || ""} ${details.middleName ? details.middleName + " " : ""}${details.lastName || ""}`.trim()
    : "") || basic?.username || "Customer Profile";

const profileInitials = (details, basic) =>
  ((details?.firstName?.[0] || basic?.email?.[0] || "?") + (details?.lastName?.[0] || "")).toUpperCase();

function CustomerProfileModal({ userID, bookings, onClose }) {
  const navigate = useNavigate();
  const [subID, setSubID] = useState(null); // invited user currently being viewed (null = original customer)
  const root = useCustomerProfile(userID);
  const sub  = useCustomerProfile(subID);
  const cur  = subID ? sub : root;
  const { basic, details, loading, error } = cur;

  // userID -> { total, completed } across every booking this page loaded. Only `completed` is shown in this window.
  const statsMap = useMemo(() => {
    const m = new Map();
    (bookings || []).forEach((b) => {
      if (!b.userID) return;
      const s = m.get(b.userID) || { total: 0, completed: 0 };
      s.total += 1;
      if ((b.status || "").toLowerCase() === "completed") s.completed += 1;
      m.set(b.userID, s);
    });
    return m;
  }, [bookings]);
  const statsOf = (id) => statsMap.get(id) || { total: 0, completed: 0 };

  const shownID = subID || userID;
  const stats   = statsOf(shownID);
  const bookingsText = String(stats.completed);   // only completed bookings are counted here

  const refBy = basic?.referral?.referredBy;
  const refByText = refBy
    ? (refBy.removed
        ? `${refBy.code || "—"} (account removed)`
        : (refBy.name && refBy.username ? `${refBy.name} (@${refBy.username})`
          : refBy.name || (refBy.username ? `@${refBy.username}` : refBy.code)))
    : "None";

  const row = (label, value) => (
    <div className="flex justify-between py-2 border-b border-gray-50 last:border-0 text-sm">
      <span className="text-gray-500 font-medium w-32 shrink-0">{label}</span>
      <span className="text-gray-800 text-right break-words">{value || "—"}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/40 z-[60] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 space-y-2 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2 min-w-0">
            {subID && (
              <button onClick={() => setSubID(null)} title="Back" aria-label="Back"
                className="shrink-0 p-1.5 -ml-1.5 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-100">
                <IconArrowLeft className="w-5 h-5" />
              </button>
            )}
            <h2 className="font-bold text-lg text-gray-800 truncate">
              {loading ? (subID ? "Invited user" : "Customer Profile") : profileFullName(details, basic)}
            </h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 shrink-0">
            <IconX className="w-5 h-5" />
          </button>
        </div>

        {loading ? (
          <div className="py-8 text-center text-sm text-gray-400">Loading…</div>
        ) : error ? (
          <div className="py-8 text-center text-sm text-red-500">{error}</div>
        ) : (
          <div>
            <div className="flex items-center gap-3 pb-3 mb-1 border-b border-gray-100">
              <ProfileAvatar key={basic?.profileImage || "none"} src={basic?.profileImage} initials={profileInitials(details, basic)} />
              <div className="min-w-0">
                <p className="font-semibold text-gray-800 truncate">{profileFullName(details, basic)}</p>
                <p className="text-xs text-gray-400 truncate">@{basic?.username || "—"}</p>
                <p className="mt-1 inline-block px-2 py-0.5 rounded-full text-xs font-semibold bg-teal-50 text-teal-700 border border-teal-200">
                  {stats.completed} completed {stats.completed === 1 ? "booking" : "bookings"}
                </p>
              </div>
            </div>

            {row("Email",     basic?.email)}
            {row("Phone",     basic?.phone)}
            {row("Username",  basic?.username)}
            {row("Status",    basic?.status)}
            {row("ID Status", basic?.isVerified ? "✓ Verified" : "Pending")}
            {row("Joined",    fmtDate(basic?.createdAt))}
            {row("Completed Bookings",  bookingsText)}

            {subID ? (
              // Brief view of an invited user: just the essentials.
              row("Invited", String(basic?.referral?.invitedCount || 0))
            ) : (
              <>
                {row("Referral Code", basic?.referral?.code)}
                {row("Referred By",   refByText)}
                {row("Invited",       String(basic?.referral?.invitedCount || 0))}
                {basic?.referral?.invited?.length > 0 && (
                  <ul className="mt-1 mb-1 divide-y border rounded-xl">
                    {basic.referral.invited.map((p) => {
                      const n = statsOf(p.id).completed;
                      return (
                        <li key={p.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                          <span className="min-w-0 truncate text-gray-700">
                            {p.name || "—"}{p.username && <span className="text-gray-400"> (@{p.username})</span>}
                          </span>
                          <span className="flex items-center gap-2 shrink-0">
                            <span className="text-xs text-gray-500">{n} completed</span>
                            <button onClick={() => setSubID(p.id)}
                              className="px-2.5 py-1 border border-teal-200 text-teal-700 rounded-lg text-xs font-semibold hover:bg-teal-50">
                              View
                            </button>
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                )}
                {details && row("Birth Date", details.birthDate ? fmtDate(details.birthDate) : "—")}
              </>
            )}
            <button
              type="button"
              onClick={() => navigate(`/users?open=${encodeURIComponent(subID || userID)}`)}
              className="w-full mt-3 py-2 rounded-xl text-sm font-semibold bg-arl-primary text-white hover:bg-[#16526a] transition-colors"
            >
              View More →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// Check circle for each step in the booking checklist (View modal, "Step by step" tab).
const STEP_STYLE = {
  done:    { dot: "bg-green-500 text-white border-green-500",                      text: "text-gray-800" },
  current: { dot: "bg-white text-teal-700 border-teal-500 ring-4 ring-teal-100",   text: "text-gray-900" },
  todo:    { dot: "bg-white text-gray-400 border-gray-300",                        text: "text-gray-500" },
  skipped: { dot: "bg-gray-100 text-gray-400 border-gray-200",                     text: "text-gray-400" },
  missing: { dot: "bg-amber-50 text-amber-600 border-amber-300",                   text: "text-gray-700" },
  review:  { dot: "bg-amber-50 text-amber-600 border-amber-300",                   text: "text-gray-700" },   // penalties noted but still waiting for a supervisor to confirm
  partial: { dot: "bg-orange-100 text-orange-600 border-orange-400",               text: "text-orange-700" },
  stopped: { dot: "bg-red-500 text-white border-red-500",                          text: "text-red-700" },
};

// Which step of the booking tracker (the 9 steps in ViewModal) a booking is on, for the table's "Phase" column.
// Booked and Paid are left out on purpose: every booking in the list is already booked, and payment has its own
// page. Same rules as ViewModal's step checks, so the list and the popup agree. Returns the NEXT unfinished step.
//   Driver → Pre-rental → Pickup/Monitor → Post-rental → Maintenance → Penalty → Deposit → Done
// Maintenance / Penalty only show while something is actually open (work filed and unfinished / a penalty waiting
// for review); a booking with none filed doesn't stall there. Cancelled / stolen bookings have no stage ("—").
function getBookingStage(b) {
  const status = (b.status || "").toLowerCase();
  if (status === "cancelled" || status === "stolen") return { label: "—", tone: "none" };
  if (status === "to pay") return { label: "—", tone: "none" };

  const isChauffeur = (b.modeOfDriving || "").toLowerCase().includes("chauffeur");
  const completed   = status === "completed";
  const started     = !!b.startedAt || status === "ongoing" || completed;
  const droppedOff  = !!b.droppedOffTime || completed;
  const inspDone    = (chk) => !!chk?.parts && !!chk?.photos;
  const depStatus   = b.deposit?.status || (b.paymentStatus === "Refunded" ? "Refunded" : null);
  const hasDeposit  = !!b.deposit || Number(b.securityDeposit) > 0;
  const depClosed   = ["Settled", "Refunded", "Forfeited", "Waived"].includes(depStatus);

  let label = null;
  if (isChauffeur && !b.driverID)            label = "Driver";
  else if (!inspDone(b.beforeInspection))    label = "Pre-rental";
  else if (!droppedOff)                      label = started ? "Monitor" : "Pickup";
  else if (!inspDone(b.afterInspection))     label = "Post-rental";
  else if (Number(b.maintenancePending) > 0) label = "Maintenance";
  else if (Number(b.penaltyReview) > 0)      label = "Penalty";
  else if (hasDeposit && !depClosed)         label = "Deposit";

  if (!label) return { label: "Done", tone: "done" };
  // A finished booking that still has an earlier step open (e.g. completed from Payments before the inspection) is flagged.
  return { label, tone: completed ? "warn" : "pending" };
}
const STAGE_STYLE = {
  pending: "bg-teal-50 text-teal-700 border-teal-200",
  warn:    "bg-amber-50 text-amber-700 border-amber-300",
  done:    "bg-green-50 text-green-700 border-green-200",
};

// Card + label-over-value cell, same look as the user details window (Users.jsx ViewDetailsModal).
function InfoSection({ title, aside, children, cols = 2 }) {
  return (
    <section className="bg-white border rounded-2xl overflow-hidden shadow-sm">
      <div className="flex items-center justify-between gap-2 px-4 py-2.5 bg-gray-50 border-b">
        <h3 className="text-xs font-semibold text-gray-600 uppercase tracking-wide">{title}</h3>
        {aside}
      </div>
      <div className={`p-4 grid ${cols === 3 ? "grid-cols-3" : "grid-cols-2"} gap-x-6 gap-y-4`}>{children}</div>
    </section>
  );
}
function InfoField({ label, value, wide }) {
  return (
    <div className={wide ? "col-span-2 min-w-0" : "min-w-0"}>
      <p className="text-[11px] font-medium uppercase tracking-wide text-gray-400">{label}</p>
      <div className="text-sm font-medium text-gray-800 mt-0.5 break-words">{value || "—"}</div>
    </div>
  );
}

function ViewModal({ booking, onClose, onViewCustomer, onEdit, onRefund, onDelete }) {
  const { fmt } = useCurrency();
  const { getToken } = useAuth();
  const navigate = useNavigate();
  const driverTotal = Number(booking.driversFee) || 0;
  const driverDays  = Math.max(1, Number(booking.totalDays) || 1);
  // Amount only; the "Refunded" label is not shown any more (the Cancellation section covers refunds).
  const depositText = booking.deposit?.status === "Waived" ? "Waived"
    : booking.deposit ? `${fmt(booking.deposit.amount)}${booking.deposit.status && booking.deposit.status !== "Refunded" ? ` · ${booking.deposit.status}` : ""}`
    : Number(booking.securityDeposit) > 0 ? `${fmt(booking.securityDeposit)}${booking.paymentStatus === "Refunded" ? "" : " · Awaiting payment"}`
    : "Not collected";
  const row = (label, value) => (
    <div className="flex justify-between py-2 border-b border-gray-50 last:border-0 text-sm">
      <span className="text-gray-500 font-medium w-36 shrink-0">{label}</span>
      <span className="text-gray-800 text-right">{value || "—"}</span>
    </div>
  );

  // Inline check: does THIS booking actually have before/after-trip
  // inventory records? Don't just link off to Vehicle Inspections and
  // hope it lands on the right one — that page defaults to a car's
  // nearest/upcoming booking, which for a completed booking is very
  // likely the wrong record entirely.
  const [inventoryCheck, setInventoryCheck]     = useState(null); // { before, after } | null
  const [inventoryLoading, setInventoryLoading] = useState(true);

  useEffect(() => {
    const bID = booking.bookingID || booking.id;
    if (!bID) { setInventoryLoading(false); return; }
    setInventoryLoading(true);
    fetch(`${process.env.REACT_APP_API_URL}/api/inventory/booking/${encodeURIComponent(bID)}`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    })
      .then((r) => r.json())
      .then((json) => setInventoryCheck(json.data || { before: null, after: null }))
      .catch(() => setInventoryCheck(null))
      .finally(() => setInventoryLoading(false));
  }, [booking, getToken]);

  // Is a GPS device linked to this booking's car? undefined = still checking, null = none, object = the device.
  // gpsError = the device list couldn't be loaded (so we don't claim "no device" when we simply don't know).
  const [gpsDevice, setGpsDevice] = useState(undefined);
  const [gpsError, setGpsError]   = useState(false);
  useEffect(() => {
    if (!booking.carID) { setGpsDevice(null); return; }
    let cancelled = false;
    setGpsDevice(undefined); setGpsError(false);
    fetch(`${process.env.REACT_APP_API_URL}/api/gps/devices`, { headers: { Authorization: `Bearer ${getToken()}` } })
      .then((r) => r.json().then((json) => ({ ok: r.ok, json })))
      .then(({ ok, json }) => {
        if (cancelled) return;
        if (!ok) { setGpsError(true); setGpsDevice(null); return; }
        setGpsDevice((json.data || []).find((d) => d.assigned && d.carID === booking.carID) || null);
      })
      .catch(() => { if (!cancelled) { setGpsError(true); setGpsDevice(null); } });
    return () => { cancelled = true; };
  }, [booking.carID, getToken]);

  // GPS Setup, in "link a device to this car" mode when the car has none (it asks which device to use, then
  // brings you back to this booking). With a device already linked it just opens the page.
  const goToDeviceSetup = () => {
    const bID = booking.bookingID || booking.id;
    navigate("/gps-setup", gpsDevice ? undefined : {
      state: {
        assignCarId:    booking.carID,
        assignCarLabel: booking.vehicleName || "this car",
        returnTo:       `/bookings?open=${encodeURIComponent(bID)}`,
      },
    });
  };

  const gpsMissing = gpsDevice === null && !gpsError; // we know the car has no device linked

  const goToHistory = () => {
    navigate("/car-tracking", {
      state: {
        tab: "history",
        carID: booking.carID,
        bookingID: booking.bookingID || booking.id,
      },
    });
  };

  // Car Tracking (Live tab) with this car already selected.
  // CarTracking already reads location.state.selectCarId (same deep link
  // Header notifications and GPS Setup use) and selects that car.
  const goToCarTracking = () => {
    navigate("/car-tracking", { state: { selectCarId: booking.carID } });
  };

  // Vehicle name -> Fleet, with this car's Details window already open.
  // Fleet reads location.state.openCarId.
  const goToFleet = () => {
    navigate("/fleet", { state: { openCarId: booking.carID } });
  };

  const goToPayments = () => {
    navigate(`/payments?bookingID=${encodeURIComponent(booking.bookingID || booking.id)}`);
  };

  // Terms & Conditions page, opened on the exact version this booking agreed to
  // (termsViewID = the termsVersions doc ID, or the old hash for pre-switch bookings).
  // bookingID lets the Terms page offer a "Back to booking" button.
  const goToTerms = () => {
    const params = new URLSearchParams({
      version: booking.termsViewID,
      bookingID: booking.bookingID || booking.id,
    });
    navigate(`/terms?${params.toString()}`);
  };

  // Vehicle Inspections page (system inventory: before/after-trip part
  // condition + photos) is keyed by carID first, bookingID second — same
  // deep-link shape it already reads elsewhere (?carID=...&bookingID=...).
  const goToInventory = () => {
    const params = new URLSearchParams({
      carID: booking.carID || "",
      bookingID: booking.bookingID || booking.id || "",
    });
    navigate(`/vehicle-documentation?${params.toString()}`);
  };

  // Maintenance.jsx already handles ?carID= (from Fleet.jsx); this reuses
  // that same effect, extended to also pre-fill ?bookingID= and default
  // the basis to "Post-Rental" — see that file's deep-link effect.
  const goToMaintenance = () => {
    const params = new URLSearchParams({
      carID: booking.carID || "",
      bookingID: booking.bookingID || booking.id || "",
    });
    navigate(`/maintenance?${params.toString()}`);
  };

  // A record is already filed for this booking: open it in its read-only view (Maintenance.jsx reads ?open=<id>)
  // instead of the add form. With several records, the newest one still in progress opens first (the list is newest first).
  const viewMaintenance = () => {
    const list = linkedMaintenance || [];
    const target = list.find((m) => m.status !== "Completed") || list[0];
    if (!target?.id) { goToMaintenance(); return; }
    navigate(`/maintenance?open=${encodeURIComponent(target.id)}`);
  };

  // Maintenance records already linked to THIS booking (filed manually
  // via the button below) — so staff can see at a glance whether post-rental cleaning/repair
  // has already been scheduled instead of guessing or re-filing it.
  const [linkedMaintenance, setLinkedMaintenance] = useState(null); // null = loading
  useEffect(() => {
    const bID = booking.bookingID || booking.id;
    if (!bID) { setLinkedMaintenance([]); return; }
    fetch(`${process.env.REACT_APP_API_URL}/api/maintenance/booking/${encodeURIComponent(bID)}`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    })
      .then((r) => r.json())
      .then((json) => setLinkedMaintenance(json.data || []))
      .catch(() => setLinkedMaintenance([]));
  }, [booking, getToken]);

  // Every stop for this booking's trip (pickup, dropoff, any extra stops
  // selected at booking time) — same shape MyTrips.jsx's map already uses.
  // Only ever non-empty once getAllBookings has resolved a session for
  // this booking (see booking.service.js's resolveHistoryInfo).
  const [mapOpen, setMapOpen] = useState(false);
  const locationStops = tripStops(booking);
    // Booking-time Number Coding restrictions the customer app saved (booking.codingWarnings) —
  // the list the customer was warned about; empty for bookings made before that existed.
  const codingByCity = warningsByCity(readCodingWarnings(booking.codingWarnings));

  // Existing penalties already tied to this booking — same "always shown,
  // even when empty" treatment as Linked Maintenance below, so staff can
  // see at a glance whether anything's been noted against this booking
  // instead of guessing or re-checking on the Penalties page.
  const [linkedPenalties, setLinkedPenalties] = useState(null); // null = loading
  useEffect(() => {
    const bID = booking.bookingID || booking.id;
    if (!bID) { setLinkedPenalties([]); return; }
    fetch(`${process.env.REACT_APP_API_URL}/api/penalties/booking/${encodeURIComponent(bID)}`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    })
      .then((r) => r.json())
      .then((json) => setLinkedPenalties(json.data || []))
      .catch(() => setLinkedPenalties([]));
  }, [booking, getToken]);

  // Penalties.jsx is where penalties actually get drafted (see its own
  // CreatePenaltyModal) — this hands it the bookingID via query param so
  // the draft it opens is pre-filled and locked to THIS booking, instead
  // of staff having to copy/type the ID over there themselves.
  const goToNotePenalty = () => {
    navigate(`/penalties?bookingID=${encodeURIComponent(booking.bookingID || booking.id)}`);
  };

  // ── Two tabs: "Step by step" (a checklist with View buttons) and "Details" ──
  // The steps: Booked → Paid → Driver → Before-trip inspection (vehicle inspection + device setup) → Pickup & trip
  // → Drop-off & after-trip inspection → Maintenance → Deposit & completion.
  // Each step's check is worked out from data this modal already has, and its
  // View button jumps to the page where that step is handled.
  const [tab, setTab] = useState("steps");

  const status        = (booking.status || "").toLowerCase();
  const dead          = status === "cancelled" || status === "stolen";
  const isStolen      = status === "stolen";
  const isCancelled   = status === "cancelled";
  const isChauffeur   = (booking.modeOfDriving || "").toLowerCase().includes("chauffeur");
  const before        = inventoryCheck?.before || null;
  const after         = inventoryCheck?.after || null;
  // The same before/after checklist the Pickup and Return gates use (it comes with every booking in the list):
  // { photos, parts, complete, videos } where photos = a video OR the 3 exterior photos. An inspection step is only
  // green when the parts condition AND that video/photos evidence both exist, so the tracker never says "done"
  // for something the gate would still block.
  const beforeChk     = booking.beforeInspection || null;
  const afterChk      = booking.afterInspection || null;
  const maint         = linkedMaintenance || [];
  const maintAllDone  = maint.length > 0 && maint.every((m) => m.status === "Completed");
  const depStatus     = booking.deposit?.status || (booking.paymentStatus === "Refunded" ? "Refunded" : null);
  const depositClosed = ["Settled", "Refunded", "Forfeited", "Waived"].includes(depStatus);
  // A cancelled booking that was refunded may have lost its deposit record, so money that came in
  // (or went back out) still counts as paid.
  const paid          = ["upcoming", "ongoing", "completed", "cancellation_request"].includes(status) || !!booking.deposit
    || (dead && (booking.paymentStatus === "Refunded" || booking.paymentStage === "Refunded" || Number(booking.amountPaid) > 0));
  // What happened to the money on a cancelled booking (shown under "Paid" and in the red banner).
  const refundNote    = status !== "cancelled" || !paid ? null
    : (booking.paymentStatus === "Refunded" || booking.paymentStage === "Refunded") ? "Refunded"
    : booking.paymentStage === "For Refund" ? "Refund pending"
    : depStatus === "Forfeited" ? "Deposit kept"
    : "No refund";
  // Paid but not in full yet (the balance is still owed) -> shown orange, "in the middle".
  const partial       = paid && !dead && status !== "completed" && (String(booking.paymentStage || "").toLowerCase() === "partial" || Number(booking.balance) > 0);
  const discountGiven = Number(booking.discountAmount) > 0;
  const started       = !!booking.startedAt || status === "ongoing" || status === "completed";
  const droppedOff    = !!booking.droppedOffTime || status === "completed";
  const invLabel      = (rec) => (rec.inventoryOverallStatus === "has damage" ? `Has damage (${rec.damageParts?.length || 0})` : "Good");
  // Parts confirmed = the saved parts record (fetched just now) or the checklist's flag; evidence = video or 3 photos.
  const inspectionDone = (rec, chk) => (!!rec || !!chk?.parts) && !!chk?.photos;
  const inspectionSub  = (rec, chk, emptyText) => {
    if (inventoryLoading) return "Checking…";
    const hasParts = !!rec || !!chk?.parts;
    const hasMedia = !!chk?.photos;
    const partsText = rec ? invLabel(rec) : "Parts confirmed";
    const mediaText = chk?.videos > 0 ? `${chk.videos} video${chk.videos > 1 ? "s" : ""}` : "photos";
    if (hasParts && hasMedia) return `${partsText} · ${mediaText}`;
    if (hasParts)             return `${partsText} · video or photos missing`;
    if (hasMedia)             return `${chk?.videos > 0 ? "Video added" : "Photos added"} · parts condition not confirmed`;
    return emptyText;
  };
  const pendingMaint  = maint.filter((m) => m.status !== "Completed").length;
  const penaltyCount  = (linkedPenalties || []).length;

  const monitorText = !started ? "Not started"
    : isStolen ? `Flagged stolen${booking.hasHistory ? " · GPS trail saved" : ""}`
    : !droppedOff ? "Trip in progress — track it live"
    : booking.hasHistory ? "GPS trail saved" : "No GPS trail saved";
  // A penalty a driver noted stays "Under Review" until a supervisor confirms it. Until then the step is yellow, not green.
  const penaltyReviewCount = (linkedPenalties || []).filter((x) => x.status === "UnderReview").length;
  const penaltiesDone = penaltyCount > 0 && penaltyReviewCount === 0;

  const stepDefs = [
    { key: "booked", title: "Booked", done: true, sub: fmtDateTime(booking.createdAt) },
    {
      // Payment AND the one-time discount. Orange while only part of the fee has come in.
      key: "paid", title: "Paid", done: paid && !partial, partial,
      sub: !paid ? "Awaiting payment"
        : [
            partial ? `Partial · ${fmt(booking.balance)} still to pay` : (booking.paymentMethod || "Paid"),
            refundNote,
            discountGiven ? `Discount −${fmt(booking.discountAmount)}` : null,
          ].filter(Boolean).join(" · "),
    },
    {
      // On a cancelled booking "self-drive, no driver needed" is not something that got done, so only a real assignment counts.
      key: "driver", title: "Driver assigned", done: isCancelled ? !!booking.driverID : (!isChauffeur || !!booking.driverID),
      sub: !isChauffeur ? "Self-drive — no driver needed" : booking.driverID ? (booking.driverName || "Assigned") : "No driver yet",
    },
    {
      // Two things to get done before pickup: the vehicle inspection, and a GPS device linked to the car.
      // The device part is only held against the step when we know the car has none (still loading / a failed check never block it).
      key: "before", title: "Before-trip inspection",
      done: inspectionDone(before, beforeChk) && !gpsMissing,
      sub: inspectionSub(before, beforeChk, "Not recorded"),
      parts: [
        {
          key: "inspection", label: "Vehicle inspection", done: inspectionDone(before, beforeChk),
          text: inspectionSub(before, beforeChk, "Not recorded"),
          actions: [{ label: "Vehicle Inspections", onClick: goToInventory }],
        },
        {
          key: "gps", label: "Device setup",
          done: gpsDevice === undefined ? undefined : !!gpsDevice,
          text: gpsDevice === undefined ? "Checking…"
            : gpsDevice ? `${gpsDevice.gpsName || "GPS device"} connected`
            : gpsError ? "Couldn't check the car's GPS device"
            : "No GPS device connected to this car",
          actions: booking.carID ? [{ label: "GPS Setup", onClick: goToDeviceSetup }] : [],
        },
      ],
    },
    {
      // One process: pickup → monitor → drop-off. Done once the car is dropped off.
      key: "trip", title: "Pickup, monitor & drop-off", done: droppedOff,
      sub: droppedOff ? "Dropped off" : started ? "Trip in progress" : "Not started",
      parts: [
        { key: "pickup", label: "Pickup", done: started, text: booking.startedAt ? fmtDateTime(booking.startedAt) : started ? "Trip started" : "Not picked up yet" },
        {
          key: "monitor", label: "Monitor", done: droppedOff || isStolen, text: monitorText,
          actions: [{ label: "Car Tracking", onClick: goToCarTracking }],
        },
        { key: "dropoff", label: "Drop-off", done: droppedOff, bad: isStolen && !droppedOff,
          text: booking.droppedOffTime ? fmtDateTime(booking.droppedOffTime) : droppedOff ? "Dropped off" : isStolen ? "Never dropped off — flagged stolen" : "Not dropped off yet",
          actions: booking.hasHistory ? [{ label: "Trip History", onClick: goToHistory }] : [] },
      ],
    },
    {
      // Green once the after-trip inspection is complete: parts condition + a video (or the 3 exterior photos).
      key: "after", title: "Post-rental inspection", done: inspectionDone(after, afterChk),
      warn: after?.inventoryOverallStatus === "has damage",
      sub: inspectionSub(after, afterChk, droppedOff ? "Dropped off · not inspected yet" : "Not recorded"),
    },
    {
      key: "maintenance", title: "Maintenance", done: maintAllDone,
      skipped: !maintAllDone && linkedMaintenance !== null && maint.length === 0 && status === "completed",
      sub: linkedMaintenance === null ? "Checking…"
        : maint.length === 0 ? (status === "completed" ? "None filed" : "None filed yet")
        : maintAllDone ? "Completed" : `${pendingMaint} in progress`,
    },
    {
      key: "penalties", title: "Penalties", done: penaltiesDone, review: penaltyReviewCount > 0,
      skipped: !penaltiesDone && penaltyReviewCount === 0 && linkedPenalties !== null && status === "completed",
      sub: linkedPenalties === null ? "Checking…"
        : penaltyReviewCount ? `${penaltyCount} noted · ${penaltyReviewCount} to review`
        : penaltyCount ? `${penaltyCount} noted` : status === "completed" ? "None noted" : "None noted yet",
    },
    {
      // A cancelled booking never completed: its refund / forfeit (already shown under "Paid") writes the deposit
      // status as Refunded/Forfeited, which used to turn this step green. It now shows as stopped, with the outcome.
      key: "deposit", title: "Deposit & completion", done: depositClosed && !isCancelled,
      stoppedSub: isCancelled && refundNote ? `Cancelled — ${refundNote}` : null,
      sub: depStatus || (Number(booking.securityDeposit) > 0 ? "Not settled yet" : "No deposit"),
    },
  ];

  // done as computed; on a cancelled or stolen booking every step that never happened is red
  // ("stopped"); otherwise the first one not done is "current", and on a finished booking gaps show as "missing".
  let currentSeen = false;
  const steps = stepDefs.map((d, i) => {
    let state;
    if (d.done) state = "done";
    else if (dead) state = "stopped";        // cancelled / stolen: everything that didn't happen is red
    else if (d.partial) state = "partial";   // in the middle: orange, and it doesn't hold up the steps after it
    else if (d.review) state = "review";     // penalties waiting for review: yellow, doesn't hold up the steps after it
    else if (d.skipped) state = "skipped";
    else if (status === "completed") state = "missing";
    else if (!currentSeen) { state = dead ? "stopped" : "current"; currentSeen = true; }
    else state = "todo";
    return { ...d, n: i + 1, state };
  });
  const countable = steps.filter((s) => s.state !== "skipped");
  const doneCount = countable.filter((s) => s.state === "done").length;

  // Every button is named after the page it opens.
  const goToDispatch = () => navigate("/driver-dispatch", {
    state: { assignBookingId: booking.bookingID || booking.id, assignCustomerName: booking.customerName },
  });
  const stepActions = {
    booked:      [{ label: "Details", onClick: () => setTab("details") }],
    paid:        [{ label: "Payments", onClick: goToPayments }],
    driver:      isChauffeur ? [{ label: "Driver Dispatch", onClick: goToDispatch }] : [],
    after:       [{ label: "Vehicle Inspections", onClick: goToInventory }],
    // Already filed: open it. Nothing filed (or still loading): the add form, as before.
    maintenance: maint.length > 0
      ? [{ label: maint.length > 1 ? `View maintenance (${maint.length})` : "View maintenance", onClick: viewMaintenance }]
      : [{ label: "Maintenance", onClick: goToMaintenance }],
    penalties:   [{ label: "Penalties", onClick: goToNotePenalty }],
    // The deposit is handed back from the Payments page ("Return deposit"), so name the button for it while one is waiting.
    deposit:     [{ label: status === "ongoing" && depStatus === "Held" ? "Return deposit (Payments)" : "Payments", onClick: goToPayments }],
  };

  const stepBtn = "px-3 py-1.5 text-sm font-medium rounded-xl border border-teal-200 bg-teal-50 text-teal-700 hover:bg-teal-100 transition-colors whitespace-nowrap";
  const partBtn = "px-2.5 py-1 text-xs font-medium rounded-lg border border-teal-200 bg-teal-50 text-teal-700 hover:bg-teal-100 transition-colors whitespace-nowrap";

  const tabBtn = (key, label) => (
    <button
      onClick={() => setTab(key)}
      className={`px-5 py-2.5 text-sm font-semibold border-b-2 -mb-px transition ${
        tab === key ? "border-teal-600 text-teal-700" : "border-transparent text-gray-400 hover:text-gray-600"
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 pt-5 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <h2 className="font-bold text-lg text-gray-800">Booking Details</h2>
              <StatusBadge status={booking.status} />
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 shrink-0">
              <IconX className="w-5 h-5" />
            </button>
          </div>
          <p className="text-sm text-gray-500 mt-1 truncate">
            {booking.customerName || "—"}{booking.vehicleName ? ` · ${booking.vehicleName}` : ""}
          </p>
          <div className="flex border-b border-gray-100 mt-3">
            {tabBtn("steps", "Step by step")}
            {tabBtn("details", "Details")}
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 min-h-0 overflow-y-auto px-6 py-5">
          {/* The customer's own request to cancel an ongoing trip (cancellationRequests).
              Shown on both tabs — this is the only place the approver can read WHY it was asked. */}
          {booking.cancellationRequest && (
            <div className="mt-2 rounded-xl border border-orange-100 bg-orange-50/60 px-3 py-2">
              <p className="text-xs font-semibold text-orange-700 mb-1">Cancellation request</p>
              {row("Status", String(booking.cancellationRequest.status || "").replace(/^./, (c) => c.toUpperCase()))}
              {row("Reason", booking.cancellationRequest.reason || "—")}
              {row("Requested", fmtDateTime(booking.cancellationRequest.createdAt || booking.cancellationRequest.requestedAt))}
              {booking.cancellationRequest.processedAt && row(
                "Processed",
                `${fmtDateTime(booking.cancellationRequest.processedAt)}${booking.cancellationRequest.processedByName ? ` by ${booking.cancellationRequest.processedByName}` : ""}`
              )}
              {booking.cancellationRequest.rejectReason && row("Reject reason", booking.cancellationRequest.rejectReason)}
            </div>
          )}

          {/* Cancelled / stolen: one clear red banner on both tabs. The header says WHO cancelled;
              the details (reason, time, refund) are in the Cancellation section of the Details tab. */}
          {dead && (
            <div className="mt-2 mb-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2">
              <p className="text-xs font-bold uppercase tracking-wide text-red-700">
                {isStolen
                  ? "Stolen — car flagged stolen"
                  : booking.cancelledBy === "customer" ? "Cancelled by Customer"
                  : booking.cancelledBy === "staff" ? "Cancelled by Staff"
                  : booking.cancelledBy === "system" ? "Cancelled by System"
                  : "Cancelled"}
              </p>
            </div>
          )}

          {/* Number Coding restrictions the customer was warned about when booking
              (booking.codingWarnings). Shown on both tabs — staff doing pickup on the Steps tab
              need it as much as someone reading Details. Nothing renders for older bookings. */}
          {codingByCity.length > 0 && (
            <div className="mt-2 mb-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
              <p className="font-semibold">⚠️ Number Coding restrictions found before booking</p>
              <ul className="mt-1.5 space-y-0.5">
                {codingByCity.map((c) => (
                  <li key={c.city || "city"}>
                    <span className="font-semibold">{c.city || "City"}</span>
                    {c.plateLastDigit != null ? ` (plate ending ${c.plateLastDigit})` : ""}
                    {c.text ? `: ${c.text}` : ""}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {tab === "steps" ? (
            <>
              <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-3">
                {doneCount} of {countable.length} steps done
              </p>
              <ol className="space-y-2">
                {steps.map((st) => {
                  const sty = STEP_STYLE[st.state];
                  const actions = stepActions[st.key] || [];
                  return (
                    <li
                      key={st.key}
                      className={`rounded-xl border ${st.state === "current" ? "border-teal-200 bg-teal-50/40" : st.state === "stopped" ? "border-red-200 bg-red-50/40" : "border-gray-100 bg-white"}`}
                    >
                      <div className="flex flex-wrap items-center gap-3 px-4 py-3">
                        <span className={`w-8 h-8 shrink-0 rounded-full border-2 flex items-center justify-center text-xs font-bold ${sty.dot}`}>
                          {st.state === "done" ? <IconCheck className="w-4 h-4" />
                            : st.state === "stopped" ? <IconX className="w-4 h-4" />
                            : st.state === "skipped" ? "–"
                            : st.state === "missing" || st.state === "review" ? "!"
                            : st.n}
                        </span>
                        <div className="min-w-0 flex-1 basis-40">
                          <p className={`text-sm font-semibold leading-snug ${sty.text}`}>{st.n}. {st.title}</p>
                          <p className={`text-xs mt-0.5 ${st.warn ? "text-red-600 font-semibold" : "text-gray-400"}`}>
                            {st.state === "stopped" ? (isStolen ? "Not completed — car flagged stolen" : st.stoppedSub || "Cancelled — did not happen") : st.sub}
                          </p>
                        </div>
                        {actions.length > 0 && (
                          <div className="flex items-center gap-2 shrink-0 ml-auto">
                            {actions.map((a) => (
                              <button key={a.label} onClick={a.onClick} className={stepBtn}>{a.label}</button>
                            ))}
                          </div>
                        )}
                      </div>

                      {st.parts && (
                        <ul className="pl-[3.75rem] pr-4 pb-3 pt-0.5 space-y-2">
                          {st.parts.map((p) => (
                            <li key={p.key} className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
                              <span className={`w-5 h-5 shrink-0 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                                p.bad ? "bg-red-500 text-white border-red-500"
                                : p.done === undefined ? "bg-gray-100 text-gray-400 border-gray-200"
                                : p.done ? "bg-green-500 text-white border-green-500"
                                : "bg-white text-gray-300 border-gray-300"
                              }`}>
                                {p.bad ? <IconX className="w-3 h-3" /> : p.done ? <IconCheck className="w-3 h-3" /> : p.done === undefined ? "•" : ""}
                              </span>
                              <div className="min-w-0 flex-1 basis-40">
                                <span className="text-sm font-medium text-gray-700">{p.label}</span>
                                <span className={`text-xs ml-2 ${p.warn || p.bad ? "text-red-600 font-semibold" : "text-gray-400"}`}>{p.text}</span>
                              </div>
                              {p.actions && (
                                <div className="flex items-center gap-2 shrink-0 ml-auto">
                                  {p.actions.map((a) => (
                                    <button key={a.label} onClick={a.onClick} className={partBtn}>{a.label}</button>
                                  ))}
                                </div>
                              )}
                            </li>
                          ))}
                        </ul>
                      )}
                    </li>
                  );
                })}
              </ol>
            </>
          ) : (
            <div className="space-y-4">
              {/* Same look as the user details window in Users.jsx: one bordered card per group. */}
              <InfoSection title="Customer Information">
                <InfoField label="Customer" value={booking.userID ? (
                  <button onClick={() => onViewCustomer(booking.userID)} className="text-indigo-600 hover:underline font-medium text-left">
                    {booking.customerName || "—"}
                  </button>
                ) : booking.customerName} />
                <InfoField label="Phone" value={booking.phone} />
              </InfoSection>

              <InfoSection title="Booking Information">
                <InfoField label="Booking ID" value={booking.bookingID || booking.id} />
                <InfoField label="Created"    value={fmtDateTime(booking.createdAt)} />
                <InfoField label="Vehicle" value={booking.carID && booking.vehicleName ? (
                  <button onClick={goToFleet} title="Open vehicle details in Fleet" className="text-indigo-600 hover:underline font-medium text-left">
                    {booking.vehicleName}
                  </button>
                ) : booking.vehicleName} />
                <InfoField label="Service Type" value={booking.serviceTypeName} />
                <InfoField label="Start Date" value={fmtDate(booking.startDateTime)} />
                <InfoField label="End Date"   value={fmtDate(booking.endDateTime)} />
                <InfoField wide label="Duration" value={booking.totalDays != null ? `${booking.totalDays} day${booking.totalDays > 1 ? "s" : ""}` : null} />
                <InfoField label="Driving"    value={booking.modeOfDriving} />
                <InfoField label="Driver" value={booking.driverID ? (
                  `${booking.driverName || "—"}${booking.driverPhone && booking.driverPhone !== "—" ? ` · ${booking.driverPhone}` : ""}`
                ) : (
                  <span className="text-gray-400 italic font-normal">{isChauffeur ? "No driver assigned" : "Not needed"}</span>
                )} />
                {/* Pickup and destination live on the map. */}
                <div className="col-span-2 flex items-center justify-between gap-4 pt-3 border-t border-gray-100 min-w-0">
                  <p className="text-[11px] font-medium uppercase tracking-wide text-gray-400">Pickup, Destination/s and Drop-off</p>
                  {locationStops.length > 0 ? (
                    <button onClick={() => setMapOpen(true)} className="px-3.5 py-1 rounded-lg text-xs font-semibold bg-arl-primary text-white hover:bg-[#16526a] transition-colors shrink-0">
                      View Map →
                    </button>
                  ) : (
                    <span className="text-xs text-gray-300 shrink-0">No map data</span>
                  )}
                </div>
              </InfoSection>

              <InfoSection
                title="Booking Fee"
                cols={3}
                aside={(
                  <button
                    type="button"
                    onClick={goToPayments}
                    title="Open this booking's payment on the Payments page"
                    className="px-3.5 py-1 rounded-lg text-xs font-semibold bg-arl-primary text-white hover:bg-[#16526a] transition-colors"
                  >
                    View payments →
                  </button>
                )}
              >
                <InfoField label="Rental Fee"       value={fmt(booking.rentalFee)} />
                <InfoField label="Security Deposit" value={depositText} />
                <div />
                <InfoField label="Service Fee"      value={fmt(booking.serviceFee)} />
                <InfoField label="Gateway Fee"      value={Number(booking.gatewayFee) > 0 ? fmt(booking.gatewayFee) : null} />
                <div />
                {/* Chauffeur: rate per day × days = total. driversFee is the total, so the rate is total ÷ days. */}
                <InfoField label="Driver's Fee"     value={driverTotal > 0 ? fmt(driverTotal / driverDays) : null} />
                <InfoField label="Duration"         value={driverTotal > 0 ? `× ${driverDays} day${driverDays > 1 ? "s" : ""}` : null} />
                <InfoField label="Total Driver Fee" value={driverTotal > 0 ? fmt(driverTotal) : null} />
                <div className="col-span-3 flex items-baseline justify-end gap-4 pt-3 border-t border-gray-100">
                  <span className="text-[11px] font-medium uppercase tracking-wide text-gray-400">Total Fee</span>
                  <span className="text-base font-bold text-gray-800">{fmt(booking.totalFee)}</span>
                </div>
              </InfoSection>

              {/* Cancellation — only for a cancelled booking. Every line shows; "—" = not recorded. */}
              {isCancelled && (
                <InfoSection title="Cancellation">
                  <InfoField label="Cancelled By" value={
                    booking.cancelledBy === "system" ? "System (auto-cancelled)"
                    : booking.cancelledBy === "customer" ? `${booking.cancelledByName || booking.customerName || "Customer"} · Customer`
                    : booking.cancelledBy === "staff" ? (booking.cancelledByName ? `${booking.cancelledByName} · ${booking.cancelledByRole || "Staff"}` : "Staff · name not recorded")
                    : "Not recorded"
                  } />
                  <InfoField label="Cancelled At" value={booking.cancelledAt ? fmtDateTime(booking.cancelledAt) : null} />
                  {booking.approvedByName && <InfoField label="Approved By" value={`${booking.approvedByName} · ${booking.approvedByRole || "Staff"}`} />}
                  <InfoField wide label="Reason" value={booking.cancelDisplayReason} />
                  {booking.refundSummary?.byStaff && (
                    <InfoField wide label="Refund Type" value={
                      booking.refundSummary.depositForfeited > 0 ? `No Deposit Refund · ${fmt(booking.refundSummary.depositForfeited)} deposit${booking.refundSummary.gatewayFeeKept > 0 ? ` and ${fmt(booking.refundSummary.gatewayFeeKept)} payment fee` : ""} not returned`
                      : booking.refundSummary.gatewayFeeKept > 0 ? `Normal refund · ${fmt(booking.refundSummary.gatewayFeeKept)} payment fee not returned`
                      : booking.refundSummary.bookingPaid > (booking.refundSummary.amount || 0) ? `Partial refund · ${fmt(booking.refundSummary.bookingPaid - booking.refundSummary.amount)} not returned`
                      : "Full refund"
                    } />
                  )}
                  <InfoField wide label="Refund" value={(booking.refundSummary?.status || refundNote) ? (
                    <span className="flex items-center justify-between gap-3">
                      <span>{booking.refundSummary?.status || refundNote}{booking.refundSummary?.scheduled ? " · sends after midnight" : ""}</span>
                      {booking.refundSummary?.refundRequestID && (
                        <button
                          type="button"
                          onClick={() => navigate(`/refund-requests?search=${encodeURIComponent(booking.refundSummary.refundRequestID)}`)}
                          className="px-3.5 py-1 rounded-lg text-xs font-semibold bg-arl-primary text-white hover:bg-[#16526a] transition-colors shrink-0"
                        >
                          View refund →
                        </button>
                      )}
                    </span>
                  ) : null} />
                </InfoSection>
              )}

              {/* T&C this customer ticked "I agree" to. Written once at booking creation, never edited. */}
              <InfoSection title="Terms & Conditions">
                <InfoField wide label="Agreed Version" value={
                  booking.termsViewID && booking.termsAcceptedAt ? (
                    <span className="flex items-center justify-between gap-3">
                      <button onClick={goToTerms} title="Open the exact Terms & Conditions text the customer agreed to" className="text-indigo-600 hover:underline font-medium text-left">
                        {booking.termsVersionNumber != null && Number.isFinite(Number(booking.termsVersionNumber))
                          ? `Version ${Number(booking.termsVersionNumber).toFixed(2)}`
                          : "View agreed terms"} →
                      </button>
                      <span className="text-xs text-gray-400 font-normal shrink-0">Agreed {fmtDateTime(booking.termsAcceptedAt)}</span>
                    </span>
                  ) : booking.termsAcceptedAt ? (
                    <span>Agreed {fmtDateTime(booking.termsAcceptedAt)} <span className="text-xs text-gray-400 font-normal">· Version not recorded</span></span>
                  ) : (
                    <span className="text-gray-400 font-normal">No agreement recorded</span>
                  )
                } />
              </InfoSection>

              {/* Admin / Owner only (onRefund is only passed to them). Opens the same Refund & Cancel window the footer button used to. */}
              {onRefund && (canRefundCancel(booking.status) || status === "ongoing") && (
                <InfoSection title="Cancel Booking">
                  {canRefundCancel(booking.status) ? (
                    <div className="sm:col-span-2 col-span-full flex items-center justify-between gap-4">
                      <p className="text-sm text-gray-500">Cancel this booking and choose what goes back to the customer: full refund, normal refund, no deposit refund, or cancel only.</p>
                      <button onClick={() => onRefund(booking)} className="shrink-0 px-3.5 py-1.5 border border-red-200 bg-red-50 text-red-600 font-semibold rounded-xl text-sm hover:bg-red-100 transition-colors whitespace-nowrap">Cancel Booking</button>
                    </div>
                  ) : (
                    <p className="sm:col-span-2 col-span-full text-sm text-gray-400">A trip that is already ongoing can't be cancelled from here. It goes through the customer's cancellation request.</p>
                  )}
                </InfoSection>
              )}

              <InfoSection title="Notes">
                <InfoField wide label="Notes (User)"  value={booking.notesUser} />
                <InfoField wide label="Notes (Admin)" value={booking.notesAdmin} />
              </InfoSection>
            </div>
          )}
        </div>

        {/* Actions — only the ones that apply to this booking / this role. */}
        <div className="px-6 py-4 border-t border-gray-100 shrink-0">
        {(onEdit || onRefund || onDelete) && (
          <div className="flex flex-col gap-1.5">
            {onEdit && (
              <button onClick={() => onEdit(booking)} className="w-full px-3 py-1.5 bg-arl-primary text-white font-semibold rounded-xl text-sm hover:bg-[#16526a] transition-colors">Add Note</button>
            )}
            {onRefund && status === "cancelled" && !booking.refundSummary && (refundNote === "No refund" || refundNote === "Deposit kept") && (
              <button onClick={() => onRefund(booking)} className="w-full px-3 py-1.5 border border-orange-200 bg-orange-50 text-orange-700 font-semibold rounded-xl text-sm hover:bg-orange-100 transition-colors whitespace-nowrap">Refund (cancelled)</button>
            )}
            {onDelete && (
              <button onClick={() => onDelete(booking)} className="w-full px-3 py-1.5 border border-red-200 bg-red-50 text-red-600 font-semibold rounded-xl text-sm hover:bg-red-100 transition-colors">Delete</button>
            )}
          </div>
        )}
          <button onClick={onClose} className="w-full mt-1.5 py-1.5 border rounded-xl text-sm">Close</button>
        </div>
      </div>

      <TripMapModal
        open={mapOpen}
        onClose={() => setMapOpen(false)}
        title={`${booking.customerName || "Booking"} — ${booking.vehicleName || ""}`}
        stops={locationStops}
      />
    </div>
  );
}

// Booking ID with a copy icon beside it. Shows the first 8 characters (full ID
// on hover and what actually gets copied) so the column stays narrow.
function CopyableId({ value }) {
  const [copied, setCopied] = useState(false);
  if (!value) return <span className="text-gray-300">—</span>;
  const copy = async (e) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(String(value));
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch { /* clipboard blocked — nothing to do */ }
  };
  return (
    <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
      <span className="font-mono text-xs text-gray-600" title={value}>{String(value).slice(0, 8)}…</span>
      <button
        type="button"
        onClick={copy}
        title={copied ? "Copied!" : "Copy booking ID"}
        aria-label="Copy booking ID"
        className={`p-1 rounded-md transition-colors ${copied ? "text-teal-600 bg-teal-50" : "text-gray-400 hover:text-teal-600 hover:bg-teal-50"}`}
      >
        {copied ? (
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
        ) : (
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2" /><path strokeLinecap="round" d="M5 15V6a2 2 0 012-2h9" /></svg>
        )}
      </button>
    </span>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

export default function Bookings() {
  const { getToken, effectiveRole } = useAuth();
  const canRefundRole = [ROLES.ADMIN, ROLES.OWNER].includes(effectiveRole);
  const [refundBooking, setRefundBooking] = useState(null);
  const [activeTab, setActiveTab]           = useState("All");
  const [search, setSearch]                 = useState("");
  const [searchBy, setSearchBy]             = useState("customer");
  const [dateValue, setDateValue]           = useState(""); // "YYYY-MM-DD" from the date picker
  const [allBookings, setAllBookings]       = useState([]);
  const [loading, setLoading]               = useState(true);
  const [error, setError]                   = useState(null);
  const [viewBooking, setViewBooking]       = useState(null);
  const [editBooking, setEditBooking]       = useState(null);
  const [deleteBooking, setDeleteBooking]   = useState(null);
  const [deleteToast, setDeleteToast]       = useState(null);
  // Customer name → profile modal, in place, instead of navigating to /users.
  // Shared by both the table row and ViewModal (ViewModal passes its own
  // trigger down to this same modal via the userID it's given).
  const [profileUserID, setProfileUserID]   = useState(null);
  const [searchParams, setSearchParams]     = useSearchParams();
  const [sortKey, setSortKey]               = useState("created");  // newest bookings on top by default
  const [sortDir, setSortDir]               = useState("desc");

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "created" ? "desc" : "asc");
    }
  };

  const showToast = (msg, type = "success") => {
    setDeleteToast({ msg, type });
    setTimeout(() => setDeleteToast(null), 4000);
  };

  // `silent` skips the loading spinner — used by the live-refresh listener below
  // so a change from another admin/customer doesn't flash the whole table blank.
  const fetchBookings = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const res  = await fetch(`${process.env.REACT_APP_API_URL}/api/bookings?status=all`, { headers: { Authorization: `Bearer ${getToken()}` } });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to load bookings");
      setAllBookings(json.data);
    } catch (err) { if (!silent) setError(err.message); }
    finally { if (!silent) setLoading(false); }
  }, [getToken]);

  useEffect(() => { fetchBookings(); }, [fetchBookings]);

  // ── Live refresh ────────────────────────────────────────────────────────────
  // The REST endpoint does all the real work (joins car/user/driver info, sorts,
  // filters), so instead of re-implementing that here off raw Firestore docs,
  // we just listen for *any* change to the bookings collection and re-run the
  // existing fetch. Bursts of writes (e.g. a booking + its history doc changing
  // together) are coalesced with a short debounce so we don't hammer the API.
  //
  // CHANGED: this used to be onSnapshot(collection(db, "bookings")) — which reads
  // EVERY booking document each time the page opens and again on every change
  // (per open tab), on top of the API re-fetch it triggered. Now it just
  // re-runs the same API fetch every 45s while the tab is visible.
  usePolling(() => fetchBookings(true), 45_000, { immediate: false });

  // Opens a specific status tab when linked in via ?tab=<Upcoming|Ongoing|...>
  // (used by Dashboard's stat cards). Runs once, on mount — doesn't need to
  // wait on bookings to load like ?open= below does.
  useEffect(() => {
    const tabParam = searchParams.get("tab");
    if (!tabParam) return;
    const match = STATUS_TABS.find((t) => t.toLowerCase() === tabParam.toLowerCase());
    if (match) setActiveTab(match);
    setSearchParams((prev) => { prev.delete("tab"); return prev; }, { replace: true });
  }, [searchParams, setSearchParams]);

  // Linked in with ?search=<bookingID> (e.g. Payments' "View booking"): fills the search bar, on the All tab so the
  // booking can't be hidden by a status tab, then strips the param. The list is filtered right away, no loading wait.
  useEffect(() => {
    const q = searchParams.get("search");
    if (!q) return;
    setSearchBy("booking"); // these links always carry a booking ID
    setDateValue("");
    setSearch(q);
    setActiveTab("All");
    setSearchParams((prev) => { prev.delete("search"); return prev; }, { replace: true });
  }, [searchParams, setSearchParams]);

  // Opens the exact booking a notification click pointed to (?open=<refID>,
  // set by Header.jsx). Runs once bookings are loaded so the record is
  // actually there to find; strips the param afterward so refreshing/
  // navigating away doesn't keep re-opening it.
  useEffect(() => {
    const openID = searchParams.get("open");
    if (!openID || loading || allBookings.length === 0) return;
    const match = allBookings.find((b) => b.id === openID || b.bookingID === openID);
    if (match) setViewBooking(match);
    setSearchParams((prev) => { prev.delete("open"); return prev; }, { replace: true });
  }, [searchParams, allBookings, loading, setSearchParams]);

  // DeleteBundleModal does the asking + the DELETE call (blockers, force, whole-booking archive); we only react.
  const handleDeleted = (json) => {
    const removed = deleteBooking;
    setAllBookings((prev) => prev.filter((b) => b.id !== removed.id));
    showToast(json?.message || "Booking archived.", "success");
    setDeleteBooking(null);
  };

  const counts = {
    All:       allBookings.length,
    "To Pay":  allBookings.filter((b) => b.status?.toLowerCase() === "to pay").length,
    Upcoming:  allBookings.filter((b) => b.status?.toLowerCase() === "upcoming").length,
    Ongoing:   allBookings.filter((b) => b.status?.toLowerCase() === "ongoing").length,
    Cancelled: allBookings.filter((b) => b.status?.toLowerCase() === "cancelled").length,
    Completed: allBookings.filter((b) => b.status?.toLowerCase() === "completed").length,
  };
  const cancellationRequestCount = allBookings.filter((b) => b.status?.toLowerCase() === "cancellation_request").length;

  const tabFiltered  = activeTab === "All"
    ? allBookings
    : allBookings.filter((b) => b.status?.toLowerCase() === activeTab.toLowerCase());

  const searchType = SEARCH_BY.find((o) => o.key === searchBy)?.type || "text";

  const filtered = tabFiltered.filter((b) => {
    if (searchType === "date") {
      if (!dateValue) return true;
      const val = searchBy === "created" ? b.createdAt : searchBy === "start" ? b.startDateTime : b.endDateTime;
      return dayKey(val) === dateValue;
    }
    const q = search.trim().toLowerCase();
    if (!q) return true;
    const hay = {
      customer: b.customerName,
      phone:    b.phone,
      vehicle:  b.vehicleName,
      phase:    b.paymentStage,
      booking:  b.bookingID || b.id,
    }[searchBy];
    return String(hay || "").toLowerCase().includes(q);
  });

  // Sort (dates/fee/duration only — everything else stays in API/insertion order).
  // Applied after search+tab filtering, before pagination, so page counts
  // reflect the sorted set and Page 1 always shows the "top" of the sort.
  const sorted = [...filtered].sort((a, b) => {
    if (!sortKey) return 0;
    let av, bv;
    if (sortKey === "start") { av = toMillis(a.startDateTime); bv = toMillis(b.startDateTime); }
    else if (sortKey === "end") { av = toMillis(a.endDateTime); bv = toMillis(b.endDateTime); }
    else if (sortKey === "fee") { av = a.totalFee ?? -Infinity; bv = b.totalFee ?? -Infinity; }
    else if (sortKey === "created") { av = toMillis(a.createdAt); bv = toMillis(b.createdAt); }
    else if (sortKey === "duration") { av = a.totalDays != null ? Number(a.totalDays) : -Infinity; bv = b.totalDays != null ? Number(b.totalDays) : -Infinity; }
    else return 0;
    if (av === bv) return 0;   // also avoids -Infinity - -Infinity = NaN when both are missing
    return sortDir === "asc" ? av - bv : bv - av;
  });

  const { page, setPage, totalPages, pageItems, start, count } = usePagination(sorted);
  // Jump back to page 1 whenever the visible set changes shape (new search/filter/tab).
  // (not on allBookings: the 45s background refresh would otherwise throw you back to page 1 while you browse)
  useEffect(() => { setPage(1); }, [search, searchBy, dateValue, activeTab, sortKey, sortDir]); // eslint-disable-line react-hooks/exhaustive-deps

  const fmtDuration = (days) => { if (days == null) return "—"; return days <= 1 ? `${days} day` : `${days} days`; };

  return (
    <div className="p-4 space-y-5 font-sans">

      {/* TOAST */}
      {deleteToast && (
        <div className={`fixed top-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-medium text-white ${deleteToast.type === "error" ? "bg-red-500" : "bg-teal-600"}`}>
          {deleteToast.msg}
        </div>
      )}

      {/* STAT TABS */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
        {STATUS_TABS.map((tab) => {
          const TabIcon = TAB_ICON[tab];
          return (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`p-4 rounded-2xl border text-left transition-all ${activeTab === tab ? "border-teal-500 bg-teal-50 shadow-sm" : "bg-white hover:bg-gray-50"}`}
            >
              <div className="flex items-start justify-between">
                <div className={`text-2xl font-bold ${activeTab === tab ? "text-teal-600" : "text-gray-800"}`}>{loading ? "…" : counts[tab] ?? 0}</div>
                <span className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${TAB_ICON_COLOR[tab]}`}>
                  <TabIcon className="w-4 h-4" />
                </span>
              </div>
              <div className="text-xs text-gray-400 mt-0.5 flex items-center gap-1">
                {tab === "All" ? "All Bookings" : tab}
                {tab === "Cancelled" && cancellationRequestCount > 0 && <span className="w-2 h-2 bg-red-500 rounded-full inline-block" />}
              </div>
            </button>
          );
        })}
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex justify-between items-center">
          <span className="flex items-center gap-2">
            <IconWarning className="w-4 h-4 shrink-0" />
            {error}
          </span>
          <button onClick={fetchBookings} className="underline font-semibold">Retry</button>
        </div>
      )}

      {/* TABLE */}
      <div className="bg-white rounded-2xl border overflow-hidden">
        {/* SEARCH + FILTERS */}
        <div className="flex flex-wrap gap-3 items-end p-4 border-b">
          <div className="flex flex-col gap-1">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Search by</span>
            <select
              value={searchBy}
              onChange={(e) => { setSearchBy(e.target.value); setSearch(""); setDateValue(""); }}
              className="px-3 py-2 border rounded-xl text-sm text-gray-700 outline-none bg-white"
            >
              {SEARCH_BY.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
            </select>
          </div>
          {searchType === "date" ? (
            <input
              type="date"
              value={dateValue}
              onChange={(e) => setDateValue(e.target.value)}
              className="flex-1 min-w-52 px-4 py-2 border rounded-xl text-sm outline-none"
            />
          ) : (
            <input
              type="text"
              placeholder={`Enter ${(SEARCH_BY.find((o) => o.key === searchBy)?.label || "").toLowerCase()}...`}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 min-w-52 px-4 py-2 border rounded-xl text-sm outline-none"
            />
          )}
          <select
            value={activeTab}
            onChange={(e) => setActiveTab(e.target.value)}
            className="px-3 py-2 border rounded-xl text-sm text-gray-700 outline-none bg-white"
          >
            {STATUS_TABS.map((t) => <option key={t} value={t}>{t === "All" ? "All statuses" : t}</option>)}
          </select>
          <button
            onClick={fetchBookings}
            className="px-4 py-2 rounded-xl text-sm font-medium bg-arl-primary text-white hover:bg-[#16526a] flex items-center gap-1.5"
          >
            <IconRefresh className="w-3.5 h-3.5" />
            Refresh
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-400 text-xs uppercase tracking-wide">
              <tr>
                <SortableTh label="Created At" sortKey="created" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                <th className="px-4 py-3 text-left">Phase</th>
                <th className="px-4 py-3 text-left">Customer</th>
                <th className="px-4 py-3 text-left">Contact No.</th>
                <th className="px-4 py-3 text-left">Vehicle</th>
                <SortableTh label="Trip Start" sortKey="start" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                <SortableTh label="Trip End" sortKey="end" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                <SortableTh label="Duration" sortKey="duration" sortKeyState={sortKey} sortDir={sortDir} onSort={handleSort} />
                <th className="px-4 py-3 text-left">Booking ID</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="pl-4 pr-8 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-t">
                    {Array.from({ length: 11 }).map((__, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-gray-100 rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr><td colSpan={11} className="text-center text-gray-400 py-12">No bookings found</td></tr>
              ) : (
                pageItems.map((b) => {
                  const needsAction = b.status?.toLowerCase() === "cancellation_request";
                  return (
                    <tr key={b.id} className={`border-t hover:bg-gray-50 transition-colors ${needsAction ? "bg-orange-50 border-l-4 border-l-orange-500" : ""}`}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="text-gray-700">{fmtDate(b.createdAt)}</span>
                        <span className="mx-1.5 text-gray-300">|</span>
                        <span className="text-gray-500">{fmtTime(b.createdAt)}</span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {(() => {
                          const stage = getBookingStage(b);
                          return stage.tone === "none"
                            ? <span className="text-gray-300">—</span>
                            : <span
                                title={stage.tone === "warn" ? "Booking is completed but this step is still open" : stage.tone === "done" ? "All steps finished" : "Next step to do"}
                                className={`inline-flex items-center text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${STAGE_STYLE[stage.tone]}`}
                              >{stage.label}</span>;
                        })()}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => setProfileUserID(b.userID)}
                          disabled={!b.userID}
                          className="font-medium text-gray-800 hover:text-indigo-600 hover:underline text-left disabled:no-underline disabled:cursor-default disabled:hover:text-gray-800"
                        >
                          {b.customerName}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-gray-700 whitespace-nowrap">{b.phone || "—"}</td>
                      <td className="px-4 py-3">
                        <div className="text-gray-700">{b.vehicleName}</div>
                      </td>
                      <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{fmtDate(b.startDateTime)}</td>
                      <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{fmtDate(b.endDateTime)}</td>
                      <td className="px-4 py-3 text-gray-600 whitespace-nowrap">
                        {fmtDuration(b.totalDays)}
                        {b.durationType && <span className="text-xs text-gray-400 ml-1">· {b.durationType}</span>}
                      </td>
                      <td className="px-4 py-3"><CopyableId value={b.bookingID || b.id} /></td>
                      <td className="px-4 py-3"><StatusBadge status={b.status} /></td>
                      <td className="pl-4 pr-8 py-3 text-right">
                        <button onClick={() => setViewBooking(b)} className="px-3.5 py-1 rounded-lg text-xs font-semibold bg-arl-primary text-white hover:bg-[#16526a] transition-colors">View</button>
                      </td>
                    </tr>
                  );
                })
              )}
              {/* Same as Refunds: pad a short page with empty rows so the table always keeps its 10-row height. */}
              {!loading && pageItems.length > 0 && Array.from({ length: Math.max(0, PAGE_SIZE - pageItems.length) }).map((_, i) => (
                <tr key={`filler-${i}`} aria-hidden="true" className="border-t">
                  <td colSpan={11} className="h-[53px]">&nbsp;</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination page={page} totalPages={totalPages} onChange={setPage} start={start} pageSize={PAGE_SIZE} count={count} />
      </div>

      {viewBooking   && (
        <ViewModal
          booking={viewBooking}
          onClose={() => setViewBooking(null)}
          onViewCustomer={setProfileUserID}
          onEdit={(b) => { setViewBooking(null); setEditBooking(b); }}
          onRefund={canRefundRole ? (b) => { setViewBooking(null); setRefundBooking(b); } : undefined}
          onDelete={(b) => { setViewBooking(null); setDeleteBooking(b); }}
        />
      )}
      {editBooking   && <EditModal booking={editBooking} onClose={() => setEditBooking(null)} onSave={() => { setEditBooking(null); fetchBookings(); }} />}
      {refundBooking && String(refundBooking.status || "").toLowerCase() === "cancelled" && (
        <RefundAfterCancelModal
          booking={refundBooking}
          onClose={() => setRefundBooking(null)}
          onDone={(msg) => { setRefundBooking(null); showToast(msg, "success"); fetchBookings(); }}
        />
      )}
      {refundBooking && String(refundBooking.status || "").toLowerCase() !== "cancelled" && (
        <RefundCancelModal
          booking={refundBooking}
          onClose={() => setRefundBooking(null)}
          onDone={(msg) => { setRefundBooking(null); showToast(msg, "success"); fetchBookings(); }}
        />
      )}
      {profileUserID && <CustomerProfileModal userID={profileUserID} bookings={allBookings} onClose={() => setProfileUserID(null)} />}
      {deleteBooking && (
        <DeleteBundleModal
          kind="booking"
          id={deleteBooking.id}
          label={deleteBooking.bookingID || deleteBooking.id}
          onClose={() => setDeleteBooking(null)}
          onDone={handleDeleted}
        />
      )}
    </div>
  );
}