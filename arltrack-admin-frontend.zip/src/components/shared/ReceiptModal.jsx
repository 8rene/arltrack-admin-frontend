import React, { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { useCurrency } from "../../context/CurrencyContext";

// Printable Receipt / Slip for ONE successful money movement (a booking payment, a penalty payment, a refund or a deposit return).
//   <ReceiptModal entryID="..." onClose={() => ...} />
// Reads GET /api/payment-entries/:entryID/receipt. Every open is written to the audit log by the server, and a reprint is
// shown as a COPY. "Print / Save as PDF" uses the browser's print dialog; "Email to customer" sends it to the address on the
// customer's account (POST /api/payment-entries/:entryID/receipt/email). For the whole booking in one document, see StatementModal.

const fmtDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d) ? iso : d.toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
};
const fmtDay = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d) ? iso : d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
};
const METHOD = { gcash: "GCash", maya: "Maya", qrph: "QR Ph", cash: "Cash", bank_transfer: "Bank transfer" };

// Print only the receipt: hide everything else on the page while the print dialog is open.
const PRINT_CSS = `
@media print {
  /* The app locks html/body to the screen height with overflow hidden (index.css); in print that cut everything after the first page. */
  html, body { height: auto !important; min-height: 0 !important; overflow: visible !important; }
  body > *:not(#receipt-print-root) { display: none !important; }
  #receipt-print-root { position: static !important; background: #fff !important; padding: 0 !important; overflow: visible !important; }
  #receipt-print-root .no-print { display: none !important; }
  #receipt-print-root .receipt-sheet { box-shadow: none !important; border: none !important; max-width: none !important; margin: 0 !important; }
  #receipt-print-root .keep-together { break-inside: avoid; }
  #receipt-print-root, #receipt-print-root .receipt-sheet { height: auto !important; max-height: none !important; overflow: visible !important; }
  @page { margin: 14mm; }
}`;

function Row({ label, children, strong = false, tone }) {
  if (children == null || children === "") return null;
  return (
    <div className={`flex justify-between gap-4 text-sm py-0.5 ${strong ? "font-semibold" : ""}`}>
      <span className={strong ? "text-gray-800" : "text-gray-500"}>{label}</span>
      <span className={`text-right break-all ${tone || "text-gray-900"}`}>{children}</span>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="border-t border-dashed border-gray-300 pt-3 space-y-2 keep-together">
      <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">{title}</p>
      {children}
    </div>
  );
}

export default function ReceiptModal({ entryID, onClose }) {
  const { fmt } = useCurrency();
  const [state, setState] = useState({ loading: true, error: null, data: null });
  // email to the customer: idle -> confirm (shows where it will go) -> sending -> idle again with a result message
  const [mail, setMail] = useState({ stage: "idle", ok: null, msg: "" });

  useEffect(() => {
    let alive = true;
    setState({ loading: true, error: null, data: null });
    fetch(`${process.env.REACT_APP_API_URL}/api/payment-entries/${encodeURIComponent(entryID)}/receipt`, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    })
      .then(async (res) => { const json = await res.json(); if (!res.ok) throw new Error(json.message || "Could not load the receipt."); return json.data; })
      .then((data) => alive && setState({ loading: false, error: null, data }))
      .catch((e) => alive && setState({ loading: false, error: e.message, data: null }));
    return () => { alive = false; };
  }, [entryID]);

  // Escape closes ONLY the receipt (capture phase + stopImmediatePropagation), so a screen underneath that also closes on
  // Escape stays open.
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") { e.stopImmediatePropagation(); onClose?.(); } };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  const sendEmail = async () => {
    setMail({ stage: "sending", ok: null, msg: "" });
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/payment-entries/${encodeURIComponent(entryID)}/receipt/email`, {
        method: "POST",
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      const json = await res.json().catch(() => ({}));
      setMail({ stage: "idle", ok: res.ok, msg: json.message || (res.ok ? "Receipt emailed." : "Couldn't send the email.") });
    } catch {
      setMail({ stage: "idle", ok: false, msg: "Couldn't reach the server. Please try again." });
    }
  };

  const { loading, error, data: r } = state;
  const out = r?.direction === "out";   // money handed back to the customer (refund / deposit return)
  const how = r ? [METHOD[r.method] || r.method, r.source === "in_person" ? "In person" : r.source === "online" ? "Online" : null].filter(Boolean).join(" · ") : "";

  // z-[2100]: above the Car Tracking payment popup and the map. The click handlers stop the event here because React
  // sends events from a portal up through the component that opened it, and the screens underneath close on a backdrop click.
  return createPortal(
    <div
      id="receipt-print-root"
      className="fixed inset-0 z-[2100] bg-black/50 overflow-auto p-4"
      onClick={(e) => { e.stopPropagation(); onClose?.(); }}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <style>{PRINT_CSS}</style>
      <div className="receipt-sheet relative mx-auto max-w-lg bg-white rounded-2xl shadow-xl border border-gray-200 p-6" onClick={(e) => e.stopPropagation()} onMouseDown={(e) => e.stopPropagation()}>
        {loading && <p className="text-sm text-gray-400 py-10 text-center">Preparing receipt…</p>}
        {error && (
          <div className="space-y-3">
            <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg p-3">{error}</p>
            <button onClick={onClose} className="no-print w-full rounded-xl border border-gray-300 py-1.5 text-sm text-gray-700 hover:bg-gray-50">Close</button>
          </div>
        )}

        {r && (
          <div className="space-y-4" data-testid="receipt">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <img src={`${process.env.PUBLIC_URL || ""}/logo192.png`} alt="ARL Car Rental" className="h-14 w-14 shrink-0 object-contain" />
                <div className="min-w-0 space-y-0.5">
                  <p className="text-lg font-bold leading-tight text-gray-900">{r.business.name}</p>
                  {r.business.address && <p className="text-xs text-gray-500">{r.business.address}</p>}
                  {(r.business.phone || r.business.email) && <p className="text-xs text-gray-500">{[r.business.phone, r.business.email].filter(Boolean).join(" · ")}</p>}
                </div>
              </div>
              <div className="border-t border-gray-200 pt-2 text-center">
                <p className="text-sm font-semibold tracking-wide uppercase text-gray-700">
                  {r.title}
                  {r.isCopy && <span className="ml-2 align-middle rounded-full border border-gray-400 px-2 py-0.5 text-[10px] font-bold text-gray-600">COPY</span>}
                </p>
                <p className="text-xs text-gray-500">{fmtDate(r.date)}</p>
              </div>
            </div>

            <div className="border-t border-dashed border-gray-300 pt-3">
              <Row label="Receipt no.">{r.receiptNo}</Row>
              <Row label="Customer">{r.customer.name}</Row>
              <Row label="Booking">{r.booking.bookingID}</Row>
              <Row label="Vehicle">{r.booking.vehicle}</Row>
              {r.booking.startDateTime && <Row label="Rental period">{fmtDay(r.booking.startDateTime)} – {fmtDay(r.booking.endDateTime)}</Row>}
            </div>

            {/* what was paid / returned in this movement */}
            <Section title={out ? "Returned to customer" : "Payment details"}>
              <div>
                {r.lines.map((l, i) => (
                  <div key={i} className="flex items-start justify-between gap-4 text-sm py-0.5">
                    <div className="min-w-0">
                      <p className={l.isFee ? "text-gray-500" : "text-gray-800"}>{l.label}</p>
                      {l.detail && <p className="text-xs text-gray-400 break-all">{l.detail}</p>}
                    </div>
                    <span className="text-gray-900 whitespace-nowrap">{fmt(l.amount)}</span>
                  </div>
                ))}
                <div className="border-t border-gray-200 mt-1 pt-1"><Row label={out ? "Total returned" : "Total paid"} strong>{fmt(r.total)}</Row></div>
              </div>
              <div>
                <Row label="Method">{how}</Row>
                <Row label="Reference no.">{r.referenceNumber}</Row>
                <Row label="Handled by">{r.handledBy}</Row>
              </div>
              {r.note && <p className="text-xs text-gray-500">{r.note}</p>}
            </Section>

            {/* penalty receipts: the charges behind each payment and where each penalty stands now */}
            {r.penalties?.length > 0 && (
              <Section title={r.penalties.length > 1 ? "Penalties covered" : "Penalty covered"}>
                <div className="space-y-3">
                  {r.penalties.map((p, i) => (
                    <div key={p.penaltyID || i} className="rounded-lg border border-gray-200 p-3 space-y-1">
                      {p.penaltyID && <p className="text-[11px] text-gray-400 break-all">{p.penaltyID}</p>}
                      {p.items.map((it, j) => <Row key={j} label={it.description}>{fmt(it.amount)}</Row>)}
                      {p.total != null && <div className="border-t border-gray-200 pt-1"><Row label="Penalty total" strong>{fmt(p.total)}</Row></div>}
                      {p.paidBefore > 0 && <Row label="Paid before">{fmt(p.paidBefore)}</Row>}
                      {p.coveredByDeposit > 0 && <Row label="Covered by security deposit">{fmt(p.coveredByDeposit)}</Row>}
                      <Row label="This payment">{fmt(p.thisPayment)}</Row>
                      {p.remaining != null && <Row label="Still unpaid" strong tone={p.remaining > 0 ? "text-red-600" : "text-green-700"}>{p.remaining > 0 ? fmt(p.remaining) : "Fully paid"}</Row>}
                    </div>
                  ))}
                </div>
              </Section>
            )}

            {/* booking payments: where the booking stands after this payment */}
            {r.summary && (
              <Section title="Booking balance">
                <div>
                  <Row label="Booking total">{fmt(r.summary.bookingTotal)}</Row>
                  <Row label="Paid to date">{fmt(r.summary.paidToDate)}</Row>
                  <div className="border-t border-gray-200 mt-1 pt-1">
                    <Row label="Balance after this payment" strong tone={r.summary.balanceAfter > 0 ? "text-red-600" : "text-green-700"}>{r.summary.balanceAfter > 0 ? fmt(r.summary.balanceAfter) : "Fully paid"}</Row>
                  </div>
                </div>
              </Section>
            )}

            {/* deposit return slips: how the held deposit was used */}
            {r.depositSummary && (
              <Section title="Security deposit">
                <div>
                  <Row label="Deposit held">{fmt(r.depositSummary.held)}</Row>
                  <Row label="Used for penalties">{r.depositSummary.usedForPenalties > 0 ? `− ${fmt(r.depositSummary.usedForPenalties)}` : null}</Row>
                  <div className="border-t border-gray-200 mt-1 pt-1"><Row label="Returned to customer" strong>{fmt(r.depositSummary.returned)}</Row></div>
                </div>
              </Section>
            )}

            <p className="text-[11px] text-gray-400 text-center border-t border-dashed border-gray-300 pt-3">
              {r.isCopy ? "This is a reprinted copy. " : ""}Printed {fmtDate(r.printedAt)}{r.printedBy ? ` by ${r.printedBy}` : ""}. System-generated, not an official receipt.
            </p>

            <div className="no-print space-y-2 pt-1">
              {mail.msg && (
                <p className={`text-xs rounded-lg border p-2 ${mail.ok ? "text-green-700 bg-green-50 border-green-200" : "text-red-600 bg-red-50 border-red-200"}`}>{mail.msg}</p>
              )}

              {mail.stage === "idle" ? null : (
                <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 space-y-2">
                  <p className="text-sm text-blue-900">Send this receipt to <b>{r.customer.emailMasked}</b>?</p>
                  <div className="flex gap-2">
                    <button disabled={mail.stage === "sending"} onClick={() => setMail({ stage: "idle", ok: null, msg: "" })} className="flex-1 rounded-lg border border-gray-300 bg-white py-1.5 text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50">Cancel</button>
                    <button disabled={mail.stage === "sending"} onClick={sendEmail} className="flex-1 rounded-lg bg-blue-900 py-1.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-50">{mail.stage === "sending" ? "Sending…" : "Send"}</button>
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-1.5">
                <button onClick={() => window.print()} className="w-full rounded-xl bg-blue-900 px-3 py-1.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors">Print / Save as PDF</button>
                <button
                  disabled={!r.customer.emailMasked || mail.stage !== "idle"}
                  title={r.customer.emailMasked ? `Email to ${r.customer.emailMasked}` : "This customer has no email on their account"}
                  onClick={() => setMail({ stage: "confirm", ok: null, msg: "" })}
                  className="w-full rounded-xl border border-blue-900 px-3 py-1.5 text-sm font-semibold text-blue-900 hover:bg-blue-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >Email to customer</button>
                <button onClick={onClose} className="w-full mt-1.5 rounded-xl border border-gray-300 py-1.5 text-sm text-gray-700 hover:bg-gray-50">Close</button>
              </div>
              {!r.customer.emailMasked && <p className="text-[11px] text-gray-400">No email address on this customer's account.</p>}
            </div>
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}