import { useState, useEffect } from "react";
import { useTheme } from "../../context/ThemeContext";
import StoreLocationMapPicker from "../shared/StoreLocationMapPicker";

const IconPin = ({ className = "w-4 h-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 21s7-7.05 7-12a7 7 0 10-14 0c0 4.95 7 12 7 12z" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="12" cy="9" r="2.5" stroke="currentColor" strokeWidth="1.75" />
  </svg>
);

// ─── Store Location & Name ──────────────────────────────────────────────
// Powers the customer app's "Pick up in-store" option (Booking.jsx /
// BookingDetails.jsx). Backed by the SAME systemSettings doc as the
// pricing card above — see backend/models/systemSettings/systemSettings
// .model.js — just a different named endpoint (/api/settings/store)
// touching only the storeName/storeLat/storeLng slice of it.
//
// UNLIKE pricing, this one IS actually wired up to the customer app: the
// customer backend's getStoreLocation reads this same Firestore doc
// directly (same project). Saving here takes effect immediately, with
// no customer-app redeploy needed.
//
// Kept as its own self-contained card (own fetch/save/edit state) rather
// than folded into the big pricing form above — different save cadence,
// different endpoint, and a map picker doesn't fit that form's simple
// numeric-input layout.
export default function StoreLocationCard() {
  const { isDark } = useTheme();

  const [storeName, setStoreName] = useState("");
  const [storeLat,  setStoreLat]  = useState(null);
  const [storeLng,  setStoreLng]  = useState(null);
  const [saved,     setSaved]     = useState({ storeName: "", storeLat: null, storeLng: null });

  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [notice,  setNotice]  = useState(null);
  const [pickerOpen, setPickerOpen] = useState(false);

  const card = `rounded-2xl border p-6 ${
    isDark
      ? "bg-[#1A5F7A] border-[#4FC3F7]/20 shadow-[0_4px_24px_rgba(79,195,247,0.08)]"
      : "bg-white border-gray-100 shadow-soft"
  }`;

  const inputCls = `w-full rounded-xl border px-3 py-2 text-sm focus:outline-none focus:ring-2 transition-colors disabled:opacity-60 disabled:cursor-not-allowed ${
    isDark
      ? "bg-[#212121] border-[#4FC3F7]/20 text-[#F5F5F5] focus:ring-[#4FC3F7]/40"
      : "bg-white border-gray-200 text-arl-dark focus:ring-arl-dark/20"
  }`;

  const fetchStore = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/settings/store`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.message || "Failed to load store location.");
      setStoreName(json.data.storeName || "");
      setStoreLat(json.data.storeLat);
      setStoreLng(json.data.storeLng);
      setSaved(json.data);
    } catch (err) {
      setNotice({ type: "error", msg: err.message || "Failed to load store location." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStore(); }, []);

  const isDirty = storeName !== (saved.storeName || "") || storeLat !== saved.storeLat || storeLng !== saved.storeLng;
  const isConfigured = !!storeName && storeLat !== null && storeLng !== null;

  const handlePickerConfirm = ({ address, lat, lng }) => {
    setStoreName(address);
    setStoreLat(lat);
    setStoreLng(lng);
    setPickerOpen(false);
  };

  const handleClear = () => {
    setStoreName("");
    setStoreLat(null);
    setStoreLng(null);
  };

  const handleSave = async () => {
    setSaving(true);
    setNotice(null);
    try {
      const res = await fetch(`${process.env.REACT_APP_API_URL}/api/settings/store`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({ storeName, storeLat, storeLng }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) throw new Error(json.message || "Failed to save store location.");

      setStoreName(json.data.storeName || "");
      setStoreLat(json.data.storeLat);
      setStoreLng(json.data.storeLng);
      setSaved(json.data);
      setEditMode(false);
      setNotice({ type: "success", msg: "Store location saved." });
    } catch (err) {
      setNotice({ type: "error", msg: err.message || "Failed to save store location." });
    } finally {
      setSaving(false);
      setTimeout(() => setNotice(null), 5000);
    }
  };

  const handleReset = () => {
    setStoreName(saved.storeName || "");
    setStoreLat(saved.storeLat);
    setStoreLng(saved.storeLng);
    setNotice(null);
    setEditMode(false);
  };

  return (
    <div className={`${card} space-y-4`}>
      <div>
        <h2 className={`font-semibold text-sm flex items-center gap-2 ${isDark ? "text-[#F5F5F5]" : "text-gray-700"}`}>
          <IconPin className={`w-4 h-4 ${isDark ? "text-[#4FC3F7]" : "text-gray-500"}`} /> Store Location &amp; Name
        </h2>
        <p className={`text-xs mt-0.5 ${isDark ? "text-[#F5F5F5]/40" : "text-gray-400"}`}>
          Powers "Pick up in-store" on the customer booking page. Leave blank to hide that option entirely.
        </p>
      </div>

      {notice && (
        <div className={`rounded-xl border px-4 py-2.5 text-sm ${
          notice.type === "success"
            ? isDark ? "bg-[#1A5F7A] text-[#4FC3F7] border-[#4FC3F7]/30" : "bg-green-50 text-green-700 border-green-200"
            : "bg-[#D32F2F]/10 text-[#D32F2F] border-[#D32F2F]/30"
        }`}>
          {notice.msg}
        </div>
      )}

      {loading ? (
        <p className={`text-sm ${isDark ? "text-[#F5F5F5]/50" : "text-gray-400"}`}>Loading…</p>
      ) : (
        <>
          <div className="space-y-1">
            <label className={`text-xs font-medium ${isDark ? "text-[#F5F5F5]/70" : "text-gray-600"}`}>Store Name / Label</label>
            <input
              type="text"
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              disabled={!editMode}
              placeholder="e.g. ARL Car Rental — Malolos Branch"
              className={inputCls}
            />
            <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>
              Shown to customers as the pickup label — pick a name that's clear on its own, not just an address.
            </p>
          </div>

          <div className="space-y-2">
            <label className={`text-xs font-medium ${isDark ? "text-[#F5F5F5]/70" : "text-gray-600"}`}>Location</label>

            <div className={`rounded-xl border px-4 py-3 flex items-center justify-between gap-3 ${
              isDark ? "bg-[#212121] border-[#4FC3F7]/20" : "bg-gray-50 border-gray-200"
            }`}>
              <div className="min-w-0">
                {storeLat !== null && storeLng !== null ? (
                  <p className={`text-xs font-mono truncate ${isDark ? "text-[#F5F5F5]/70" : "text-gray-600"}`}>
                    {storeLat.toFixed(5)}, {storeLng.toFixed(5)}
                  </p>
                ) : (
                  <p className={`text-xs italic ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>No location set</p>
                )}
              </div>
              {editMode && (
                <div className="flex gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setPickerOpen(true)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      isDark ? "bg-[#4FC3F7] text-[#212121] hover:bg-[#4FC3F7]/90" : "bg-arl-primary text-white hover:bg-arl-secondary"
                    }`}
                  >
                    📍 {storeLat !== null ? "Change on Map" : "Pick on Map"}
                  </button>
                  {(storeName || storeLat !== null) && (
                    <button
                      type="button"
                      onClick={handleClear}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                        isDark ? "border-[#4FC3F7]/20 text-[#F5F5F5]/60 hover:bg-[#4FC3F7]/10" : "border-gray-200 text-gray-500 hover:bg-gray-100"
                      }`}
                    >
                      Clear
                    </button>
                  )}
                </div>
              )}
            </div>

            {!isConfigured && !editMode && (
              <p className={`text-[11px] ${isDark ? "text-[#F5F5F5]/35" : "text-gray-400"}`}>
                "Pick up in-store" is currently hidden on the customer app — set both a name and a location to enable it.
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-1">
            {editMode ? (
              <>
                <button
                  onClick={handleSave}
                  disabled={saving || !isDirty}
                  className={`px-6 py-2.5 rounded-xl shadow text-sm font-medium disabled:opacity-50 transition-all ${
                    isDark ? "bg-[#4FC3F7] hover:bg-[#4FC3F7]/90 text-[#212121]" : "bg-arl-dark hover:opacity-90 text-white"
                  }`}
                >
                  {saving ? "Saving…" : "Save Changes"}
                </button>
                <button
                  onClick={handleReset}
                  disabled={saving}
                  className={`px-6 py-2.5 rounded-xl border text-sm font-medium disabled:opacity-50 transition-all ${
                    isDark ? "border-[#4FC3F7]/20 text-[#F5F5F5]/70 hover:bg-[#212121]/40" : "border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {isDirty ? "Discard Changes" : "Cancel"}
                </button>
              </>
            ) : (
              <button
                onClick={() => setEditMode(true)}
                className={`px-6 py-2.5 rounded-xl shadow text-sm font-medium transition-all ${
                  isDark ? "bg-[#4FC3F7] hover:bg-[#4FC3F7]/90 text-[#212121]" : "bg-arl-dark hover:opacity-90 text-white"
                }`}
              >
                Edit Settings
              </button>
            )}
          </div>
        </>
      )}

      <StoreLocationMapPicker
        isOpen={pickerOpen}
        onClose={() => setPickerOpen(false)}
        onConfirm={handlePickerConfirm}
        initialLabel={storeName}
        initialCoords={storeLat !== null && storeLng !== null ? { lat: storeLat, lng: storeLng } : null}
      />
    </div>
  );
}