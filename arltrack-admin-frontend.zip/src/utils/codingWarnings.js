// Reads the booking-time Number Coding audit the CUSTOMER app saves on the
// trip session as `codingCheck`. Shape (newer bookings):
//   { blocked, reason, city, dayOfWeek, checkedAt, plateLastDigit,
//     locations: [{ id, label, city }],
//     warnings:  [{ id, location, city, schedule: [{ dayOfWeek, dayName, startTime, endTime }] }],
//     warned, datedWarnings (count), acknowledged }
// `id` is "pickup", "primary" (main destination) or an extra stop's id.
// `warnings` is the schedule the customer was SHOWN for that location;
// `acknowledged` is true only when some of the booking's own dates fell on a
// coded day and the customer confirmed it. Older bookings only have the first
// five fields, so everything here returns null / [] for them and callers show
// nothing extra.

const DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const norm = (s) => String(s || "").trim().toLowerCase();

export function readCodingWarnings(codingCheck) {
  const cc = codingCheck;
  if (!cc || !Array.isArray(cc.warnings) || cc.warnings.length === 0) return null;
  const acknowledged = cc.acknowledged === true;
  return {
    plateLastDigit: cc.plateLastDigit ?? null,
    acknowledged,
    datedWarnings: Number(cc.datedWarnings) || 0,
    checkedAt: cc.checkedAt || null,
    warnings: cc.warnings.map((w) => ({
      id: w?.id ?? null,
      location: w?.location || "",
      city: w?.city || "",
      schedule: Array.isArray(w?.schedule) ? w.schedule : [],
      acknowledged,
    })),
  };
}

// "Fri 7:00 AM – 10:00 AM, 3:00 PM – 7:00 PM; Mon 7:00 AM – 10:00 AM"
export function scheduleText(schedule) {
  if (!Array.isArray(schedule) || schedule.length === 0) return "";
  const byDay = new Map();
  for (const s of schedule) {
    const dow = Number(s?.dayOfWeek);
    const day = (s?.dayName && String(s.dayName).slice(0, 3)) || (dow >= 1 && dow <= 7 ? DAY_NAMES[dow - 1] : "");
    const win = s?.startTime && s?.endTime ? `${s.startTime} – ${s.endTime}` : "";
    if (!byDay.has(day)) byDay.set(day, []);
    if (win) byDay.get(day).push(win);
  }
  return [...byDay.entries()].map(([d, wins]) => [d, wins.join(", ")].filter(Boolean).join(" ")).join("; ");
}

export const warningStatusText = (acknowledged) =>
  acknowledged ? "Customer confirmed the warning" : "Schedule shown at booking";

// Pins each warned location onto the stop it belongs to so the map can mark it.
//   "pickup"  -> the pickup stop
//   "primary" -> the main destination stop (matched by the booking's destination
//                text; falls back to the dropoff pin when they share a spot)
//   other ids -> the extra stop with the same address text
// Anything that cannot be placed is returned in `unplaced` (the details list
// still shows it). Returns copies; the input stops are not changed.
export function matchWarningsToStops(stops, warnings, destinationText) {
  const placed = stops.map((s) => ({ ...s }));
  const unplaced = [];
  for (const w of warnings || []) {
    let target = null;
    if (w.id === "pickup") {
      target = placed.find((s) => s.type === "pickup");
    } else if (w.id === "primary") {
      target = placed.find((s) => s.type === "stop" && norm(s.address) === norm(destinationText))
            || placed.find((s) => s.type === "dropoff");
    } else {
      target = placed.find((s) => s.type === "stop" && norm(s.address) && norm(s.address) === norm(w.location));
    }
    if (!target) { unplaced.push(w); continue; }
    (target.warnings = target.warnings || []).push(w);
  }
  return { stops: placed, unplaced };
}